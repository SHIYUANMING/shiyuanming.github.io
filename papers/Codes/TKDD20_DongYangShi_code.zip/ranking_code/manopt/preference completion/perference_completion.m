function [X, infos] = perference_completion(Y,user,item_1,item_2,params)
%   fun          function handle on the optimization algorithm
%                (trust region or gradient descent) 
%   H            n-by-n symmetric martix with binary entries 
%   D_ob         n-by-n matrix: Euclidean Distance Matric with noisy.
%   Y            m-by-p0 initial condition of rank p0
%   params       structure array containing algorithm parameters
              
    params = defaultparams(params);
    [n, ~,~] = size(Y);
    n_train = size(user,1);
    pmax = params.maxrank;
    max_step = params.max_step;
    ls_maxiter = params.ls_maxiter;
    smin_tol = params.smin_tol;
    vp_tol = params.vp_tol;
    
    % Record cost function values and new rank locations
    infos.cost = [];
    infos.newRank = [];
    
    p0 = 1;% the initial rank
    p = p0;
    X = randn(n,p0);
   
    
    while (p <= pmax),
         fprintf('>> Rank %d <<\n',p);
         if (p > p0),
            
            if isempty(restartDir), % If no restart dir avail. do random restart
                
                disp('No restart dir available, random restart is performed');
                X = randn(n,p);
                
            else % Perform line-search based on the restart direction 
                
                disp('>> Line-search with restart direction');
                X(:,p) = 0; % Append a column of zeroes  
                f = 0;
                for z = 1:n_train,
                    i = user(z);
                    j = item_1(z);
                    k = item_2(z);
                    if j <= p && k <= p,
                     YdeltaX = Y(i,j,k) * (X(i,j) - X(i,k));
                     f = f + l2_loss(YdeltaX); 
                    end
                end
                f_before = f;
                fprintf('>> Cost before = %f\n',f);

                stepsize = 2.5;
                if stepsize > max_step,
                    stepsize = max_step;
                end
                    
                for iter = 1:ls_maxiter,
                    
                    % Update
                    X(:,p) = stepsize*restartDir;
                    f = 0;
                    for z = 1:n_train,
                        i = user(z);
                        j = item_1(z);
                        k = item_2(z);
                        if j <= p && k <= p,
                         YdeltaX = Y(i,j,k) * (X(i,j) - X(i,k));
                         f = f + l2_loss(YdeltaX);
                        end
                    end
                    f_after = f;
                    fprintf('>> Cost after = %f\n',f);
                    
                    % Armijo rule
                    armijo = (f_after - f_before) <=   - 1e-4 * stepsize * norm([zeros(n,p); restartDir]' * deta_Y,'fro');
                    if armijo,
                        break;
                    else
                        stepsize = stepsize/2;
                    end
                    
                end
                % Check for sufficient decrease
                if (costAfter >= costBefore) || abs(costAfter - costBefore) < 1e-8,
                    disp('Decrease is not sufficient, random restart');
                    X = randn(n,p);
                end
                
            end    

        end
       
        % Run algorithm
        [X, infos_algo] = fixedrankopt(Y, X, p, user, item_1, item_2,params);
        if size([infos_algo.cost],1) == 1,
            infoscost =  [infos_algo.cost ]';
        else
            infoscost = infos_algo.cost;
        end
        infos.cost = [infos.cost; infoscost];
        infos.newRank = [infos.newRank;max([infos_algo.iter])];
       
        % Dual variable
        Sy = 0;
        for z = 1:n_train,
            i = user(z);
            j = item_1(z);
            k = item_2(z);
            if j <= p && k <= p,
             YdeltaX = Y(i,j,k) * (X(i,j) - X(i,k));   
             if YdeltaX < 1,
               Sy = Sy - 2 * (1 - YdeltaX);
             end
            end

        end
        % Compute smallest algebraic eigenvalue of Sy,
        % this gives us a descent direction for the next rank (v)
        % as well as a way to control progress toward the global
        % optimum (s_min)
        [v, s_min] = eigs(Sy, 1, 'SA');
        
        % To check whether Y is rank deficient
        %vp = svd(X);
        
%         % Stopping criterion
%         fprintf('>> smin = %f, and min(vp) = %f\n',s_min,min(vp));
%         if (s_min  > -smin_tol) || (min(vp) < vp_tol),
%             break;
%         end
        
          p = p + 1;

        if (s_min < -1e-10),
            restartDir = v;
        else
            restartDir = [];
        end
        clear Sy v;

     end
    
    infos.newRank = cumsum(infos.newRank);

end