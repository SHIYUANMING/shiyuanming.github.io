function L = l2_loss(x)
    L = max(0, 1-x)^2;
end
 