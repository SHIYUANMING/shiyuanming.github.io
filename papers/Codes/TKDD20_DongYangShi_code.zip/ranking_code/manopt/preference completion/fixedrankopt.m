function X_est = fixedrankopt(Y, X, r,user, item_1, item_2)
% input: 
%        Y:  Y_ijk ��{1,-1}:(i,j,k)�� ��
%        X:  the score matrix of user i rating item j
    
    n_train = size(user,1);
    [d1,d2] = size(X);A =  rand(d1,d2);
%     [f_lost,g_lost] = get_func();
    problem.M = fixedrankfactory_2factors(d1, d2, r);
    % Cost evaluation
    problem.cost = @cost;
    function [f, store] = cost(X, store)
            f = 0;
            for z = 1:n_train,
                i = user(z);
                j = item_1(z);
                k = item_2(z);
                YdeltaX = Y(i,j,k) * (X.L(i,:) * X.R(j,:)' - X.L(i,:) * X.R(k,:)');
%                 f = f + f_lost(YdeltaX);
                
               
            end
            f =  .5*norm(X.L*X.R' -A, 'fro')^2;
    end
        
   
    problem.egrad = @egrad;
    function g = egrad(X)
            g0 = zeros(d1,d2);
            for z = 1:n_train,
                i = user(z);
                j = item_1(z);
                k = item_2(z);
                YdeltaX = Y(i,j,k) * (X.L(i,:) * X.R(j,:)' - X.L(i,:) * X.R(k,:)');   
%                 g0= g0 + g_lost(YdeltaX) * Y(i,j,k)* sparse([i,i],[j,k],[1,-1],d1,d2);
        g0= g0 + Y(i,j,k)* sparse([i,i],[j,k],[1,-1],d1,d2);
      
            end
%               g.L =g0*X.R;
%               g.R =  g0'*X.L;
                P = (X.L*X.R' - A);
        g.L = P*X.R;        
        g.R = P'*X.L;

 end
    
    % Hessian evaluation
   problem.ehess = @ehess;
    function Hess= ehess(X,eta)
            Hess.L = zeros(d1,r);
            Hess.R = zeros(d2,r);
            for z = 1:n_train,
                i = user(z);
                j = item_1(z);
                k = item_2(z);
                L = X.L;
                R = X.R;

                YdeltaX = Y(i,j,k) * (L(i,:) * R(j,:)' - L(i,:) * R(k,:)');   
                M =  sparse([i,i],[j,k],[1,-1],d1,d2);
%                 gradLL_UL =( M * R * exp(YdeltaX)  * (eta.L(i,:) *( R(j,:)-R(k,:))'))/(exp(YdeltaX) + 1)^2;
%                  
%                gradLR_UR = (-Y(i,j,k) * M * eta.R * (exp(YdeltaX)+1)+M * R * exp(YdeltaX) *( L(i,:)*(eta.R(j,:)-eta.R(k,:))'))/(exp(YdeltaX) + 1)^2;
%               
%                 Hess.L =  Hess.L + gradLL_UL + gradLR_UR;
%                
%                
%                gradRL_UL = (-Y(i,j,k) * M' * eta.L * (exp(YdeltaX)+1)+ M' * L * exp(YdeltaX)*  (eta.L(i,:) * ( R(j,:)-R(k,:))'))/(exp(YdeltaX) + 1)^2;
%                
%                gradRR_UR = (M' * L * exp(YdeltaX) *( L(i,:)*(eta.R(j,:)-eta.R(k,:))'))/(exp(YdeltaX) + 1)^2; 
%                 
%                 Hess.R =  Hess.R + gradRL_UL + gradRR_UR;
%                 
                gradLL_UL =0;
                 
               gradLR_UR = Y(i,j,k) * M * eta.R ;
              
              
               
               gradRL_UL = Y(i,j,k) * M' * eta.L;
               
               gradRR_UR = (M' * L * exp(YdeltaX) *( L(i,:)*(eta.R(j,:)-eta.R(k,:))'))/(exp(YdeltaX) + 1)^2; 
                
               
            end
          P = (X.L*X.R' - A);
        Pdot = (eta.L*X.R' + X.L*eta.R');
        Hess.L = Pdot*X.R + P*eta.R;
        Hess.R = Pdot'*X.L + P'*eta.L;

      
    end

    figure;
    checkgradient(problem);

    figure;
    checkhessian(problem);
%     
    
    X0.L = rand(d1,r);
    X0.R = rand(d2,r);

    
    % Minimize the cost function using Riemannian trust-regions, starting
    % from the initial guess X0.
    %X_opt = trustregions(problem, X0);
     options.stopfun = @mystopfun;
    function stopnow = mystopfun(problem, Y, info, last) %#ok<INUSL>
        stopnow = (last >= 5 && (info(last-2).cost - info(last).cost < 1e-5 || abs(info(last-2).cost - info(last).cost)/info(last).cost < 1e-5));
    end
    
    
    
    % Call appropriate algorithm
    %options.solver = @trustregions;
    options.solver  = @conjugategradient;
    X_opt = manoptsolve(problem, X0, options);
    
    % Minimize the cost function using Riemannian trust-regions, starting
    % from the initial guess X0.
    %X_opt = trustregions(problem, X0);
    
    % The reconstructed matrix is X, represented as a structure with fields
    % U, S and V.
    X_est = X_opt.L * X_opt.R';
    f = 0;
    for m = 1:n_train,
        i = user(m);
        j = item_1(m);
        k = item_2(m);
        YdeltaX = Y(i,j,k) * (X_est(i,j) - X_est(i,k));
%         f = f + f_lost(YdeltaX); 
         f = f + YdeltaX;
    end
    fprintf('the objective function is %d\n',f);
    
end
%%
% function [f,g] = get_func()
%         f = @(x)log(1+exp(-x)); g = @(x)-1/(1+exp(x)); 
% end
