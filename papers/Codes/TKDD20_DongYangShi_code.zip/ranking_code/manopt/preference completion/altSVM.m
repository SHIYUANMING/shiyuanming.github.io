function [U,V] = altSVM(X,Y,user,item_1,item_2,lamda)

    [U,D,V] = svd(X);
    [row,~] = find(D>1e-5);
    r = max(row);
    U = U(:,1:r) * D(1:r,1:r);
    V = V(:,1:r);
    %the number of train set
    n_train = size(user,1);
    alpha = zeros(n_train);
    beta = zeros(n_train);
    f_old = object_fun(Y,U,V,user,item_1,item_2,lamda,n_train);
    iter = 0;
 while(1) 
     iter = iter + 1;
     fprintf('<< iteration: %d<<,  objective function: %d\n',iter,f_old);
    for z = 1:n_train,
        i = user(z);
        j = item_1(z);
        k = item_2(z);
        d = beta(z) * Y(i,j,k) * user(j);
        V(j,:) = V(j,:) + d;
        V(k,:) = V(k,:) - d;
    end
   % update V
    n_thread = 2;
%    parpool(n_thread)
  
   for n_update = 1:n_train,
         id = randi([1 n_train]);
         i = user(id);
         j = item_1(id);
         k = item_2(id);
         % generate delta
   
         d = V(j,:) - V(k,:);
         a = U(i,:) * U(i,:)';
         b = Y(i,j,k) * U(i,:) * d';         
         delta = minloss(beta(id),2 * a,b, lamda);
         beta(id) = beta(id) + delta;
         d = delta * Y(i,j,k) * U(i,:);
         V(j,:) = V(j,:) + d;
         V(k,:) = V(k,:) - d; 
   end
 
   
    %set U
 
    for z = 1:n_train,
        i = user(z);
        j = item_1(z);
        k = item_2(z);
        U(i,:) = alpha(z) * Y(i,j,k) * (V(j,:) - V(k,:)); 
    end
    %update U
   % spmd(n_thread)
    for n_update = 1:n_train,
         id = randi([1 n_train]);
         i = user(id);
         j = item_1(id);
         k = item_2(id);
         % generate delta
         d = V(j,:) - V(k,:);
         a = d * d';
         b = Y(i,j,k) * U(i,:) * d';         
         delta = minloss(beta(id),a,b, lamda);
         alpha(id) = alpha(id) + delta;
         d = delta * Y(i,j,k) *  (V(j,:) - V(k,:));
         U(i,:) = U(i,:) + d;
    end
   % end
    % check whether converge
    f = object_fun(Y,U,V,user,item_1,item_2,lamda,n_train);
    if (f_old - f)/f_old <1e-5
        fprintf('converged,end');
        break
    end
    f_old =  f;
 end

end