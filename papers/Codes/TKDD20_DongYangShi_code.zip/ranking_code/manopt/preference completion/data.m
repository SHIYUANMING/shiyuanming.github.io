d1 = 10;  %number of user
d2 = 4;   %number of item
% simple data to test
I = [1 1 2 2 3 3 4 4 5 5 6 6 7 7 8 8 9 9 10 10];
J = [1 2 3 4 1 3 2 3 1 4 2 4 2 3 1 4 3 2 3 1 ];
val=[5 4 2 3 4 1 5 3 4 2 4 5 5 1 2 1 3 5 2 3 ];
X = sparse(I,J,val,d1,d2);
%data from MovieLens
%load testdata
% subsample N rating for each user and drop users with less than N + 10
% N = 20;
% for i = 1:d1,
%     fprintf('%d\n',i);
%     rate = find(X(i,:)~=0);
%     n = length(rate);
%     if n < N + 10,
%         X(i,:) = 0;
%     else
%         id = randperm(n,n-20);
%         X(i,rate(id)) = 0;
%     end
%     
% end
X = full(X);
[U,D,V] = svd(X);
[row,col] = find(D>1e-5);
r = max(row);


%  Y:  [d1]*[d2]*[d2]
Y = [];
[xi,xj] = find(X>0);
xi = unique(xi);
for m =1:length(xi),
   k = xi(m); 
   idx =  find(X(k,:)>0);
   for i = 1:length(idx)-1,
        for j = i+1:length(idx), 
            %fprintf('k = %d,i =%d,j = %d\n',k,i,j);
            if X(k,idx(i)) > X(k,idx(j))% && idx(i)<idx(j)
                Y(k,idx(i),idx(j)) = 1;
                
         elseif X(k,idx(i)) < X(k,idx(j)) % && idx(i)<idx(j)
                Y(k,idx(i),idx(j)) = -1;
                

            end
          
        end
    end
end
user =[];
item_1 =[];
item_2 =[];
[~,~,z_Y] = size(Y); % z_Y is the number of trained pair.
for i = 1:z_Y,
    [row,col] = find(Y(:,:,i)~=0);
    
    user = [user ;row];
    item_1 = [item_1; col];
    item_2 = [item_2 ; i * ones(length(row),1)];
    
end

%[U_est,V_est] = altSVM(X,Y,user,item_1,item_2,r);
% user = Y_obs(:,1);
% item_1= Y_obs(:,2);
% item_2 = Y_obs(:,3);
% Y = zeros(8,8,2);
% for z = 1:35,
%      i = user(z);
%     j = item_1(z);
%     k = item_2(z);
%     Y(i,j,k)  = Y_obs(z,4);
% end
X_est = fixedrankopt(Y,X, r,user, item_1, item_2);

%X_est = U_est * V_est'; 