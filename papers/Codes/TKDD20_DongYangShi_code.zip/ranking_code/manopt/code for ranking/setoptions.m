function params = setoptions(options,lambda)
 params = options;
 params.lambda = lambda;
end