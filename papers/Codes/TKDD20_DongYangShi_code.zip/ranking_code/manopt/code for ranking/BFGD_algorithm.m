function [Xopt,infos] = BFGD_algorithm(r, omega, S, Xs, params)
% This function recovers the algorithm proposed in
% Park, Dohyung, et al. "Finding Low-rank Solutions to Matrix Problems, Efficiently and Provably." 
% arXiv preprint arXiv:1606.03168 (2016).
% It solves min f(X) s.t. rank(X)<=r with factorization
% This code is created by Kai Yang, Sep. 03, 2016.

if ~isfield(params,'rho'); params.rho = 1e-2; end; 
if ~isfield(params,'eps'); params.eps = 1e-1; end; 
if ~isfield(params,'maxiter'); params.maxiter = 1e5; end; 
if ~isfield(params,'verbosity'); params.verbosity = 2; end; 
lambda = params.lambda;
%params.deltacosttol = params.deltacosttol/r^2;
K = size(omega,1); m = S; n = S;

[f_lost,g_lost] = get_func('logistic');

problem.cost = @cost;
    function f = cost(X)
        Xmat = X.L*X.R';
        index = 1:K;
        A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],n,K);
        M = Xmat * A;
        mask = sparse(omega(:,1),index,1,n,K);
        M = M(mask==1);
        YdeltaX = omega(:,4).* M;
        f = sum(f_lost(YdeltaX))+lambda*0.5*norm(Xmat,'fro')^2;
    end
problem.grad = @BF_grad;
    function g = BF_grad(X)
        Xmat = X.L*X.R';
        index = 1:K;
        A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],n,K);
        M = Xmat * A;
        mask = sparse(omega(:,1),index,1,n,K);
        M = M(mask==1);
        YdeltaX = omega(:,4).* M;
        gx = g_lost(YdeltaX).* omega(:,4);
        G = sparse([omega(:,1) omega(:,1)],[omega(:,2) omega(:,3)],[gx -gx],m,n)+lambda*Xmat;
        g.G = full(G);
        g.L= G*X.R;
        g.R = G'*X.L;
    end


problem.Lip=1;

%% my stopping criteron
params.stopfun = @mystopfun1;
function y=mystopfun1(infos,this,last)
    if last
        thiscost = infos(this).obj;
        lastcost = infos(last).obj;
        y = (abs(thiscost-lastcost)<params.deltacosttol);
    else
        y=0;
    end

end
if isempty(Xs)
    X0.L=randn(m,r)/sqrt(m); X0.R=randn(n,r)/sqrt(n);
else
    X0.L=Xs{1}; X0.R=Xs{2};
end

[Xout,~,infos] = BFGD_smooth(problem, S, r, X0, params);
Xopt = Xout.L*Xout.R';
end
function [f,g] = get_func(fun)
    if strcmp(fun,'logistic')
        f = @(x)log(1+exp(-x)); g = @(x)-1./(1+exp(x));
    end
end