function [Xcg,infos] = ranking_nonconvex( r, omega, m,n, X_in, options )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
if ~isfield(options,'fun'); options.fun='logistic'; end
if ~isfield(options,'verbosity'); options.verbosity=1; end
if ~isfield(options,'norm'); options.norm='fro'; end
tol=options.deltacosttol;
verb = options.verbosity;
mynorm = options.norm;

lambda = 1;
K = size(omega,1);
f_lost = get_func(options.fun);
U0 = randn(m,r); V0 = randn(n,r);err=1;
if isempty(X_in)
   U0=randn(m,r)/sqrt(m);V0=randn(n,r)/sqrt(n);
else
   U0=X_in{1};V0=X_in{2};
end
f=@(U,V)cost(f_lost,omega,K,U,V);
cost_func = @(U,V)f(U,V)+lambda/2*(norm(U,'fro')^2+norm(V,'fro')^2);
iter = 0;  infos.obj = cost_func(U0,V0);
while(err>tol && iter<=10)
    iter = iter+1;
    
    cvx_begin quiet
    cvx_expert true
    variable U(m,r)
    minimize f(U,V0)+lambda/2*norm(U,'fro')^2
    cvx_end
    
    cvx_begin quiet
    cvx_expert true
    variable V(n,r)
    minimize f(U,V)+lambda/2*norm(V,'fro')^2
    cvx_end
    
    obj = cost_func(U,V);
    err = abs(obj - infos.obj(end));
    infos.obj = [infos.obj; obj];
    if verb
        fprintf('Iter: %.2d, Err: %7.6e obj:%7.6e \n', iter, err, obj);
    end
end

Xcg = U*V';
end
function f = cost(f_lost,omega,K,U,V)
    X =  U * V';
    [~,nx] = size(X);
    index = 1:K;
    A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],nx,K);
    M = X * A;
    mask = sparse(omega(:,1),index,1,nx,K);
    M = M(mask==1);
    YdeltaX = omega(:,4).* M;
      
       
    L = f_lost(YdeltaX);
    f = sum(L);
%         f= 0;
%     for kk = 1:K
%         i = omega(kk,1); j = omega(kk,2); k = omega(kk,3); y = omega(kk,4);
%         f = f + f_lost(y*U(i,:)*(V(j,:)'-V(k,:)'));
%     end
end
    
function f = get_func(fun)
    if strcmp(fun,'logistic')
       f = @(x)log(1+exp(-x));
    end
end