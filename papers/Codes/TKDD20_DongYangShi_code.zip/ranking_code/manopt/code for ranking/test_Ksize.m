%% main.m
%warning off
clear;clc; randn('seed',1); rand('seed',1);
addpath('./func');

r = 5; K=100;
per = 0.001:0.001:0.01;
all_num = K*(K-1)/2;
obs_num_set = round(per*all_num);
obs_num_len = length(per);
options.verbosity = 0;
options.tolgradnorm = 0;
options.maxiter = 500;
options.lambda = 1e-3;
options.deltacosttol = 1e-8;
options.norm = 'fro';

params = options;
%params.maxiter = 1e3;

testnum=25;
myresults1 = zeros(obs_num_len,testnum);
myresults2 = zeros(obs_num_len,testnum);
myresults3 = zeros(obs_num_len,testnum);
myresults4 = zeros(obs_num_len,testnum);
myt1 = zeros(obs_num_len,testnum);
myt2 = zeros(obs_num_len,testnum);
myt3 = zeros(obs_num_len,testnum);
myt4 = zeros(obs_num_len,testnum);
alltime=tic;
parfor test = 1:testnum
    results1 = zeros(obs_num_len,1);
    results2 = zeros(obs_num_len,1);
    results3 = zeros(obs_num_len,1);
    results4 = zeros(obs_num_len,1);
    t1 = zeros(obs_num_len,1);
    t2 = zeros(obs_num_len,1);
    t3 = zeros(obs_num_len,1);
    t4 = zeros(obs_num_len,1);
    for j = 1:obs_num_len
        [X,Y] = gen_data(K,K,r);
        obs_num = obs_num_set(j);
        [Y_obs,Y_test] = gen_obs(X,Y,obs_num);

        XL = randn(K,r)/sqrt(K); XR = randn(K,r)/sqrt(K);
        ts=tic;
        [Xcg1,~,infos_rm] = ranking_fixedrankCG(r, Y_obs, K ,K,{XL,XR},options);
        X1 = Xcg1.L*Xcg1.R';
        results1(j) = predicting_error(X1,Y_test);
        t1(j) = toc(ts);

%         ts=tic;
%         X2 = ranking_convex_relaxation( r, Y_obs, K ,K, [], options );
%         results2(j) = predicting_error(X2,Y_test);
%         t2(j) = toc(ts);

        ts = tic;
        X3=BFGD_algorithm(r, Y_obs,K, {XL,XR}, params);
        %X3 = ranking_nonconvex( r, Y_obs, K ,K, [], options );
        results3(j) = predicting_error(X3,Y_test);
        t3(j) = toc(ts);

        ts=tic;
        X4 = ranking_nonconvex( r, Y_obs, K ,K, [], options );
        results4(j) = predicting_error(X4,Y_test);
        t4(j) = toc(ts);

        %fprintf('testnum:%.3d, K:%.5d, obs_num:%d,  TR:%.3f, convex:%.3f, BFGD:%.3f, altmin:%.3f; time: %d, %d, %d, %d \n',test,K,obs_num,results1(j),results2(j),results3(j),results4(j),t1(j),t2(j),t3(j),t4(j));
        fprintf('testnum:%.3d, K:%.5d, obs_num:%d,  TR:%.3f, BFGD:%.3f, AltMin:%.3f; time: %d, %d, %d\n',test,K,obs_num,results1(j),results3(j),results4(j),t1(j),t3(j),t4(j));
        %fprintf('testnum:%.3d, K:%.5d, obs_num:%d,  TR:%.3f, convex:%.3f, altmin:%.3f; time: %d, %d, %d \n',test,K,obs_num,results1(j),results2(j),results3(j),t1(j),t2(j),t3(j));
    end
    myresults1(:,test) = results1;
%     myresults2(:,test) = results2;
    myresults3(:,test) = results3;
    myresults4(:,test) = results4;
    myt1(:,test) = t1;
%     myt2(:,test) = t2;
    myt3(:,test) = t3;
    myt4(:,test) = t4;
end
alltime=toc(alltime);
%save('CG_convex_Altmin5-10.mat');

aver1 = mean(myresults1,2);
% aver2 = mean(myresults2,2);
aver3 = mean(myresults3,2);
aver4 = mean(myresults4,2);
figure, plot(obs_num_set,aver1,'r-d','LineWidth',1.2, 'MarkerSize',6);hold on
% plot(obs_num_set,aver2,'k.-','LineWidth',1.2, 'MarkerSize',6);
plot(obs_num_set,aver3,'b-o','LineWidth',1.2, 'MarkerSize',6);
plot(obs_num_set,aver4,'-s','Color', [0.5 0 0.5],'LineWidth',1.2, 'MarkerSize',6);hold off;
legend('CG','BFGD','AltMin');
xlabel('Observed Comparison Num');
ylabel('Test error');
title(['lambda=' num2str(options.lambda)]);
axis tight