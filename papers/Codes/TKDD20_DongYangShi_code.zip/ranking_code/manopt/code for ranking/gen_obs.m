function [Y_obs,Y_test] = gen_obs(X,Y,obs_num_per_user)
[m,n] = size(X);
all_num = (n^2-n)/2;
datay = size(Y,2);
Y_obs = zeros(m*obs_num_per_user,datay);
Y_test = zeros(m*(all_num-obs_num_per_user),datay);
for i=1:m
    obs = randperm(all_num,obs_num_per_user);
    test = setdiff(1:all_num,obs);
    Y_obs((i-1)*obs_num_per_user+1:i*obs_num_per_user,:) = Y((i-1)*all_num+obs,:);
    Y_test((i-1)*(all_num-obs_num_per_user)+1:i*(all_num-obs_num_per_user),:) = Y((i-1)*all_num+test,:);
end