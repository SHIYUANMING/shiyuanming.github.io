function optcost = findoptcost(X,omega,lambda)
f_lost = @(x)log(1+exp(-x));
K = size(omega,1);
[m,n] = size(X);
index = 1:K;
A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],n,K);
M = X * A;
mask = sparse(omega(:,1),index,1,n,K);
M = M(mask==1);
YdeltaX = omega(:,4).* M;
optcost = sum(f_lost(YdeltaX))+lambda*0.5*norm(X,'fro')^2;
end

