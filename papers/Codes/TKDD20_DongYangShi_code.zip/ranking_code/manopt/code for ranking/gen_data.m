function [X,Y] = gen_data(m,n,r)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
%X = randi(5,[m,n]);
X = randn(m,n);
[u,s,v] = svds(X,r);
X = u*s*v';

all_num = m*(n^2-n)/2;
Y = zeros(all_num,4);
t = 0 ;
for i = 1:m
    for j = 1:n
        for k = j+1:n
            t = t+1;
            Y(t,:)=[i,j,k,2*(X(i,j)>X(i,k))-1];
        end
    end
end
end

