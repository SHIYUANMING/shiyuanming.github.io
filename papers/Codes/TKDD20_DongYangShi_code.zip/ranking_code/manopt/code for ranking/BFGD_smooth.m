function [Xout,xcost,infos] = BFGD_smooth(problem, K, r, X0, params)
% This function recovers the algorithm proposed in
% Park, Dohyung, et al. "Finding Low-rank Solutions to Matrix Problems, Efficiently and Provably." 
% arXiv preprint arXiv:1606.03168 (2016).
% It solves min f(X) s.t. rank(X)<=r with factorization
% This function is suitable for gradient-smooth functions, i.e. Lipschiz
% continuity with L.  ||grad(X1)-grad(X2)||<=L*|X1-X2|. It can ensure
% sub-linear convergence rate (with assumptions) in the paper.
% This code is created by Kai Yang, Sep. 03, 2016.
m=K;
n=K;

%% Initialization

% tmp = norm(X0.U*X0.V','fro');
% X0.U = X0.U/sqrt(tmp);
% X0.V = X0.V/sqrt(tmp);



%% Gradient descend
if isempty(X0)
    X0.L = randn(m,r)/sqrt(m);
    X0.R = randn(n,r)/sqrt(n);
end

if ~isfield(params,'maxiter'); params.maxiter = 1000;end
if ~isfield(params,'gradnormtol'); params.gradnormtol = 1e-6;end
if ~isfield(params, 'verbosity'); params.verbosity = 1;end
if ~isfield(params, 'lambda'); params.lambda = 1;end
if ~isfield(params, 'deltacosttol'); params.deltacosttol = 1e-6;end

%% If mycost exists, we use our stopping criteron, else default
% function y = compute_my_cost(X)
%     y=norm( P.*(X.L*X.R')-M, 'fro')/sqrt(m);
% end

ticstart = tic();
[Xout,infos] = BFGD_iter(problem,X0,params);
    function [X,infos] = BFGD_iter(problem,X0,params)
        Lip = problem.Lip; f_cost = problem.cost; f_grad = problem.grad; 

        this_f_grad= f_grad(X0);
        eta0 = 1/(12*Lip*norm([X0.L;X0.R])^2+3*norm(this_f_grad.G));

        iter=0; obj = f_cost(X0); 
        gradnorm = norm(this_f_grad.G);
        deltacost = obj;

        maxiter = params.maxiter; verb = params.verbosity; lambda = params.lambda; deltacosttol=params.deltacosttol;
        stats = savestats([], iter,obj,gradnorm,eta0,ticstart);
        infos(1) = stats; 
        infos(min(1e5,maxiter+1)).iter=[];

        X=X0; X1=X0; last = 0;
        while(iter<=maxiter)
            % Start clock for this outer iteration
            ticstart = tic();
            
            eta = eta0;
            iter = iter+1;
            X0=X;
            
            
            X.L = X0.L-eta*this_f_grad.L;
            X.R = X0.R-eta*this_f_grad.R;
            deltacost = obj;
            obj = f_cost(X);
            deltacost = deltacost - obj;
            
            this_f_grad = f_grad(X);
            gradnorm = norm(this_f_grad.G);
            stats = savestats(infos, iter,obj,gradnorm,eta,ticstart);
            infos(iter+1) = stats;
            if mod(iter,5)
                if params.stopfun(infos,iter,last)
                    break;
                end
                X1 = X0;
                last = iter;
            end
            if verb
                fprintf('Iter=%3d, obj=%.4e, gradnorm=%.4e, deltacost=%.4e \n',iter,obj,gradnorm, deltacost);
            end
        end
    end
infos = infos(1:iter+1);
xcost = [infos.obj];
xcost = xcost(end);
end

function stats = savestats(info,iter,obj,gradnorm,eta,ticstart)
    if iter==0
        stats.time = toc(ticstart);
    else
        stats.time = info(iter).time + toc(ticstart);
    end
    stats.iter = iter;
    stats.obj = obj;
    stats.gradnorm = gradnorm;
    stats.eta = eta;
end
