%% main.m
%warning off
clear;clc; randn('seed',1); rand('seed',1);
addpath('./func');

r = 5; K=100;
per = 0.1;
all_num = K*(K-1)/2;
obs_num = round(per*all_num);
options.verbosity = 2;
options.tolgradnorm = 0;
options.maxiter = 500;
options.lambda = 1e-3;
options.deltacosttol = 1e-8;
options.norm = 'fro';
params = options;


[X,Y] = gen_data(K,K,r);

[Y_obs,Y_test] = gen_obs(X,Y,obs_num);

XL = randn(K,r)/sqrt(K); XR = randn(K,r)/sqrt(K);

[Xcg1,~,infos_cg] = ranking_fixedrankTR2(r, Y_obs, K ,K,{XL,XR},options);
X1 = Xcg1.L*Xcg1.R';
result1 = predicting_error(X1,Y_test);

[X3,infos_BFGD]=BFGD_algorithm(r, Y_obs,K, {XL,XR}, params);
result2 = predicting_error(X3,Y_test);

% X4 = ranking_nonconvex( r, Y_obs, K ,K, [], options );
% result4 = predicting_error(X4,Y_test);

%fprintf('testnum:%.3d, K:%.5d, obs_num:%d,  TR:%.3f, convex:%.3f, BFGD:%.3f, altmin:%.3f; time: %d, %d, %d, %d \n',test,K,obs_num,results1(j),results2(j),results3(j),results4(j),t1(j),t2(j),t3(j),t4(j));
fprintf('K:%.5d, obs_num:%d,  TR:%.3f, BFGD:%.3f\n',K,obs_num,result1,result2);

time1 = [infos_cg.time]; time2 = [infos_BFGD.time]; 
cost1 = [infos_cg.cost]; cost2 = [infos_BFGD.obj]; 

yL = floor(cost1(end));
yR = cost2(1);
tR = 10*ceil(time1(end)/10);

figure, plot(time1,cost1,'r-d','LineWidth',1.2, 'MarkerSize',3);hold on

plot(time2,cost2,'b-o','LineWidth',1.2, 'MarkerSize',3);

legend('CG','BFGD');
xlabel('Time/s');
ylabel('Cost');
title('Convergence Rate');
ylim([yL,yR]);
xlim([0,tR]);