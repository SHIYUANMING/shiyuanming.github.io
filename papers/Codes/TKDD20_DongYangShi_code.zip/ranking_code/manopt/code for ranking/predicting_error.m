function result = predicting_error(X,Y)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
K = size(Y,1);
t = 0;
for k = 1:K
    t = t + ((X(Y(k,1),Y(k,2))-X(Y(k,1),Y(k,3)))*Y(k,4)>0);
end
result = t/K;
end

