%function [Xcg, xcost]=RiemOpt_fixedrank(K,r, P, X0)
function [Xcg, xcost, info, options]=ranking_fixedrankCG(r, omega, m,n, X_in, options)
if ~isfield(options,'tolgradnorm'); options.gradtol=1e-6; end
if ~isfield(options,'verbosity'); options.verbosity=1; end 
if ~isfield(options,'fun'); options.fun='logistic'; end
lambda = options.lambda;
K = size(omega,1);
%user i preferes item j over item k then Y_{ijk}=1
%user i preferes item k over item j then Y_{ijk}=-1
[f_lost,g_lost,h_lost] = get_func(options.fun);
       if isempty(X_in)
           X0.L=randn(m,r)/sqrt(m);X0.R=randn(n,r)/sqrt(n);
       else
           X0.L=X_in{1};X0.R=X_in{2};
       end
    %% Pick the manifold of matrices of size mxn of fixed rank r.
       problem.M = fixedrankfactory_2factors_preconditioned(m,n, r);

    %% Define the problem cost function f(X) = 1/2 * || P.*(X-A) ||^2
    problem.cost = @cost;  % The input X is a structure with fields U, S, V representing a rank k matrix as U*S*V'.
    function [f,store] = cost(X,store)
        if ~isfield(store,'Xmat')
            store.Xmat = X.L*X.R';
        end
        Xmat = store.Xmat;
       if ~isfield(store,'YdeltaX')
        index = 1:K;
        A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],n,K);
        M = Xmat * A;
        mask = sparse(omega(:,1),index,1,n,K);
        M = M(mask==1);
        store.YdeltaX = omega(:,4).* M;
       end
        YdeltaX = store.YdeltaX;
        L = f_lost(YdeltaX);
        f = sum(L)+lambda*0.5*norm(Xmat,'fro')^2;
end

    %% Define the Euclidean gradient of the cost function nabla f(X) = P.*(X-A)
    problem.egrad = @egrad;
    function [g,store] = egrad(X,store)
        % Same comment here about Xmat.
       if ~isfield(store,'Xmat')
            store.Xmat = X.L*X.R';
       end
       Xmat = store.Xmat;

       if ~isfield(store,'YdeltaX')
        index = 1:K;
        A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],n,K);
        M = Xmat * A;
        mask = sparse(omega(:,1),index,1,n,K);
        M = M(mask==1);
        store.YdeltaX = omega(:,4).* M;
       end
        YdeltaX = store.YdeltaX;
        gx = g_lost(YdeltaX).* omega(:,4);
        G = sparse([omega(:,1) omega(:,1)],[omega(:,2) omega(:,3)],[gx -gx],m,n)+lambda*Xmat; 
        g.L= G*X.R;
        g.R = G'*X.L;
    end

%     problem.ehess = @ehess;
%     function [Hess,store] = ehess(X, eta,store)
%         if ~isfield(store,'YdeltaX')
%         Xmat = X.L*X.R';
%         index = 1:K;
%         A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],n,K);
%         M = Xmat * A;
%         mask = sparse(omega(:,1),index,1,n,K);
%         M = M(mask==1);
%         store.YdeltaX = omega(:,4).* M;
%        end
%         YdeltaX = store.YdeltaX;
%         gx = g_lost(YdeltaX).* omega(:,4);
%         G = sparse([omega(:,1) omega(:,1)],[omega(:,2) omega(:,3)],[gx -gx],m,n); 
%         etalx = eta.L*X.R';
%         etarx = X.L*eta.R';
%         tmp = etalx-etarx;
% 
%         index = 1:K;
%         mask = sparse(omega(:,1),index,1,n,K);
%         hx = h_lost(YdeltaX);
%         
%         Pdot = sparse([omega(:,1) omega(:,1)],[omega(:,2) omega(:,3)],[hx hx],m,n); 
%         Pdot = Pdot.*tmp;
%         Hess.L = G* eta.R + Pdot*X.R;
%         Hess.R = G'* eta.L + Pdot'*X.L; 
%     end



%     %% Define the Euclidean Hess  
%     problem.ehess = @ehess;
%     function Hess = ehess(X, eta)
%         Xmat = X.L*X.R';
%         G= zeros(m,n);
%         for kk = 1:K
%             i = omega(kk,1); j = omega(kk,2); k = omega(kk,3); y = omega(kk,4);
%             G(i,j) = G(i,j) + g_lost(y*(Xmat(i,j)-Xmat(i,k)))*y;
%             G(i,k) = G(i,k) - g_lost(y*(Xmat(i,j)-Xmat(i,k)))*y;
%         end
%         Pdot= zeros(m,n);
%         for kk = 1:K
%             i = omega(kk,1); j = omega(kk,2); k = omega(kk,3); y = omega(kk,4);
%             G(i,j) = G(i,j) + f_lost(y*(eta.L(i,:) * X.R(j,:)' -  X.L(i,:) * eta.R(k,:)'))*y;
%             G(i,k) = G(i,k) - g_lost(y*(Xmat(i,j)-Xmat(i,k)))*y;
%         end        
%         
%         Pdot  = P.*(eta.L*X.R' + X.L*eta.R');
%         
%         Hess.L = G* eta.R + Pdot*X.R;
%         Hess.R = G'* eta.L + Pdot'*X.L;
%         
%     end
    
%       checkhessian(problem);
    options.stopfun = @mystopfun;
    function y=mystopfun(problem, X, infos, last)
        if last&&(~mod(last,5))
            thiscost = infos(end).cost;
            lastcost = infos(end-5).cost;
            y = (abs(thiscost-lastcost)<options.deltacosttol)|(abs(thiscost-lastcost)/lastcost<options.deltacosttol);
        else
            y=0;
        end
    end
%     options.statsfun = @mystats;
%     function stats = mystats(problem, x, stats,store)
%         if ~isfield(store,'Xmat')
%             store.Xmat = X.L*X.R';
%         end
%         pre_err = predicting_error(store.Xmat,omega);
%         stats.pre_err = pre_err;        
%     end
    %% Notice that for this solver, the Hessian is not needed.
       [Xcg, xcost, info, options] = conjugategradient(problem, X0, options);
       
end
function [f,g,h] = get_func(fun)
    if strcmp(fun,'logistic')
        f = @(x)log(1+exp(-x)); g = @(x)-1./(1+exp(x)); h = @(x)exp(x)./(1+exp(x)).^2;
    end
end