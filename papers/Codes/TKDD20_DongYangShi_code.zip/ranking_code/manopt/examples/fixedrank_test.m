function fixedrank_test()
 
% Generate the problem data. 
 
% Problem
m = 100;
n = 100;
k = 5;
A = randn(m, k)* randn(k ,m);
 
% We aim for a rank k approximation of A

 
% Create the problem structure.
manifold =productmanifold(struct('L', euclideanfactory(m,k),'R', euclideanfactory(n,k)));
problem.M =manifold; %fixedrankfactory_2factors(m,n,k);
 
% Define the problem cost function and its gradient.
 
problem.cost = @cost;
    function f = cost(X)
        f = .5*norm(X.L*X.R' - A, 'fro')^2;
    end
 
problem.grad = @(X) problem.M.egrad2rgrad(X, egrad(X)); 
    function g = egrad(X)
        P = (X.L*X.R' - A);
        g.L = P*X.R;        
        g.R = P'*X.L;
    end
 
problem.hess = @(X, U) problem.M.ehess2rhess(X, egrad(X), ehess(X, U), U); 
    function Hess = ehess(X, eta)
        P = (X.L*X.R' - A);
        Pdot = (eta.L*X.R' + X.L*eta.R');
        Hess.L = Pdot*X.R + P*eta.R;
        Hess.R = Pdot'*X.L + P'*eta.L;
    end
 
 
% Numerically check the differentials.
% checkgradient(problem); pause;
% checkhessian(problem); pause;
 
X = trustregions(problem);
 norm(X.L*X.R'-A,'fro')
end