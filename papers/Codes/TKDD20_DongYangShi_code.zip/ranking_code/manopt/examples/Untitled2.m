X = rand(4,3);
H = rand(4,3);
xh = X*H' + H*X';
trace((xh*X)'*H)
0.5 * trace(xh'*xh)