function [Y infos] = gd_dist_completion(H,D_ob,Y,params)
% 
%
%   fun          function handle on the optimization algorithm
%                (trust region or gradient descent) 
%   H            n-by-n symmetric martix with binary entries 
%   D_ob         n-by-n matrix: Euclidean Distance Matric with noisy.
%   Y            m-by-p0 initial condition of rank p0
%   params       structure array containing algorithm parameters
              
%
% Output
%   Y            n-by-p final matrix of rank p
%   infos        structure array with additional information
%

% Original Authors:
% Bamdev Mishra and Gilles Meyer
% {b.mishra,g.meyer}@ulg.ac.be



% Problem size
n = size(Y,1);

% Data size
%m = length(knownDists);

% Collect parameters
%params = DefaultParams(params);

% Shortcut parameter names
maxiter = params.maxiter;
sig_A = params.sig_A;
ls_maxiter = params.ls_maxiter;
max_step = params.max_step;
tol = params.tol;
vtol = params.vtol;

% Compute initial cost
G = Y*Y';
e = ones(n,1);
K = diag(G)*e' + e*diag(G)' - 2*G;
errors = H.*(K - D_ob);                                
cost = norm(errors,'fro')^2;
fprintf('[%0.4d] cost = %g\n',0,cost);


infos.cost = zeros(maxiter+1,1);
infos.cost(1) = cost;
infos.sqnormgrad = [];
infos.linesearch = [];



% Loop through all iterations
for iter = 1 : maxiter,
  
    G = Y*Y';
    K = diag(G)*e' + e*diag(G)' - 2*G;
    errors = H.*(K - D_ob);                                
    
    % Compute gradient
    grad_Y = 2*2*(diag(errors * e) - errors)*Y;
    
    gradientNorm = norm(grad_Y,'fro')^2;
    infos.sqnormgrad = [infos.sqnormgrad ; gradientNorm];
  % adjust the stepsize according to former situation   
    if iter > 1,
         % Nocedal & Wright stepsize search
         % A factor of 2 is used to avoid slow covergence due to underestimation of stepsize 
         max_step = 2*stepSize * infos.sqnormgrad(end - 1) / gradientNorm;
        
        % Adaptive stepsize search as proposed by Mishra et al., arXiv:1209.0430
        % On an average we intend to perform only 2 linesearch per iteration.
        if s == 1,
            max_step = 2*max_step;
        elseif s >= 3,
            max_step = 2*stepSize;
        else % here s == 2,
            max_step = max_step; % Do nothing 
        end
        
    end
    
    % Perform line-search
    Yt = Y;
    stepSize = max_step;

    for s = 1 : ls_maxiter,
        
        % Update parameter
        Y = Yt - stepSize * grad_Y;
        G = Y*Y';
        e = ones(n,1);
        K = diag(G)*e' + e*diag(G)' - 2*G;
        errors = H.*(K - D_ob);                                
        newcost =norm(errors,'fro')^2;
        
        % Check Armijo condition
        armijo = (cost - newcost) >=  sig_A * stepSize * gradientNorm;
        if armijo,
            break;
        else
            stepSize = stepSize / 2;
        end
        
    end

    
    infos.cost(iter+1) = newcost;
    infos.linesearch= [infos.linesearch; s];
   % if verb,
        fprintf('[%0.4d] cost = %g, grad norm = %g, #linesearch = %g\n',iter,newcost,gradientNorm, s);
    %end
    
    % Stopping criterion
    if newcost < tol || (cost - newcost)/cost < vtol,
        break;
    end
    
    cost = newcost;
    
end


infos.cost = infos.cost(1:iter+1);
infos.iter = iter;

if iter >= maxiter,
    warning('MATLAB:MaxIterReached','Maximum number of iterations has been reached.');
end

end