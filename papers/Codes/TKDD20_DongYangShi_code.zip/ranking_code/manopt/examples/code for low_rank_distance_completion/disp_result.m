function disp_result(infos_gd, infos_tr,Y_gd,Y_tr,Yo)
fs = 10;
figure('name', 'Gradient descent');
line(1:length(infos_gd.cost),infos_gd.cost,'Color','r','LineWidth',2);
ax1 = gca;
set(ax1,'FontSize',fs);
xlabel(ax1,'Number of iterations','FontSize',fs);
ylabel(ax1,'Cost','FontSize',fs);
ax2 = axes('Position',get(ax1,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor','k');
set(ax2,'FontSize',fs);
line(1:length(infos_gd.cost),infos_gd.cost,'Color','r','LineWidth',2,'Parent',ax2);               
set(ax2,'XTick',infos_gd.newRank(1:end-1),...
        'XTickLabel',2:length(infos_gd.newRank-1),...
        'YTick',[]);
    
set(ax2,'XGrid','on');
title('Rank');
legend('Gradient descent');
legend 'boxoff';




% TR algorithm
fs=10;    
figure('name', 'Trust-region');

line(1:length(infos_tr.cost),infos_tr.cost,'Marker','*','LineStyle','--','Color','blue','LineWidth',1.5);
ax1 = gca;

set(ax1,'FontSize',fs);
xlabel(ax1,'Number of iterations','FontSize',fs);
ylabel(ax1,'Cost','FontSize',fs);

ax2 = axes('Position',get(ax1,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor','k');
       
set(ax2,'FontSize',fs);
line(1:length(infos_tr.cost),infos_tr.cost,'Marker','*','LineStyle','--','Color','blue','LineWidth',1.5,'Parent',ax2);
set(ax2,'XTick',infos_tr.newRank(1:end-1),...
        'XTickLabel',2:length(infos_tr.newRank-1),...
        'YTick',[]);
    
set(ax2,'XGrid','on');
%xlabel(ax2,'rank','FontSize',fs);
title('Rank');
legend('Trust-region');
legend 'boxoff';

% Projecting onto the 3D subspace to visualize  
rhat_gd = size(Y_gd, 2);
rhat_tr = size(Y_tr, 2);
[~,m1] = size(Y_gd);
[~,m2] = size(Y_tr);
m = min(m1,m2);
for i = 1:m,
 if sign(Y_gd(1,i))~=sign(Y_tr(1,i)),
     Y_gd(:,i) = -Y_gd(:,i);
 end
end
Yhat_gd = Y_gd;
Yhat_tr = Y_tr;

if rhat_gd > 3, % we need to project onto the 3D dominant subspace
    [U1, S1, V1] = svds(Y_gd, 3);
    Yhat_gd = U1*S1*V1';
end
    
if rhat_tr > 3, % we need to project onto the 3D dominant subspace
    [U2, S2, V2] = svds(Y_tr, 3);
    Yhat_tr = U2*S2*V2';
end


% Plot 3D structure given by GD
figure('name','3D structure of GD')
fs=10;
ax1 = gca;
set(ax1,'FontSize',fs);
plot3(Yhat_gd(:,1), Yhat_gd(:,2), Yhat_gd(:,3),'*','Color', 'r','LineWidth',1.0);
xlabel(ax1,'X axis','FontSize',fs);
ylabel(ax1,'Y axis','FontSize',fs);
zlabel(ax1,'Z axis','Fontsize',fs);
legend('GD')


% Plot 3D structure given by TR
figure('name','3D structure of TR')
fs=10;
ax1 = gca;
set(ax1,'FontSize',fs);
plot3(Yhat_tr(:,1), Yhat_tr(:,2), Yhat_tr(:,3),'*','Color', 'b','LineWidth',1.0);
xlabel(ax1,'X axis','FontSize',fs);
ylabel(ax1,'Y axis','FontSize',fs);
zlabel(ax1,'Z axis','Fontsize',fs);
legend('TR')

figure('name','3D structure of orginal')
fs=10;
ax1 = gca;
set(ax1,'FontSize',fs);
plot3(Yo(:,1), Yo(:,2), Yo(:,3),'*','Color', 'r','LineWidth',1.0);
xlabel(ax1,'X axis','FontSize',fs);
ylabel(ax1,'Y axis','FontSize',fs);
zlabel(ax1,'Z axis','Fontsize',fs);
legend('OR')

end