% generate the mask matrix
% H is a symmetric martix with binary entries
function H = getH(Yo)
    n = size(Yo, 1); % Number of points

    % Fraction of unknown distances
    fractionOfUnknown = 0.85;

    % True distances among points in 3d Helix
    trueDists = pdist(Yo)'.^2; % True distances^2

    % Add noise (set noise_level = 0 for clean measurements)
    noise_level = 0; % 0.01;
    trueDists = trueDists + noise_level * std(trueDists) * randn(size(trueDists));

    % Compute all pairs of indices
    M = tril(true(n), -1);
    % I: the row index of nonezero entries
    % J: the column index of nonezero entries
    [I, J] = ind2sub([n, n], find(M(:)));  
    [train, ~] = crossvalind('HoldOut',length(trueDists),fractionOfUnknown);
   
    % generate the  observational entries 
    H=sparse(I(train),J(train),1,n,n);
    H = H + H';
end