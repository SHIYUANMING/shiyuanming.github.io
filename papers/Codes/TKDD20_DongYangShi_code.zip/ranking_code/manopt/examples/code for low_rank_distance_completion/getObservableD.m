%get the dissimilarties between n data points 
%generate the obervable \tilde{D}
% D is Euclidean Distance Matric with noisy.
function D = getObservableD(Yo)
n = size(Yo, 1); % Number of points

    % True distances among points in 3d Helix
    trueDists = pdist(Yo)'.^2; % True distances^2

    % Add noise (set noise_level = 0 for clean measurements)
    noise_level = 0; % 0.01;
    trueDists = trueDists + noise_level * std(trueDists) * randn(size(trueDists));
    D = zeros(n,n);
    k = 1;
    % generate EDM 
    for j = 1:n-1,
        for i = j+1:n,
            D(i,j) = trueDists(k);
            k = k+1;
        end
    end 
    D  = D + D';
    
end