function [Yopt, infos] = miscg_dist_completion(H,D_ob, Y_initial, params)
   [n, r] = size(Y_initial);
    problem.M = symfixedrankYYfactory(n,  r);
    % Cost evaluation
    problem.cost = @cost;
    function [f, store] = cost(Y, store)
        if ~isfield(store, 'G')
            store.G = Y*Y';
        end
        G = store.G;
        e = ones(length(Y),1);
        K = diag(G)*e' + e*diag(G)' - 2*G;
        errors = H.*(K - D_ob);               
        f = norm(errors,'fro')^2;
    end
    problem.egrad = @grad;
    function [g, store] = grad(Y, store)
       if ~isfield(store, 'G')
            store.G = Y*Y';
        end
        G = store.G;
        e = ones(length(Y),1);
        K = diag(G)*e' + e*diag(G)' - 2*G;
        errors = H.*(K - D_ob);  
        g = 2*2*(diag(errors * e) - errors)*Y;
    end
    
    % Hessian evaluation
    problem.ehess = @ehess;
    function [Hess, store] = ehess(Y, u, store)
        if ~isfield(store, 'G')
            store.G = Y*Y';
        end
        G = store.G;
        e = ones(length(Y),1);
        K = diag(G) * e' + e * diag(G)' - 2 * G;
        G0 = Y * u' + u * Y';
        K0 = diag(G0) * e' + e * diag(G0)' - 2 * G;
        errors = H.* (K - D_ob);  
        part = H.* (K0); 
        Hess = 2 * (2 * (diag(part * e) - part) * Y + 2 * (diag(errors * e) - errors) * u );
       % Hess = problem.M.proj(Y, Hess);
    end
% Stopping criteria options
    options.stopfun = @mystopfun;
    function stopnow = mystopfun(problem, Y, info, last) %#ok<INUSL>
        stopnow = (last >= 5 && (info(last-2).cost - info(last).cost < params.tol || abs(info(last-2).cost - info(last).cost)/info(last).cost < params.vtol));
    end
    options.tolgradnorm = params.tolgradnorm;
    options.maxiter = params.maxiter;
    
    
    % Call appropriate algorithm
    options.solver = @conjugategradient;
    [Yopt, ~, infos] = manoptsolve(problem, Y_initial, options);
    
   
end