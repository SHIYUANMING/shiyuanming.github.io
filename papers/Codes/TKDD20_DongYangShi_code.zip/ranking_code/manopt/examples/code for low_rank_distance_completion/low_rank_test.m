% main program

%Yo is vector of coordinates of original points
Yo = getHelix();
% the orginal EDM
G0 = Yo*Yo';
[n,~] = size(Yo);
e = ones(n,1);
K0 = diag(G0)*e' + e*diag(G0)' - 2*G0;

% generate mask matrix
% H is a symmetric martix with binary entries
H = getH(Yo);

%generate the obervable \tilde{D}
% D_ob is Euclidean Distance Matric with noisy.
D_ob = getObservableD(Yo);

% Initialization
[n, ~] = size(D_ob);
p = 1;   %the initial rank

Y0 = randn(n,p);
params.tol = 1e-5;

% Run algorithms

% GD
fprintf('---------- GD ----------\n');
[Y_gd, infos_gd] = lowrank_dist_completion(@gd_dist_completion,H,D_ob,Y0,params);
% the EDM of Y_gd
G1 = Y_gd*Y_gd';
e = ones(n,1);
K1 = diag(G1)*e' + e*diag(G1)' - 2*G1;

% TR
fprintf('---------- TR ----------\n');
%[Y_tr, infos_tr] = lowrank_dist_completion(@tr_dist_completion,H,D_ob,Y0,params);
% the EDM of Y_tr
G2 = Y_tr*Y_tr';
e = ones(n,1);
K2 = diag(G2)*e' + e*diag(G2)' - 2*G2;

%plot the result
disp_result(infos_gd, infos_tr, Y_gd, Y_tr,Yo); 
