function [Y, infos] = lowrank_dist_completion(fun,H,D_ob,Y,params)
%   fun          function handle on the optimization algorithm
%                (trust region or gradient descent) 
%   H            n-by-n symmetric martix with binary entries 
%   D_ob         n-by-n matrix: Euclidean Distance Matric with noisy.
%   Y            m-by-p0 initial condition of rank p0
%   params       structure array containing algorithm parameters
              
    params = defaultparams(params);
    [n, ~] = size(D_ob);
    params.maxrank = n;
    pmax = params.maxrank;
    max_step = params.max_step;
    ls_maxiter = params.ls_maxiter;
    smin_tol = params.smin_tol;
    vp_tol = params.vp_tol;
    
    % Record cost function values and new rank locations
    infos.cost = [];
    infos.newRank = [];
    
    p0 = 1;% the initial rank
    p = p0;
   
    
    while (p <= pmax),
         fprintf('>> Rank %d <<\n',p);
         if (p > p0),
            
            if isempty(restartDir), % If no restart dir avail. do random restart
                
                disp('No restart dir available, random restart is performed');
                Y = randn(n,p);
                
            else % Perform line-search based on the restart direction 
                
                disp('>> Line-search with restart direction');
                Y(:,p) = 0; % Append a column of zeroes  
                G = Y*Y';   %  Gram matrix
                e = ones(n,1);  %unit vector
                K = diag(G)*e' + e*diag(G)' - 2*G;
                errors = H.*(K - D_ob); 
                deta_Y = 2*2*(diag(errors * e) - errors);  % the gradient on Y0.
                costBefore = norm(errors,'fro')^2;
                fprintf('>> Cost before = %f\n',costBefore);

                stepsize = 2.5;
                if stepsize > max_step,
                    stepsize = max_step;
                end
                    
                for i = 1:ls_maxiter,
                    
                    % Update
                    Y(:,p) = stepsize*restartDir;
                    G = Y*Y';
                    e = ones(n,1);
                    K = diag(G)*e' + e*diag(G)' - 2*G;
                    errors = H.*(K - D_ob);                                
                    costAfter = norm(errors,'fro')^2;
                    fprintf('>> Cost after = %f\n',costAfter);
                    
                    % Armijo rule
                    armijo = (costAfter - costBefore) <=   - 1e-4 * stepsize * norm([zeros(n,p) restartDir]' * deta_Y,'fro');
                    if armijo,
                        break;
                    else
                        stepsize = stepsize/2;
                    end
                    
                end
                % Check for sufficient decrease
                if (costAfter >= costBefore) || abs(costAfter - costBefore) < 1e-8,
                    disp('Decrease is not sufficient, random restart');
                    Y = randn(n,p);
                end
                
            end    

        end
        
        % Run algorithm
        [Y, infos_algo] = feval(fun,H,D_ob,Y,params);
        if size([infos_algo.cost],1) == 1,
            infoscost =  [infos_algo.cost ]';
        else
            infoscost = infos_algo.cost;
        end
        infos.cost = [infos.cost; infoscost];
        infos.newRank = [infos.newRank;max([infos_algo.iter])];
        
        
        G = Y*Y';
        e = ones(n,1);
        K = diag(G)*e' + e*diag(G)' - 2*G;
        errors = H.*(K - D_ob);                                
        
        % Dual variable
        Sy = 2*2*2*(diag(errors * e) - errors);
        % Compute smallest algebraic eigenvalue of Sy,
        % this gives us a descent direction for the next rank (v)
        % as well as a way to control progress toward the global
        % optimum (s_min)
        [v, s_min] = eigs(Sy, 1, 'SA');
        
        % To check whether Y is rank deficient
        vp = svd(Y);
        
        % Stopping criterion
        fprintf('>> smin = %f, and min(vp) = %f\n',s_min,min(vp));
        if (s_min  > -smin_tol) || (min(vp) < vp_tol),
            break;
        end
        
          p = p + 1;

        if (s_min < -1e-10),
            restartDir = v;
        else
            restartDir = [];
        end
        clear Sy v;

     end
    
    infos.newRank = cumsum(infos.newRank);

end