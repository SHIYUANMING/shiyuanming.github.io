% get the coordinate of the helix
function Yo = getHelix()
    % Helix curve in 3d
    tvec = 0:2*pi/120:2*pi;   % 121 points
    tvec = tvec'; 
    xvec = 4*cos(3*tvec);
    yvec = 4*sin(3*tvec);
    zvec = 2*tvec;
    Yo = [xvec, yvec, zvec];
end