% the ManOpt tool needs to be installed via running manopt/importmanopt.m
% Fig. 7 (d). The code of other two algorithms can be found in https://github.com/dhpark22/collranking
warning off
% clear;clc;
randn('seed',1); rand('seed',1);
addpath('./fun');
%% load data
addpath('./raw_data');
load ml100k_prtr_20_train.mat -ascii
load ml100k_prtr_20_matrix.mat -ascii
train = ml100k_prtr_20_train;  
matrix = ml100k_prtr_20_matrix;
%% set parameter
r = 50;  % value: 10 50 100 150
K = 943; N = 1682;
all_num = r*K*log(K);
obs_num = size( ml1m_10_train,1);
per = round(obs_num/all_num);
params.verbosity = 2;
params.tolgradnorm = 1e-6;
params.maxiter = 1000;
params.sigma=0.18;
options1=params; 
options1.mu=1;options1.Delta0 =2;options1.Delta_bar =16;
options1.rho_prime  = 0;

testnum=1;

results1 = zeros(testnum);

alltime=tic;
X =  sparse(matrix(:,1),matrix(:,2),matrix(:,3),K,N);

for test = 1:testnum
        Y_obs = ml1m_10_train;
        XL = rand(K,r); XR = rand(N,r);
        Xo = XL*XR';
        scale = max(abs(Xo(:)));
         XL = XL/sqrt(scale)*sqrt(0.95); XR=XR/sqrt(scale)*sqrt(0.95);        
%% log sum exp  regulization term with rank constraint / trust region algorithm
        ts=tic;
        lambda =r*obs_num/(sqrt(K)*per);
        [Xcg1,~,info1] = ranking_fixedrankTR_logsumexp(r, Y_obs, K ,N,{XL,XR},X,params,options1,lambda);
        X1 = Xcg1.L*Xcg1.R';
        [results1(test),~] = predicting_error(X1,X,params);
        index = find(X1(:,1)<1e-8);
        X1(index,:) = [];
        X(index,:) = [];
        
        index_inverse = find(abs(X1(:,1))>1e-8);
        X_est = X1+abs(min(min(X1)));
        scale = 5/max(max(X_est));
        X_est = ceil(X_est*scale);
        ndcg = ndcg_k(10,X_est,X,index_inverse);
        
        t1(test) = toc(ts);
        fprintf('TR finishes, ndcg_k: %0.3f\n',ndcg);
   
end
alltime=toc(alltime);
