% the ManOpt tool needs to be installed via running manopt/importmanopt.m
% Fig.5 Success Rate with Different Ranks
clear;clc; 
randn('seed',1); rand('seed',1);
addpath('./fun');
%% parameter setting: 
rank_set =6:10;
K=200;
rank_len = length(rank_set);
obs_num = 20000;

params.verbosity = 0;
params.tolgradnorm = 1e-6;
params.maxiter = 500;
params.sigma=0.18;

options1=params; 
options1.mu=1;options1.Delta0 =1;options1.Delta_bar =2;
options1.rho_prime  = 0;

options3.maxiter = 4000;options3.tol=5*1e-6;options3.verbosity=1;options3.sigma = 0.18;
options3.mu=1;options3.lbtol =1e-3;options3.deltau = 2;

options4 = struct();
options4.iterations = 10000;
options4.stepMax    = 10000;
options4.stepMin    = 1e-4;
options4.optTol     = 1e-4;
options4.stepMax    = 1e9;
options4.verbosity    = 0;
options4.sigma = params.sigma;

testnum=100;
results1 = zeros(rank_len,testnum);
results3 = zeros(rank_len,testnum);
results4 = zeros(rank_len,testnum);


reErr1 = zeros(rank_len,testnum);
reErr3 = zeros(rank_len,testnum);
reErr4 = zeros(rank_len,testnum);


t1 = zeros(rank_len,testnum);
t3 = zeros(rank_len,testnum);
t4 = zeros(rank_len,testnum);

alltime=tic;
parfor test = 1:testnum
    for j = 1:rank_len
        r = rank_set(j);
        [X,Y,ranking] = gen_data(K,K,r);
        [Y_obs,Y_test] = gen_obs(X,Y,obs_num,0);
        
        XL = randn(K,r); XR = randn(K,r);
        Xo = XL*XR';
        scale = max(abs(Xo(:)));
        XL = XL/sqrt(scale)*sqrt(0.95); XR=XR/sqrt(scale)*sqrt(0.95);
%% log sum exp  regulization term with rank constraint / trust region algorithm
        ts=tic;
        per = obs_num/(r*K*log(K));
        lambda =r*obs_num/(sqrt(K)*per);
        [Xcg1,~,info1] = ranking_fixedrankTR_logsumexp(r, Y_obs, K ,K,{XL,XR},X,params,options1,lambda);
        X1 = Xcg1.L*Xcg1.R';
        [results1(j,test),reErr1(j,test)] = predicting_error(X1,X,params);
        t1(j,test) = toc(ts);
        fprintf('TR finishes\n');
%% BFGD_logbarrier
        ts=tic;
        [X3,info3,infof3] = BFGD_logbarrier(r, Y_obs, K ,K,{XL,XR},X,params,options3);
        [results3(j,test),reErr3(j,test)] = predicting_error(X3,X,params);
        t3(j,test) = toc(ts);  
        fprintf('BFGD_logbarrier finishes\n');
%% SPG
        ts=tic;
        [X4,info4,infof4] = ranking_SPG(r, Y_obs, K ,K,{XL,XR},X,params,options4);
        [results4(j,test),reErr4(j,test)] = predicting_error(X4,X,params);
        t4(j,test) = toc(ts);
        fprintf('SPG finishes\n');
    end;
end

alltime=toc(alltime)

filename = './final_data/Success_Rate';
save([filename '.mat']);

aver1 = mean(results1,2);
aver3 = mean(results3,2);
aver4 = mean(results4,2);


aver_re1 = mean(reErr1,2);
aver_re3 = mean(reErr3,2);
aver_re4 = mean(reErr4,2);

figure,plot(rank_set,aver1,'-s','LineWidth',1.2, 'MarkerSize',6);hold on
plot(rank_set,aver3,'-d','LineWidth',1.2, 'MarkerSize',6); 
plot(rank_set,aver4,'-d','LineWidth',1.2, 'MarkerSize',6);
legend('PRTPS','BFGDB','SPG');
xlabel('Rank');
ylabel('Success Rate');
set(gca,'Fontsize',12);
axis tight;
grid on