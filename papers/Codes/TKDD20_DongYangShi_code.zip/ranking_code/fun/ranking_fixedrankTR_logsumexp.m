function [Xcg, xcost, info, problem]=ranking_fixedrankTR_logsumexp(r, omega, m,n, X_in,X_or,params,options,lambda)
% r: rank
% X_in: m x n matirx, initial point
% X_or: underlying weight matrix
% omega(:,1): i user    
% omega(:,2): j item
% omega(:,3): k item
% omega(:,4): Y_{ijk} = 1 or -1
% lambda: regularization coefficient
if ~isfield(options,'verbosity'); options.verbosity=1; end 
if ~isfield(options,'sigma'); options.sigma=1; end
if ~isfield(options,'mu'); options.mu=100; end 
sigma = options.sigma;

K = size(omega,1);
f_lost = @(x)log(1+exp(-x/sigma)); g_lost = @(x)-1/sigma*exp(-log(1+exp(x/sigma))); h_lost = @(x)exp(x/sigma-2*log(1+exp(x/sigma))-2*log(sigma));
mu=options.mu;
barrier_func=@barrier_cost;
    function y = barrier_cost(X)
        t = max(abs(X(:)));
        y = t^2+mu*log(sum(sum(exp((X.^2-t^2)/mu))));  
    end
nx_cost = @(X)sum(exp(X(:).^2/mu));  nx_grad = @(X)1/mu*2*X.*exp(X.^2/mu);

       if isempty(X_in)
           X0.L=randn(m,r)/sqrt(m);X0.R=randn(n,r)/sqrt(n);
       else
           X0.L=X_in{1};X0.R=X_in{2};
       end
%% Pick the manifold of matrices of size mxn of fixed rank r.
       problem.M = fixedrankfactory_2factors(m,n, r);
%% L_{\Omega,Y}(X)
problem.costcon = @costcon; 
function [f,p]= costcon(X)     
        Xmat = X.L*X.R';
        index = 1:K;
        A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],n,K);
        M = Xmat * A;
        mask = sub2ind([n,K],omega(:,1),index(:));
        YdeltaX = omega(:,4).* M(mask);
        L = f_lost(YdeltaX);
        f = sum(L);
        p = lambda *barrier_func(Xmat);
    end
%% Define the problem cost function 
    problem.cost = @cost; 
    function [f,store] = cost(X,store)
        if ~isfield(store,'Xmat')
            store.Xmat = X.L*X.R';
        end
        Xmat = store.Xmat;
       if ~isfield(store,'YdeltaX')
        index = 1:K;
        A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],n,K);
        M = Xmat * A;
        mask = sub2ind([m,K],omega(:,1),index(:));
        store.YdeltaX = omega(:,4).* M(mask);
        store.mask = mask;
        store.A = A;
       end
        YdeltaX = store.YdeltaX;
        L = f_lost(YdeltaX);
        f = sum(L)+lambda *barrier_func(Xmat);
end

%% Define the Euclidean gradient of the cost function 
    problem.egrad = @egrad;
    function [g,store] = egrad(X,store)
       if ~isfield(store,'Xmat')
            store.Xmat = X.L*X.R';
       end
       Xmat = store.Xmat;

       if ~isfield(store,'YdeltaX')
        index = 1:K;
        A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],n,K);
        M = Xmat * A;
        mask = sub2ind([m,K],omega(:,1),index(:));
        store.YdeltaX = omega(:,4).* M(mask);
        store.mask = mask;
        store.A = A;
       end
        YdeltaX = store.YdeltaX;
        if ~isfield(store,'grad')
            gx = g_lost(YdeltaX).* omega(:,4);
            nx_f = nx_cost(Xmat);
            nx_g = nx_grad(Xmat);
            G = sparse([omega(:,1) omega(:,1)],[omega(:,2) omega(:,3)],[gx -gx],m,n)+lambda*mu*nx_g/nx_f; 
            store.grad = G;
            store.nx_f = nx_f;
            store.nx_g = nx_g;
        end
        G = store.grad;
        g.L= G*X.R;
        g.R = G'*X.L;
    end
%% Define the Euclidean hessian of the cost function 
    problem.ehess = @ehess;
    function [Hess,store] = ehess(X, eta,store)
       if ~isfield(store,'Xmat')
            store.Xmat = X.L*X.R';
       end
       Xmat = store.Xmat;      
       
       if ~isfield(store,'YdeltaX')
        index = 1:K;
        A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],n,K);
        M = Xmat * A;
        mask = sub2ind([m,K],omega(:,1),index(:));
        store.YdeltaX = omega(:,4).* M(mask);
        store.mask = mask;
        store.A = A;
       end
       YdeltaX = store.YdeltaX;
       if ~isfield(store,'grad')
            gx = g_lost(YdeltaX).* omega(:,4);
            nx_f = nx_cost(Xmat);
            nx_g = nx_grad(Xmat);
            G = sparse([omega(:,1) omega(:,1)],[omega(:,2) omega(:,3)],[gx -gx],m,n)+lambda*nx_g/nx_f; 
            store.grad = G;
            store.nx_f = nx_f;
            store.nx_g = nx_g;
       end
       G = store.grad;
       etatmp = eta.L*X.R'+X.L*eta.R';
       A = store.A;
       mask = store.mask;
       mdeltax = etatmp*A;
       Pt = mdeltax(mask).*h_lost(YdeltaX);
       if ~isfield(store,'nx_f');  store.nx_f = nx_cost(Xmat); end
       if ~isfield(store,'nx_g');  store.nx_g = nx_grad(Xmat); end
       nx_f = store.nx_f;
       nx_g = store.nx_g;
       hx_reg = (2*exp(Xmat.^2/mu).*etatmp+2*Xmat.*nx_g.*etatmp)/nx_f  -  (nx_g*sum(sum(nx_g.*etatmp)))/nx_f^2;
       
       Pdot = sparse([omega(:,1) omega(:,1)],[omega(:,2) omega(:,3)],[Pt -Pt],m,n)+lambda*hx_reg;

       Hess.L = G* eta.R + Pdot*X.R;
       Hess.R = G'* eta.L + Pdot'*X.L; 
    end
% figure, checkgradient(problem);
% figure, checkhessian(problem);
if isfield(options,'xg')
    X_origin = options.xg;
    options.statsfun = @mystatsfun;
end
function stats = mystatsfun(problem, x, stats, store)
    [accuracy, reErr] = predicting_error(store.Xmat,X_origin);
    stats.accuracy = accuracy;
    stats.reErr = reErr;
end
    %% Notice that for this solver, the Hessian is not needed.
       [Xcg, xcost, info] = trustregions(problem, X0, options);
          
      
        iter_num = size(info,2);   
        for i = 1:iter_num,
          [~,reErr1] = predicting_error(info(i).x,X_or,params); 
          info(i).reErr = reErr1; 
        end
  
        
       
end
