function [Y_obs,Y_test] = gen_obs(X,Y,obs_num,type)
if  nargin<4; type=1;end

if type==1 %each row is equally randomly observed
    [m,n] = size(X);
    [all_num,~] = size(Y);
    obs_num_per_user = floor(obs_num/m);
    
    oneline_num = (n^2-n)/2; obs_set = [];
    for i=1:m
        obs = randperm(oneline_num,obs_num_per_user);
        obs_set = union(obs_set,(i-1)*oneline_num+obs);
    end
    left_set = setdiff(1:all_num, obs_set);
    tmp = randperm(length(left_set), obs_num-m*obs_num_per_user);
    obs_set = union(obs_set,tmp); test_set = setdiff(1:all_num,obs_set);
    Y_obs = Y(obs_set,:);
    Y_test = Y(test_set,:);
elseif type==2 %each column has at least one observed
    [m,n] = size(X);
    [all_num,~] = size(Y);
    obs_num_per_user = floor(obs_num/n);
    
    oneline_num = (n^2-n)/2; obs_set = [];
    for i=1:n
        obs = randperm(oneline_num,obs_num_per_user);
        obs_set = union(obs_set,(i-1)*oneline_num+obs);
    end
    left_set = setdiff(1:all_num, obs_set);
    tmp = randperm(length(left_set), obs_num-m*obs_num_per_user);
    obs_set = union(obs_set,tmp); test_set = setdiff(1:all_num,obs_set);
    Y_obs = Y(obs_set,:);
    Y_test = Y(test_set,:);
else % randomly observed
    all_num = size(Y,1);
    obs = randperm(all_num,obs_num);
    test = setdiff(1:all_num,obs);
    Y_obs = Y(obs,:);
    Y_test = Y(test,:);
end