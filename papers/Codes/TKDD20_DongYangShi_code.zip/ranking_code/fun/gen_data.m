function [X,Y,ranking] = gen_data(m,n,r,sigma)
if  nargin<4; sigma = 0.18; end
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
%X = randi(5,[m,n]);
% r = -0.5 + rand(m,r);
% X = (rand(m,r)-0.5)*(rand(r,n)-0.5);
X =  ceil((rand(m,r)*sqrt(5)+1)*(rand(r,n)*sqrt(5))+1);
% X = X/max(abs(X(:)));
% X = rand(m,n);
% [u,s,v] = svds(X,r);
% X = u*s*v';
% X = X/max(abs(X(:)));

all_num = m*(n^2-n)/2;
ranking_vec = zeros(n,1);
Y = zeros(all_num,4);
t = 0 ;
for i = 1:m
    for j = 1:n
        for k = j+1:n
            t = t+1;
            dx = exp((X(i,j)-X(i,k))/sigma);
            if rand<=(dx/(1+dx));
                Y(t,:)=[i,j,k,1];
            else
                Y(t,:)=[i,j,k,-1];
            end
            if X(i,j)>X(i,k)
                ranking_vec(j) = ranking_vec(j)+1;
%                 Y(t,:)=[i,j,k,1];
            else
                ranking_vec(k) = ranking_vec(k)+1;
%                 Y(t,:)=[i,j,k,-1];
            end
        end
    end
end

[~,ranking] = sort(ranking_vec,'descend'); 
end

