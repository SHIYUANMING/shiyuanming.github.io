function res=ndcg_k(n_k, pred, y,index)
%% 
%  pred is the predicted relevance, an n by m matrix
% y is the ground truth relevance, an n by m matrix
% n is the number of users
% m is the number of items

pred = full(pred);
y = full(y);

% return the averaged ndcg for retrieving items for the users
[n,m]=size(pred);

%% compute the ranks of the items for each user
mask = y==0;
pred = pred.* mask;
[dummy, I] = sort(pred, 2, 'descend');
ranks = zeros(size(pred));

[dummy, ideal_I] = sort(y, 2, 'descend');
ideal_ranks = zeros(size(pred));

res =0;
cnt = 0;
for ii= 1:n
    i = index(ii);
	nz = find(y(i, :)~=0); 
    nnz = length(nz);
   if ~isempty(nz)&& n_k<=nnz
   ranks(i, I(i, :)) = 1:m;
	ideal_ranks(i, ideal_I(i, :)) = 1:m;
	pos = ranks(i, nz);
	ideal_pos = ideal_ranks(i, nz);
    kk =1:n_k;
    
    nominator = (2.^( pred(pos(kk)) )-1)./log2(kk + 1);
    denominator = (2.^( y(ideal_pos(kk)) )-1)./ log2(kk + 1);
%     if n_k > nnz
%         % pad more 0
%         nominator = padarray(nominator, [0, n_k - nnz], 0, 'post');
%         denominator = padarray(denominator, [0, n_k - nnz], 0, 'post');
%     elseif n_k < nnz
%         % truncate the tail
%         nominator = nominator(1:n_k);
%         denominator = denominator(1:n_k);
%     end
    
    if size(find(cumsum(denominator)==0), 2) ~= 0
        tmp = 0;
    else
        tmp = sum(nominator)/ sum(denominator);
        cnt = cnt + 1;
    end
    %tmp = full(tmp);
    %tmp = padarray(tmp, [0, length(k_vals) - size(tmp, 2)], 0, 'post');
	res = res + tmp;
   end
end
% res = res / cnt;
res =res/cnt;

