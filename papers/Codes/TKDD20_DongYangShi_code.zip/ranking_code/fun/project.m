% ----------------------------------------------------------------------
function varargout = project(x,funObj,funProj ,projTol,projData)
% ----------------------------------------------------------------------
   if nargin < 5, projTol  = 1e-9; end;
   if nargin < 4, projData = []; end

 
   if (nargout == 1)
      x = funProj(x,projTol,projData);
      varargout{1} = x;
   else
      [x,projData] = funProj(x,projTol,projData);
      varargout{1} = x;
      varargout{2} = projData;
   end
  
end % function project
