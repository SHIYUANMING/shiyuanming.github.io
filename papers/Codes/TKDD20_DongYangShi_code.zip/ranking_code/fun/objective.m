
function varargout = objective(varargin,funObj,funProj )
% ----------------------------------------------------------------------
   
  

   if nargout == 1
      varargout{1} = funObj(varargin{:});
   elseif nargout == 2
      [varargout{1},varargout{2}] = funObj(varargin{:});
     
   end
   
 
end  % function objective

