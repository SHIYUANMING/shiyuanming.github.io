function [Xcg,infosx,infosf,funObj,funProj ]=ranking_SPG(r, omega, m,n, X_in,X_or,params, options)
% r: rank
% X_in: m x n matirx, initial point
% X_or: underlying weight matrix
% omega(:,1): i user    
% omega(:,2): j item
% omega(:,3): k item
% omega(:,4): Y_{ijk} = 1 or -1

if ~isfield(options,'verbosity'); options.verbosity=1; end 
if ~isfield(options,'sigma'); options.sigma=0.18; end
if ~isfield(options,'alpha'); options.alpha=1; end
alpha = options.alpha;
 sigma = options.sigma;

K = size(omega,1);

f_lost = @(x)log(1+exp(-x/sigma)); 
g_lost = @(x)-1/sigma*exp(-log(1+exp(x/sigma)));
%% Define the problem cost function
    function [f,g] = cost(X)
        Xmat = reshape(X,[m,n]);
        index = 1:K;
        A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],n,K);
        M = Xmat * A;
        mask = sub2ind([n,K],omega(:,1),index(:));
        YdeltaX = omega(:,4).* M(mask);
        L = f_lost(YdeltaX);
        f = sum(L);
        gx = g_lost(YdeltaX).* omega(:,4);
        G = sparse([omega(:,1) omega(:,1)],[omega(:,2) omega(:,3)],[gx -gx],m,n); 
        g = G(:);
    end

%% Set up optimization problem
        
funObj  = @(x) cost(x);

%% Define alpha to be the correct maximum using an oracle
radius  = alpha * sqrt(m*n*r);

%% Define constraints
% Use nuclear-norm constraint only
funProj = @(X,projTol,projData) projNucnorm(X,m,n,radius,projTol,projData);

% Use nuclear-norm plus infinity-norm constraints
%funProj = @(x,projTol,projData) projectKappaTau(x,d1,d2,radius,alpha,projTol,projData);
if isempty(X_in)
   X0=reshape(randn(m,r)/sqrt(m)*randn(r,n)/sqrt(n),[m*n,1]);
else
   X0=X_in{1}*X_in{2}';
end
%% Recover estimate Mhat of M
options.r = r;
options.m = m;
options.n = n;
[Mhat,infosx,infosf] = spgSolver(funObj, funProj, X0,X_or,params, options);
Mhat = reshape(Mhat,m,n);

[U,S,V] = svd(Mhat);
Xcg = U(:,1:r)*S(1:r,1:r)*V(:,1:r)'; % Project onto actual rank if known

end