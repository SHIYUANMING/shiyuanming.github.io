function [X,infosx,infos] = BFGD_logbarrier(r, omega, m ,n,X_in,X_or,params,options)
%  r: rank
% X_in: m x n matirx, initial point
% X_or: underlying weight matrix
% omega(:,1): i user    
% omega(:,2): j item
% omega(:,3): k item
% omega(:,4): Y_{ijk} = 1 or -1
if isempty(X_in)
   X0.L=randn(m,r)/sqrt(m);X0.R=randn(n,r)/sqrt(n);
else
   X0.L=X_in{1};X0.R=X_in{2};
end
Lcur = X0.L;
Rcur = X0.R;
Xcur = X0.L*X0.R';
Xprev = Xcur;

maxiter = options.maxiter;
sigma = options.sigma;
deltau = options.deltau;
lbtol = options.lbtol;
tol = options.lbtol;


ts = tic();
K = size(omega,1);

f_lost = @(x)log(1+exp(-x/sigma));
g_lost = @(x)-1/sigma*exp(-log(1+exp(x/sigma)));
barrier_func=@barrier_cost;
    function y = barrier_cost(X)
        [m1,n1] = size(X);
        y= sum(sum(log(ones(m1,n1)-X.*X)));
    end
barrier_grad = @(X)-2*X./(1-X.^2); 

f = @(X,tau)cost(f_lost,barrier_func,omega,tau,K,X);
g = @(X,tau)grad(g_lost,barrier_grad,omega,tau,K,X);
[~,ff_or] = f(Xcur,2);

tau = (m*n)/ff_or;     % parameter    
lbiter = ceil((log(m*n)-log(lbtol)-log(tau))/log(deltau));  %logbarrier outiter number

infosx = struct();
infosx(1).x=Xcur;
infosx(1).time = toc(ts);
[infos.deltacost,infos.deltacostff]=f(Xcur,tau);
[infos.deltacost_whole,infos.deltacost_wholeff]=f(Xcur,tau);
% stepsize
eta_L =0.5*2/(187*norm(X0.L,'fro')^2);
eta_R =0.5*2/(187*norm(X0.R,'fro')^2);
iter=1;

[~,reErr]=predicting_error(Xcur,X_or,params);
infos.reErr=reErr; 

for ii = 1:lbiter  % out iteration log-barrier
 iter_inner= 1;
while(iter_inner<maxiter)  % inner iteration BFGD
%     fprintf('tau: %f, iteration: %d\n',tau,iter);
    
    
    f_gradX = g(Lcur * Rcur',tau);
    gradU = f_gradX * Rcur;
    gradV = f_gradX' * Lcur;

    Lcur = Lcur - eta_L* gradU;
    Rcur = Rcur - eta_R * gradV;
    Xcur = Lcur * Rcur';
   
    if ((iter_inner > 1) && (norm(Xcur - Xprev, 'fro')/norm(Xcur, 'fro') < tol  )...
            || isnan(norm(Xcur - Xprev, 'fro')/norm(Xcur, 'fro')))...
            || max(abs(Xcur(:)))>=1
      
        break;       
    end
       [newf,newff] = f(Xcur,tau);
       infos.deltacost = [infos.deltacost;newf];
       infos.deltacostff = [infos.deltacostff;newff];
      
       infosx(iter+1).x = Xcur;
       infosx(iter+1).time = toc(ts);
       [~,reErr]=predicting_error(infosx(iter+1).x,X_or,params);
       infos.reErr= [infos.reErr;reErr];
       
       iter_inner = iter_inner + 1;  
       Xprev = Xcur;
       iter = iter + 1;

end
tau = tau * deltau;
end
   
X =  Lcur * Rcur';
end
function [f,ff] = cost(f_lost,barrier_func,omega,tau,K,X)
    [~,nx] = size(X);
    index = 1:K;
    A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],nx,K);
    M = X * A;
    mask = sub2ind([nx,K],omega(:,1),index(:));
    YdeltaX = omega(:,4).* M(mask);
    f = sum(f_lost(YdeltaX))-1/tau *barrier_func(X);
    ff = sum(f_lost(YdeltaX));
    
end
function G = grad(g_lost,barrier_grad,omega,tau,K,X)
    [m,n]  = size(X);
    index = 1:K;
    A = sparse([omega(:,2) omega(:,3)],[index index],[ones(1,K) -ones(1,K)],n,K);
    M = X * A;
    mask = sub2ind([n,K],omega(:,1),index(:));
    YdeltaX = omega(:,4).* M(mask);
    gx = g_lost(YdeltaX).* omega(:,4);
    G = sparse([omega(:,1) omega(:,1)],[omega(:,2) omega(:,3)],[gx -gx],m,n)-1/tau*barrier_grad(X); 
end