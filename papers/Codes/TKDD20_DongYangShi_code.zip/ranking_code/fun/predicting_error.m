function [accuracy,rmse] = predicting_error(X1,X2,params,type)
if nargin<4; type=1;end
if nargin<3; params.sigma=1;end
if ~isfield(params,'sigma'); params.sigma=1;end
sigma = params.sigma;
%UNTITLED3 Summary of this function goes here
%    Detailed explanation goes here
[m,n] = size(X1);
if type
    X1 = X1/max(abs(X1(:)));
end

%% computing the ranking score which is defined by tau_j^i = 1/n*sum_{k} f(X_{ij}-X_{ik});
ranking_score1 = zeros(m,n);
ranking_score2 = zeros(m,n);
for i=1:m
    for j=1:n
        tmp1=0;
        tmp2=0;
        for k=1:n
            tmp1 = tmp1+1/(1+exp(X1(i,k)-X1(i,j))/sigma);
            tmp2 = tmp2+1/(1+exp(X2(i,k)-X2(i,j))/sigma);
        end
        ranking_score1(i,j) = tmp1;
        ranking_score2(i,j) = tmp2;
    end
end
%% count the mismatches
accuracy = predicting_ranking_error(ranking_score1,ranking_score2);
%% compute the relative mse.
err = norm(X1-X2,'fro');
rmse = err^2/norm(X2,'fro')^2;
end

function result = predicting_ranking_error(ranking_score1,ranking_score2)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
[m,n]=size(ranking_score1);
t = 0;
for i = 1:m
    for j = 1:n
        for k = j+1:n
            t = t + ((ranking_score1(i,j)-ranking_score1(i,k))*(ranking_score2(i,j)-ranking_score2(i,k))>0);
        end
    end
end
result = t*2/(m*n*(n-1));
end

