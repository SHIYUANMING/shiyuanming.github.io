% the ManOpt tool needs to be installed via running manopt/importmanopt.m
% Fig. 4. Relative MSE with different sample sizes
warning off
clear;clc;
randn('seed',1); rand('seed',1);
addpath('./fun');
%% parameter setting: 
r = 10; K=200;N=200;
per =4:8;
all_num = r*K*log(K);
obs_num_set = round(per*all_num);
obs_num_len = length(per);
params.verbosity = 0;
params.tolgradnorm = 1e-6;
params.maxiter = 500;
params.sigma=0.18;
options1=params; 
options1.mu=1;options1.Delta0 =1;options1.Delta_bar =2;
options1.rho_prime  = 0;


options3.maxiter = 4000;options3.tol=5*1e-6;options3.verbosity=1;options3.sigma = 0.18;
options3.mu=1;options3.lbtol =1e-3;options3.deltau = 2;

options4 = struct();
options4.iterations = 10000; 
options4.stepMax    = 10000;
options4.stepMin    = 1e-4;
options4.optTol     = 1e-4;
options4.stepMax    = 1e9;
options4.verbosity    = 0;
options4.sigma = params.sigma;

testnum=100;

results1 = zeros(obs_num_len,testnum);
results3 = zeros(obs_num_len,testnum);
results4 = zeros(obs_num_len,testnum);

reErr1 = zeros(obs_num_len,testnum);
reErr3 = zeros(obs_num_len,testnum);
reErr4 = zeros(obs_num_len,testnum);

t1 = zeros(obs_num_len,testnum);
t3 = zeros(obs_num_len,testnum);
t4 = zeros(obs_num_len,testnum);

alltime=tic;

parfor test = 1:testnum
  [X,Y,ranking] = gen_data(K,K,r,params.sigma);

    for j = 1:obs_num_len
        obs_num = obs_num_set(j);
        [Y_obs,Y_test] = gen_obs(X,Y,obs_num,0);
        XL = randn(K,r); XR = randn(N,r);
        Xo = XL*XR';
        scale = max(abs(Xo(:)));
        XL = XL/sqrt(scale)*sqrt(0.95); XR=XR/sqrt(scale)*sqrt(0.95);   
        fprintf('test: %d, j: %d, %d\n',test,j);
%% log sum exp  regulization term with rank constraint / trust region algorithm
        ts=tic;
        lambda =r*obs_num/(sqrt(K)*per(j));
        [Xcg1,~,info1] = ranking_fixedrankTR_logsumexp(r, Y_obs, K ,N,{XL,XR},X,params,options1,lambda);
        X1 = Xcg1.L*Xcg1.R';
        [results1(j,test),reErr1(j,test)] = predicting_error(X1,X,params);
        t1(j,test) = toc(ts);
        fprintf('TR finishes\n');
%% BFGD_logbarrier   
        ts=tic;
        [X3,info3,infof3] = BFGD_logbarrier(r, Y_obs, K ,K,{XL,XR},X,params,options3);
        [results3(j,test),reErr3(j,test)] = predicting_error(X3,X,params);
        t3(j,test) = toc(ts);
        fprintf('BFGD_logbarrier finishes\n');
%% SPG
        ts=tic;
        [X4,info4,infof4] = ranking_SPG(r, Y_obs, K ,K,{XL,XR},X,params,options4);
        [results4(j,test),reErr4(j,test)] = predicting_error(X4,X,params);
        t4(j,test) = toc(ts);
        fprintf('SPG finishes\n'); 

    end
end

alltime=toc(alltime);


aver1 = mean(results1,2);
aver3 = mean(results3,2);
aver4 = mean(results4,2);


aver_re1 = mean(reErr1,2);
aver_re3 = mean(reErr3,2);
aver_re4 = mean(reErr4,2);


time1 = mean(t1,2);
time3 = mean(t3,2);
time4 = mean(t4,2);

figure,plot(per,aver_re1,'-s','LineWidth',1.2, 'MarkerSize',6);hold on
plot(per,aver_re3,'-d','LineWidth',1.2, 'MarkerSize',6);
plot(per,aver_re4,'-d','LineWidth',1.2, 'MarkerSize',6);
legend('PRTPS','BFGDB','SPG');
xlabel('Rescaled Sample Size');
ylabel('Relative MSE');
set(gca,'Fontsize',12);
axis tight
grid on

