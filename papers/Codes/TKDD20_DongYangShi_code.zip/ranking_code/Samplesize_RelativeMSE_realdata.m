% the ManOpt tool needs to be installed via running manopt/importmanopt.m
% Fig. 7.(a)(b) Relative MSE with different sample sizes
% The code of other two algorithms can be found in https://github.com/dhpark22/collranking
warning off
% clear;clc;
%  randn('seed',1); rand('seed',1);
addpath('./fun');
%% load data
addpath('./raw_data');
load ml100k_prtr_20_train.mat -ascii
load ml100k_prtr_20_matrix.mat -ascii
train = ml100k_prtr_20_train;  
matrix = ml100k_prtr_20_matrix;
%% set parameter
r = 50; K = 943; N = 1682;
all_num = r*K*log(K);
obs_num = size(train,1);
per = (obs_num/all_num);
params.verbosity = 2;
params.tolgradnorm = 1e-6;
params.maxiter =50;
params.sigma=0.18;
options1=params; 
options1.mu=1;options1.Delta0 =1;options1.Delta_bar =2;
options1.rho_prime  = 0;


options3.maxiter = 4000;options3.tol=5*1e-6;options3.verbosity=1;options3.sigma = 0.18;
options3.mu=1;options3.lbtol =1e-3;options3.deltau = 2;

options4 = struct();
options4.iterations = 10000; 
options4.stepMax    = 10000;
options4.stepMin    = 1e-4;
options4.optTol     = 1e-4;
options4.stepMax    = 1e9;
options4.verbosity    = 2;
options4.sigma = params.sigma;

testnum=100;

results1 = zeros(testnum);

t1 = zeros(testnum);


alltime=tic;
X =  sparse(matrix(:,1),matrix(:,2),matrix(:,3),K,N);

for test = 1:testnum
        Y_obs =train;
        XL = rand(K,r); XR = rand(N,r);
        Xo = XL*XR';
        scale = max(abs(Xo(:)));
        XL = XL/sqrt(scale)*sqrt(0.95); XR=XR/sqrt(scale)*sqrt(0.95);        
%% log sum exp  regulization term with rank constraint / trust region algorithm
        ts=tic;
        lambda =r*obs_num/(sqrt(K)*per);
        [Xcg1,~,info] = ranking_fixedrankTR_logsumexp(r, Y_obs, K ,N,{XL,XR},X,params,options1,lambda);
        X1 = Xcg1.L*Xcg1.R';
        [results1(test),~] = predicting_error(X1,X,params);
        results1(test) = 1-results1(test);
        ndcg = ndcg_k(10,X1,X,K);    
        t1(test) = toc(ts);
        fprintf('TR finishes, ndcg_k: %0.3f\n',ndcg);
   
end
alltime=toc(alltime);
time1 = mean(t1,2);
aver_results = mean(results1);