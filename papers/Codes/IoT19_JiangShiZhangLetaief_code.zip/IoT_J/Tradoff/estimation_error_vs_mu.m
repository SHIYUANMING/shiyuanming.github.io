clc;clear;close all;
%% generate data
iscomplex = 1;

N = 2000; % #devices
M = 10; % #atenna
S = 100; % #active devices
L = 400; % #pilot length

x_sigmma = sqrt(0.5);
noise_sigmma = sqrt(0.01/2);


%%
%smooth parameter
mus = 0.01:0.01:0.08;
exp_num = 2;
err = zeros(exp_num,length(mus));

for jj=1:length(mus)
    mu = mus(jj)
     
    sdim = N*sdim_group_l1_tradeoff(S/N,2*M,mu,x_sigmma)/(2*M);
    EPS = sqrt(2*noise_sigmma^2*(L-sdim)*M)+eps;
    for ii = 1: exp_num
        
        Theta0 = zeros(N,M)+iscomplex*zeros(N,M)*1i;
        index = randperm(N,S);
        Theta0(index,:) = normrnd(0,x_sigmma,S,M)+iscomplex*normrnd(0,x_sigmma,S,M)*1i;
        
        Q = normrnd(0,sqrt(0.5),L,N)+iscomplex*normrnd(0,sqrt(0.5),L,N)*1i;
        
        noise = normrnd(0,noise_sigmma,L,1)+iscomplex*normrnd(0,noise_sigmma,L,1)*1i;
        
        Y = Q*Theta0+noise;
        
        if iscomplex
            Q = [real(Q), -imag(Q);imag(Q) real(Q)];
            Y = [real(Y); imag(Y)];
            Theta1 = [real(Theta0); imag(Theta0)];
        else
            Theta1 = Theta0;
        end
        [Theta, ~, ~] = N83(Q,Y,M,mu,EPS,Theta1);
        err(ii,jj) = norm(Q*(Theta-Theta1),'fro')/(L*M);
        
    end
    
    
end
%% plot

figure;
semilogy(mus,mean(err),'o-');
xlabel('Smoothing parameter \mu')
ylabel('Estimation error')

