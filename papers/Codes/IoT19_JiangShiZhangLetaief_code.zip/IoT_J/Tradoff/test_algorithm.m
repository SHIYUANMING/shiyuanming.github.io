clc;clear;close all;
%% generate data
% rng(10)
iscomplex = 1;

N = 500; % #devices
M = 2; % #atenna
S = 50; % #active devices

x_sigmma = sqrt(0.5);
mu0 = 0.05;
sdim0 = ceil(N*sdim_group_l1_tradeoff(S/N,2*M,mu0,x_sigmma)/(2*M));
m0 = ceil(sdim0+sqrt(N/(2*M)));

L = m0; % #pilot length
%smooth parameter
% mus = [0.1 0.5 0.7 0.8]+mu0;
% [mu,sdim] = calculate_mu(S/N,M,N,L,x_sigmma,sdim0,m0,mu);
mus = mu0;

Theta0 = zeros(N,M)+iscomplex*zeros(N,M)*1i;
index = randperm(N,S);
Theta0(index,:) = normrnd(0,sqrt(0.5),S,M)+iscomplex*normrnd(0,sqrt(0.5),S,M)*1i;

Q = normrnd(0,sqrt(0.5),L,N)+iscomplex*normrnd(0,sqrt(0.5),L,N)*1i;


noise_sigmma = sqrt(0.001/2);
noise = normrnd(0,noise_sigmma,L,1)+iscomplex*normrnd(0,noise_sigmma,L,1)*1i;
EPS = sqrt(2*noise_sigmma^2*(L-sdim0)*M)

Y = Q*Theta0+noise;


% [Theta_star,~]=solve_CVX(Q,Y,EPS,mus,iscomplex);
% err0 = norm(Theta0-Theta_star,'fro');

if iscomplex
    Q = [real(Q), -imag(Q);imag(Q) real(Q)];
    Y = [real(Y); imag(Y)]; 
    Theta0 = [real(Theta0); imag(Theta0)];
end
% norm(Y-Q*Theta0)
%%



MAX_ITR = 3000;


time = zeros(MAX_ITR,length(mus));
err = zeros(MAX_ITR,length(mus));
err1 = zeros(MAX_ITR,length(mus));
for jj=1:length(mus)
mu = mus(jj);
Lip = norm(Q,2)^2/mu;

% [Theta_star,f_star] =solve_CVX_1(Q,Y,EPS,mu,iscomplex);

Theta = zeros(size(Q,2),M);
Z = zeros(size(Q,1),M);
Z_bar = zeros(size(Q,1),M);
t = 1;

% norm(Theta_star-Theta0,'fro')
ts = tic;
for ii = 1:MAX_ITR
   ii 
   Y_k = (1-t)*Z+t*Z_bar; 
    
   if M==1
        Theta = mu\soft_threshold(Q'*Y_k, 1); 
   else
        Theta = mu\soft_threshold_group(Q'*Y_k, 1); 
   end
   Q_Theta = Q*Theta;
   %% AT
%    name = 'AT';
%    Z_bar = shrink(Z_bar-(Q_Theta-Y)/Lip/t, EPS/Lip/t);
%    Z = (1-t)*Z+t*Z_bar;
%    
   %% LLM
%    name = 'LLM';
   Z_bar = shrink(Z_bar-(Q_Theta-Y)/Lip/t, EPS/Lip/t);
   Z = shrink(Y_k-(Q_Theta-Y)/Lip, EPS/Lip); 
  
   %% N83
%    name = 'N83';
%    Z_old = Z;
%    Z = shrink(Y_k-(Q_Theta-Y)/Lip, EPS/Lip); 
%    Z_bar = (Z-(1-t)*Z_old)/t;
% %    
   %% GRA
%    name = 'GRA';
%    Z = shrink(y_k-(Q*Theta-Y)/Lip, EPS/Lip); 
%    Z_bar = Z;
   
%    t=1;
   t = 2/(1+(1+4/t^2)^0.5);
      
   time(ii,jj) = toc(ts);
%    sub_opt(ii,jj) = norm(Theta-Theta_star,'fro');
   err(ii,jj) = norm(Theta-Theta0,'fro')/norm(Theta0,'fro');
   proj_err(ii,jj) = norm(Q*(Theta-Theta0),'fro')/L;
   err1(ii,jj) = abs(norm(Q_Theta-Y,'fro')-EPS);
   if err1(ii,jj)/ EPS<1e-3
       break;
   end
end
end
%% plot



figure;
semilogy(err1,'LineWidth',2);
xlabel('Seconds')
ylabel('Primal feasibility gap')
% legend(['\mu=' num2str(mus(1))],['\mu=' num2str(mus(2))],...
%     ['\mu=' num2str(mus(3))],['\mu=' num2str(mus(4))])
% title(name)

figure;
semilogy(err,'LineWidth',2);
xlabel('Seconds')
ylabel('Estimation error')
% legend(['\mu=' num2str(mus(1))],['\mu=' num2str(mus(2))],...
%     ['\mu=' num2str(mus(3))],['\mu=' num2str(mus(4))])
% title(name);
figure;
semilogy(proj_err,'LineWidth',2);
xlabel('Seconds')
ylabel('Proj Estimation error')