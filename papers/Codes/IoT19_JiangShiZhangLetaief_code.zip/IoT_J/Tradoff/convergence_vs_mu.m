clc;clear;close all;
%% generate data
rng(10)
iscomplex = 1;

N = 2000; % #devices
M = 10; % #atenna
S = 100; % #active devices
L = 500; % #pilot length

x_sigmma = sqrt(0.5);
Theta0 = zeros(N,M)+iscomplex*zeros(N,M)*1i;
index = randperm(N,S);
Theta0(index,:) = normrnd(0,x_sigmma,S,M)+iscomplex*normrnd(0,x_sigmma,S,M)*1i;

Q = normrnd(0,sqrt(0.5),L,N)+iscomplex*normrnd(0,sqrt(0.5),L,N)*1i;

noise_sigmma = sqrt(0.01/2);
noise = normrnd(0,noise_sigmma,L,1)+iscomplex*normrnd(0,noise_sigmma,L,1)*1i;

Y = Q*Theta0+noise;

if iscomplex
    Q = [real(Q), -imag(Q);imag(Q) real(Q)];
    Y = [real(Y); imag(Y)];
    Theta1 = [real(Theta0); imag(Theta0)];
else
    Theta1 = Theta0;
end
%%
%smooth parameter
mus = [0.01 0.02 0.03 0.04];
% mus = 0.1;

MAX_ITR = 5000;

sub_opt = zeros(MAX_ITR,length(mus));
time = zeros(MAX_ITR,length(mus));
err = zeros(MAX_ITR,length(mus));
err1 = zeros(MAX_ITR,length(mus));
err2 = zeros(MAX_ITR,length(mus));
for jj=1:length(mus)
mu = mus(jj);
Lip = norm(Q,2)^2/mu;

sdim = N*sdim_group_l1_tradeoff(S/N,2*M,mu,x_sigmma)/(2*M);
EPS = sqrt(2*noise_sigmma^2*(L-sdim)*M)+eps;


% [Theta_star,f_star] =solve_CVX_1(Q,Y,EPS,mu,iscomplex);

Theta = zeros(N,M);
Z = zeros(2*L,M);
Z_bar = zeros(2*L,M);
t = 1;

% norm(Theta_star-Theta0,'fro')
ts = tic;
for ii = 1:MAX_ITR
    
   Y_k = (1-t)*Z+t*Z_bar; 
      
   Theta = mu\soft_threshold_group(Q'*Y_k, 1); 
   Q_Theta = Q*Theta;
   Z_bar = shrink(Z_bar-(Q_Theta-Y)/Lip/t, EPS/Lip/t);
   Z = shrink(Y_k-(Q_Theta-Y)/Lip, EPS/Lip); 
   t = 2/(1+(1+4/t^2)^0.5);
     
   time(ii,jj) = toc(ts);
%    sub_opt(ii,jj) = norm(Theta-Theta_star,'fro');
   err(ii,jj) = norm(Theta-Theta1,'fro');
   err1(ii,jj) = abs(norm(Q*Theta-Y,'fro')-EPS)/EPS;
   if err1(ii,jj) < 1e-3
       err2(jj) = norm(Q*(Theta-Theta1),'fro');
      break; 
   end
end
end
%% plot

figure;
semilogy(err,'LineWidth',2);
xlabel('Number of iterations')
ylabel('Estimation error')
legend(['\mu=' num2str(mus(1))],['\mu=' num2str(mus(2))],...
    ['\mu=' num2str(mus(3))],['\mu=' num2str(mus(4))])

figure;
semilogy(err1,'LineWidth',2);
xlabel('Number of iterations')
ylabel('Relative primal feasibility gap')
legend(['\mu=' num2str(mus(1))],['\mu=' num2str(mus(2))],...
    ['\mu=' num2str(mus(3))],['\mu=' num2str(mus(4))])

