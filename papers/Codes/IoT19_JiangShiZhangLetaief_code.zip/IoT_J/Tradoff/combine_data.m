clc;clear all;
load dataM5_200.mat
err_Theta1=err_Theta;
err_proj1=err_proj;
time1=time;
iteration1=iteration;
load dataM5_100.mat
err_Theta=[err_Theta,err_Theta1];
err_proj=[err_proj,err_proj1];
time=[time,time1];
iteration=[iteration,iteration1];

exp_num=300;
save dataM5_300.mat