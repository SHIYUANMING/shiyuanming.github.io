function Xs = shrink(X, T)

if T>0
   Xs = max(norm(X,'fro')-T,0)./(max(norm(X,'fro')-T,0)+T).*X;
else
    Xs = X;
end    

end
