function [mu, samplesize] = calculate_mu(sparsity,M,N,L,x_sigmma,sdim0,m0)
% Calculate max mu given L
blocksize = M*2;

stepsize = 0.1;
samplesize = 0;
mu = 0;
temp1 = samplesize/L;
temp2 = sdim0/m0;
cnt = 0;
for ii = 1:1e9
    if temp1 >= temp2 
       mu = mu-stepsize;
       stepsize = stepsize/10;
       cnt = cnt+1;
    end    
    mu = mu+stepsize;
    samplesize = N*sdim_group_l1_tradeoff(sparsity,blocksize,mu,x_sigmma)/(blocksize);    
    temp1 = samplesize/L;
    if cnt == 13 && abs(temp1-temp2)<1e-13
       break; 
    end
end

% abs((samplesize/L) - temp2)

end