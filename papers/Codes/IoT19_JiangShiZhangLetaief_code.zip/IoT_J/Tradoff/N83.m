function [Theta, time, iter] = N83(Q,Y,M,mu,EPS,Theta1)
Lip = min(norm(Q,2)^2/mu,norm(Q,'fro')^2/mu);

Theta = zeros(size(Q,2),M);
Z = zeros(size(Q,1),M);
Z_bar = zeros(size(Q,1),M);
t = 1;

MAX_ITR = 100000;

time = 0;
for ii = 1:MAX_ITR
   tic
   Y_k = (1-t)*Z+t*Z_bar; 
    
%    Theta_old = Theta;
  
   Theta = mu\soft_threshold_group(Q'*Y_k, 1); 
   Q_Theta = Q*Theta;
   %% AT
% %    name = 'AT';
%    Z_bar = shrink(Z_bar-(Q*Theta-Y)/Lip/t, EPS/Lip/t);
%    Z = (1-t)*Z+t*Z_bar;
   
   %% LLM
%    name = 'LLM';
   Z_bar = shrink(Z_bar-(Q_Theta-Y)/Lip/t, EPS/Lip/t);
   Z = shrink(Y_k-(Q_Theta-Y)/Lip, EPS/Lip); 
%   
   %% N83
%    name = 'N83';
%    Z_old = Z;
%    Z = shrink(Y_k-(Q_Theta-Y)/Lip, EPS/Lip); 
%    Z_bar = (Z-(1-t)*Z_old)/t;
%    
   %% GRA
%    name = 'GRA';
%    Z = shrink(Y_k-(Q*Theta-Y)/Lip, EPS/Lip); 
%    Z_bar = Z;
   
%    t=1;
   t = 2/(1+(1+4/t^2)^0.5);
    
   time = time+toc;
% 
   if EPS > 0
        err = abs(norm(Q_Theta-Y,'fro')-EPS)/EPS;
   else
        err = norm(Q_Theta-Y,'fro');
   end
   if  err < 1e-4
       break;
   end

%     err_th = norm(Theta-Theta1,'fro')/max(norm(Theta1,'fro'),1);
%     if err_th<=1e-3
%         break;
%     end
   
%     err_th1 = norm(Q_Theta-Y,'fro')/EPS;
%     if err_th1 <= 1e-2 
%         break;
%     end

end
if ii < MAX_ITR
    fprintf('Solved\n');
else
    fprintf('Unsolved\n');
end
iter = ii;
end