clc;clear;close all;
%% generate data
%rng(1)
iscomplex = 1;

N = 2000; % #devices
M = 10; % #atenna
S = 100; % #active devices

x_sigmma = sqrt(0.5);
noise_sigmma = sqrt(0.01/2);


% Base line
mu0 = 0.08;
sdim0 = ceil(N*sdim_group_l1_tradeoff(S/N,2*M,mu0,x_sigmma)/(2*M));
m0 = ceil(sdim0+7*sqrt(N/M/2))


%%
pilot_len = ceil(linspace(m0,0.5*N,13));
exp_num = 10;

err_Theta = zeros(length(pilot_len),exp_num);
err_proj = zeros(length(pilot_len),exp_num);
time = zeros(length(pilot_len),exp_num);
iteration = zeros(length(pilot_len),exp_num);

err_Theta_bl = zeros(length(pilot_len),exp_num);
err_proj_bl = zeros(length(pilot_len),exp_num);
time_bl = zeros(length(pilot_len),exp_num);
iteration_bl = zeros(length(pilot_len),exp_num);

for ii=1:length(pilot_len)
    
    L = pilot_len(ii)

    for jj = 1:exp_num 
        
       Theta0 = zeros(N,M)+iscomplex*zeros(N,M)*1i;
       index = randperm(N,S);
       Theta0(index,:) = normrnd(0,x_sigmma,S,M)+iscomplex*normrnd(0,x_sigmma,S,M)*1i;
       
       Q = normrnd(0,sqrt(0.5),L,N)+iscomplex*normrnd(0,sqrt(0.5),L,N)*1i;
       
       noise = normrnd(0,noise_sigmma,L,1)+iscomplex*normrnd(0,noise_sigmma,L,1)*1i;
       
       Y = Q*Theta0+noise;

       if iscomplex
           Q = [real(Q), -imag(Q);imag(Q) real(Q)];
           Y = [real(Y); imag(Y)];
           Theta1 = [real(Theta0); imag(Theta0)];
       else
           Theta1 = Theta0;
       end
       
%           
       if  ii == 1
           mu = mu0;
           sdim = sdim0;           
       else
           [mu,sdim] = calculate_mu(S/N,M,N,L,x_sigmma,sdim0,m0);
       end
       
       noise_power = norm(Y-Q*Theta1,'fro')^2/(L*M);
%        noise_power = 2*noise_sigmma^2
      

       %(L-sdim)/L
       EPS = sqrt(noise_power*(L-sdim)*M)+eps;
       
%        [Theta, ~] = solve_CVX(Q,Y,EPS,mu,0);
       
       [Theta, t, iter] = N83(Q,Y,M,mu,EPS,Theta1);
       
       EPS0 = sqrt(noise_power*(L-sdim0)*M)+eps;
       [Theta_bl, t_bl, iter_bl] = N83(Q,Y,M,mu0,EPS0,Theta1);

%        Theta = tfocs_SCD( prox_l1, { Q, -Y }, prox_l2( EPS ), mu );
        
       err_Theta(ii,jj) = norm(Theta-Theta1,'fro')^2;
       err_proj(ii,jj) =  norm(Q*(Theta-Theta1),'fro')^2/(L*M);
       time(ii,jj) = t;
       iteration(ii,jj) = iter;
       
       err_Theta_bl(ii,jj) = norm(Theta_bl-Theta1,'fro')^2;
       err_proj_bl(ii,jj) =  norm(Q*(Theta_bl-Theta1),'fro')^2/(L*M);
       time_bl(ii,jj) = t_bl;
       iteration_bl(ii,jj) = iter_bl;
    end
end


save smoothed.mat 

%% plot

% cost = mean(iteration,2).*pilot_len'.*(N*M)*4;
% cost_bl = mean(iteration_bl,2).*pilot_len'.*(N*M)*4;
% 
% figure;
% plot(pilot_len,mean(iteration,2),'-sr','LineWidth',1.5,'MarkerSize',8);
% hold on
% plot(pilot_len,mean(iteration_bl,2),'-o','LineWidth',1.5,'MarkerSize',8);
% xlabel('Signature sequence length')
% ylabel('Iterations')
% legend('Aggressive smoothing','Constant smoothing')
% 
% 
% figure;
% semilogy(pilot_len,mean(err_Theta,2),'-sr','LineWidth',1.5,'MarkerSize',8);
% hold on
% semilogy(pilot_len,mean(err_Theta_bl,2),'-o','LineWidth',1.5,'MarkerSize',8);
% xlabel('Signature sequence length')
% ylabel('Estimation error')
% legend('Aggressive smoothing','Constant smoothing')
% 
% 
% figure;
% plot(pilot_len,cost,'-sr','LineWidth',1.5,'MarkerSize',8);
% hold on
% % plot(pilot_len,cost_bl,'-o','LineWidth',1.5,'MarkerSize',8);
% xlabel('Signature sequence length')
% ylabel('Cost')
% % legend('Aggressive smoothing','Constant smoothing')


figure;
semilogy(pilot_len,mean(err_proj,2),'-sr','LineWidth',1.5,'MarkerSize',8);
hold on
% semilogy(pilot_len,mean(err_proj_bl,2),'-o','LineWidth',1.5,'MarkerSize',8);
xlabel('Signature sequence length','Interpreter','latex','FontSize',12)
ylabel('Average squared prediction error $R(\mathbf{\hat{\Theta}})$','Interpreter','latex','FontSize',12)
% legend('Aggressive smoothing','Constant smoothing')


% figure;
% plot(pilot_len,mean(time,2),'-sr','LineWidth',1.5,'MarkerSize',8);
% hold on
% plot(pilot_len,mean(time_bl,2),'-o','LineWidth',1.5,'MarkerSize',8);
% xlabel('Training Length','Interpreter','latex','FontSize',12)
% ylabel('Time(s)','Interpreter','latex','FontSize',12)
% legend('Smoothed Method','Baseline')


avg_time = mean(time,2);
% avg_time_bl = mean(time_bl,2);
figure;
plot(pilot_len,avg_time./avg_time(1),'-sr','LineWidth',1.5,'MarkerSize',8);
hold on
% plot(pilot_len,avg_time_bl./avg_time(1),'-o','LineWidth',1.5,'MarkerSize',8);
xlabel('Signature sequence length','Interpreter','latex','FontSize',12)
ylabel('Normalized run time','Interpreter','latex','FontSize',12)
% legend('Aggressive smoothing','Constant smoothing')



