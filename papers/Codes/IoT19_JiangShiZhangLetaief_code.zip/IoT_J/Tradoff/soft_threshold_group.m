function Theta = soft_threshold_group(X, T)

Theta = zeros(size(X));
for ii = 1:size(Theta,1)
   Theta(ii,:) = shrink(X(ii,:),T)'; 

end

end