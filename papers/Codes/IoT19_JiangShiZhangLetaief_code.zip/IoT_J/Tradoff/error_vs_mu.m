clc;clear;close all;
%% generate data
%rng(1)
iscomplex = 1;

N = 2000; % #devices
M = 10; % #atenna
S = 100; % #active devices

x_sigmma = sqrt(0.5);
noise_sigmma = sqrt(0.01/2);

% Base line
mus = [0.01,0.02,0.04,0.05,0.06,0.07,0.08,0.09,0.1,0.11,0.12,0.13,0.14,0.15,0.2,0.4,0.6,0.8,1];
sdim0 = ceil(N*sdim_group_l1_tradeoff(S/N,2*M,0,x_sigmma)/(2*M));
m0 = ceil(sdim0+7*sqrt(N/M/2));


%%
exp_num = 50;

err_Theta = zeros(length(mus),exp_num);
err_proj = zeros(length(mus),exp_num);
time = zeros(length(mus),exp_num);
iteration = zeros(length(mus),exp_num);

err_Theta_bl = zeros(length(mus),exp_num);
err_proj_bl = zeros(length(mus),exp_num);
time_bl = zeros(length(mus),exp_num);
iteration_bl = zeros(length(mus),exp_num);

for ii=1:length(mus)
    mu=mus(ii)

    parfor jj = 1:exp_num 
        
       Theta0 = zeros(N,M)+iscomplex*zeros(N,M)*1i;
       index = randperm(N,S);
       Theta0(index,:) = normrnd(0,x_sigmma,S,M)+iscomplex*normrnd(0,x_sigmma,S,M)*1i;
       
       Q = normrnd(0,sqrt(0.5),m0,N)+iscomplex*normrnd(0,sqrt(0.5),m0,N)*1i;
       
       noise = normrnd(0,noise_sigmma,m0,1)+iscomplex*normrnd(0,noise_sigmma,m0,1)*1i;
       
       Y = Q*Theta0;

       if iscomplex
           Q = [real(Q), -imag(Q);imag(Q) real(Q)];
           Y = [real(Y); imag(Y)];
           Theta1 = [real(Theta0); imag(Theta0)];
       else
           Theta1 = Theta0;
       end
       

       noise_power = 2*noise_sigmma^2;     
       EPS = sqrt(noise_power*(m0-sdim0)*M)+eps;
       
      % [Theta, ~] = solve_CVX(Q,Y,EPS,mu,0);
       
       [Theta, t, iter] = N83(Q,Y,M,mu,0,Theta1); 
       
       err_Theta(ii,jj) = norm(Theta-Theta1,'fro');
       err_proj(ii,jj) =  norm(Q*(Theta-Theta1),'fro')^2/(m0*M);
       time(ii,jj) = t;
       iteration(ii,jj) = iter;       
    end
end
 

%% plot
figure;
loglog(mus,mean(err_Theta,2),'-o','LineWidth',1.5,'MarkerSize',8);
xlabel('Smooth parameter $\mu$','Interpreter','latex','FontSize',22)
ylabel('Errors $\|\hat{\Theta}-\Theta_0\|_F$','Interpreter','latex','FontSize',22)
axis square

