%Complex
% min ||X||_2,1
% s.t.    AX=Y
% 

clc;clear;close all;

is_complex=1;
exp_num = 10;
N=500;%signal demision
M=3; %number of antennas

ss=42; %nonzeros


sparsity = ss/N;
blocksize = M+is_complex*M;
sdim =sdim_group_l1(sparsity,blocksize); %normalized stat.dim.
location=ceil(N*sdim/blocksize)

ms = 20:20:260;%sample size

mu = 0;

noise_sigma = sqrt(0.0005);


err = zeros(length(ms),length(ss));
err_proj = zeros(length(ms),length(ss));

for jj=1:length(ss)
  s=ss(jj);   
  
  for kk=1:length(ms)
      suc_num=0;
      m=ms(kk)
      parfor ii=1:exp_num
            
        % Data  
        x=zeros(N,M)+is_complex*zeros(N,M)*1i;
        index=randperm(N,s);
        x(index,:)=normrnd(0,sqrt(0.5),s,M)+is_complex*normrnd(0,sqrt(0.5),s,M)*1i;

        A = normrnd(0,sqrt(0.5),m,N)+is_complex*normrnd(0,sqrt(0.5),m,N)*1i; 
        w = normrnd(0,noise_sigma,m,M)+is_complex*normrnd(0,noise_sigma,m,M)*1i; 
        z=A*x + w;  
        
        constrain_value = 0;
        for tt = 1:N
           constrain_value =  constrain_value+norm(x(tt,:));
        end
        constrain_value = constrain_value+0.5*mu*norm(x,'fro')^2;
        
        % solve
        x_hat=solve_cvx(A,z,mu,constrain_value);
        err(kk,ii) =norm(x-x_hat,'fro')^2/(2*noise_sigma^2);
        err_proj(kk,ii) =norm(A*(x-x_hat),'fro')^2/(2*noise_sigma^2);
     end     
   end
end

% save data1.mat 
%%
err_bar = sum(err,2)/exp_num;
err_proj_bar = sum(err_proj,2)/exp_num./(ms'*M);

figure;
% plot(ms,err_bar,'s-');
hold on
plot(location*ones(10,1),linspace(0.2,max(err_proj_bar)+0.2,10),'r--','LineWidth',1.5);
hold on
plot(ms,err_proj_bar,'sb','MarkerSize',8,'LineWidth',2);
hold on
plot(ms(1:5),ones(5,1),'r-.','LineWidth',2);
hold on
plot(ms(5:end),location./ms(5:end),'r-.','LineWidth',2);
xlabel('Training length','Interpreter','latex','FontSize', 12)
ylabel('Normalized Projected error $\frac{R(\mathbf{\hat{\Theta}})}{\sigma^2}$','Interpreter','latex','FontSize',12)
legend(' Phase transition location (theory)','Empirical error','Theory error')
