clc;clear;close all

load noiseless_tradeoff.mat
% load    noiseless_tradeoff_same_magnitude.mat
%% The theoretical probability
% Use real block block problem to approximate complex block problem

M = 2; %number of antennas in BS
blocksize = 2*M;
sparsity = 0.1;
mus = linspace(0,10,100); %smooth param
x_sigmma = sqrt(0.5);

sdim = sdim_group_l1_tradeoff(sparsity,blocksize,mus,x_sigmma); %normalized stat.dim.

samplesize = d*sdim/(blocksize);           
%  plot(mus,samplesize,'y','LineWidth',2)
%% Plot
%\mu=0
colormap('gray');   % set colormap
imagesc(Prob,[0,1]); % draw image and scale colormap to values range
hold on
contour(Prob,[0.95 0.95],'k','LineWidth',1);
contour(Prob,[0.5 0.5],'r','LineWidth',2);
contour(Prob,[0.05 0.05],'m','LineWidth',1);
plot(mus*100/10,samplesize,'y','LineWidth',2)
axis xy
axis square
axis([0 100 0 100])
xlabel('Smooth parameter $\mu$','Interpreter','latex',   'FontSize',22)
ylabel('Training length','Interpreter','latex','FontSize',22)
lgd=legend('95% success','50% success','5% success','Theory','Location','SouthEast');
lgd.FontSize = 20;
ax = gca;
ax.XTick =0:20:100;
ax.YTick =0:25:100;
ax.XTickLabel = {'0','2','4','6','8','10'};
ax.YTickLabel ={'0','25','50','75','100'};
ax.FontSize=13;