d=100;
Ms = [2 5 10];

for ii=1:length(Ms)

M = Ms(ii); %number of antennas in BS
blocksize = 2*M;
sparsity = linspace(0,1,100);
sdim =sdim_group_l1(sparsity,blocksize); %normalized stat.dim.

samplesize=d*sdim/blocksize;           
nonzeros=d*sparsity;  % nonzero groups
plot(nonzeros,samplesize,'LineWidth',1)
hold on
end
axis xy
axis square
axis([0 100 0 100])
legend('M=2','M=5','M=10')