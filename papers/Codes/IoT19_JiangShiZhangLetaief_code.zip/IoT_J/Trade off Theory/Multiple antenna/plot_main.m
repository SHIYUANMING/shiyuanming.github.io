clc;clear;close all

load mu_0_blocksize_2_complex.mat

%% The theoretical probability
% Use real block block problem to approximate complex block problem
%

M = 2; %number of antennas in BS
blocksize = 2*M;
sparsity = linspace(0,1,100);
sdim =sdim_group_l1(sparsity,blocksize); %normalized stat.dim.

samplesize=d*sdim/blocksize;           
nonzeros=d*sparsity;  % nonzero groups
% plot(nonzeros,samplesize,'y','LineWidth',2)
%% Plot
%\mu=0
colormap('gray');   % set colormap
imagesc(Prob,[0,1]); % draw image and scale colormap to values range
hold on
contour(Prob,[0.95 0.95],'k','LineWidth',1);
contour(Prob,[0.5 0.5],'r','LineWidth',1.5);
contour(Prob,[0.05 0.05],'m','LineWidth',1);
plot(nonzeros,samplesize,'y','LineWidth',1.5)
axis xy
axis square
axis([0 100 0 100])
xlabel('Active devices','Interpreter','latex',  'FontSize',20)
ylabel('Training length','Interpreter','latex','FontSize',20)
lgd=legend('95% success','50% success','5% success','Theory','Location','SouthEast');
lgd.FontSize = 20;
ax = gca;
ax.XTick =0:25:100;
ax.YTick =0:25:100;
ax.XTickLabel = {'0','25','50','75','100'};
ax.YTickLabel ={'0','25','50','75','100'};
ax.FontSize=20;