function x=solve_cvx(A,b,mu)
d=size(A,2);
n=size(b,2);
cvx_begin quiet

    variable x(d,n) complex
    expression xx(d) 
    for ii = 1:d
        xx(ii) = norm(x(ii,:));
    end
    
    minimize( norm(xx,1)+0.5*mu*norm(xx,2)^2)
    subject to
        norm(A*x-b,'fro')<=eps;
        
cvx_end

end