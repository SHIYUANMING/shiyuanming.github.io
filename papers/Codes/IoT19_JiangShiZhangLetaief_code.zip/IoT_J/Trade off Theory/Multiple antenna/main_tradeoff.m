%Phase transitions for compressed sensing problems
% clc;clear;close all;
is_complex = 1;
exp_num = 50;
d = 100;

ms = 0:d;
mus = linspace(0,10,length(ms));

s = 10;
M = 2;

% Prob=zeros(length(ms),length(mus));
load noiseless_tradeoff.mat
for jj=61:length(mus)
  mu=mus(jj);
  for kk=1:length(ms)
      suc_num=0;
      m=ms(kk);
      mu 
      m
%       if Prob(kk,jj)
%           continue;
%       end
%       if jj>4&&Prob(kk,jj-1)==0&&Prob(kk,jj-2)==0&&Prob(kk,jj-3)==0&&Prob(kk,jj-4)==0 
%           Prob(kk,jj:end)=0;
%           continue;
%       end
%       if kk>4&&Prob(kk-1,jj)==1&&Prob(kk-2,jj)==1&&Prob(kk-3,jj)==1 &&Prob(kk-4,jj)==1 
%           Prob(kk:end,jj)=1;
%           break;
%       end
     parfor ii=1:exp_num
          
        % Data  
        x=zeros(d,M)+is_complex*zeros(d,M)*1i;
        index=randperm(d,s);
        x(index,:)=normrnd(0,sqrt(0.5),s,M)+is_complex*normrnd(0,sqrt(0.5),s,M)*1i;
%         x(index,:)=randsrc(s,block_size)+is_complex*randsrc(s,block_size)*1i;

        A = normrnd(0,sqrt(0.5),m,d)+is_complex*normrnd(0,sqrt(0.5),m,d)*1i; 
        z=A*x;  
        
        % solve
        x_hat=solve_cvx(A,z,mu);
        err=norm(x-x_hat);
        if err<1e-5
            suc_num=suc_num+1;
        end
      end
      Prob(kk,jj)=suc_num/exp_num;
   end
end

save noiseless_tradeoff.mat Prob d  mus exp_num s ms
