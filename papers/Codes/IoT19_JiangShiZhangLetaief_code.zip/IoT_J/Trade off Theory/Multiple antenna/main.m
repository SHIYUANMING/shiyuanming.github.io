%Complex
% min ||X||_2,1
% s.t.    AX=Y
% 

clc;clear;close all;

is_complex=1;
exp_num=50;
d=100;%signal demision
block_size=2; %number of antennas

ss=0:d; %nonzeros
ms=0: d;%sample size

mu=0;

Prob=zeros(length(ms),length(ss));
for jj=3:length(ss)
  s=ss(jj);   
  
  for kk=4:length(ms)
      suc_num=0;
      m=ms(kk);
      s 
      m     
%       if(kk>4&&Prob(kk-4,jj)==1&&Prob(kk-1,jj)==1&&Prob(kk-2,jj)==1&&Prob(kk-3,jj)==1)
%           Prob(kk:end,jj)=1;
%           break;
%       end
     for ii=1:exp_num
            
        % Data  
        x=zeros(d,block_size)+is_complex*zeros(d,block_size)*1i;
        index=randperm(d,s);
        x(index,:)=normrnd(0,sqrt(0.5),s,block_size)+is_complex*normrnd(0,sqrt(0.5),s,block_size)*1i;

        A = normrnd(0,sqrt(0.5),m,d)+is_complex*normrnd(0,sqrt(0.5),m,d)*1i; 
        z=A*x;  
        
        % solve
        x_hat=solve_cvx(A,z,mu);
        err=norm(x-x_hat,'fro');
        if err<1e-5
            suc_num=suc_num+1;
        end
      end
      Prob(kk,jj)=suc_num/exp_num;
     
   end
end

save mu_0_blocksize_2_complex.mat Prob d block_size mu
