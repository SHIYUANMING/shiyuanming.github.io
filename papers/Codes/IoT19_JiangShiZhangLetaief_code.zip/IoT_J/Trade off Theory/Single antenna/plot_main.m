clc;clear;close all
%% The theoretical probability
d=100;
k=2;


rel_sparsity = linspace(0,1,d);
sdim =sdim_group_l1(rel_sparsity,k)/k;
plot(d*rel_sparsity,d*sdim,'y','LineWidth',2)
%% Plot
%\mu=0
load noiseless.mat 

colormap('gray');   % set colormap
imagesc(Prob,[0,1]); % draw image and scale colormap to values range
hold on
contour(Prob,[0.95 0.95],'k','LineWidth',1);
contour(Prob,[0.5 0.5],'r','LineWidth',2);
contour(Prob,[0.05 0.05],'m','LineWidth',1);
plot(d*rel_sparsity,d*sdim,'y','LineWidth',2)
axis xy
axis square
axis([0 100 0 100])

xlabel('Active devices','Interpreter','latex',   'FontSize',10)
ylabel('Pilot length','Interpreter','latex','FontSize',10)
lgd=legend('95% success','50% success','5% success','Theory','Location','SouthEast');
lgd.FontSize = 13;
ax = gca;
ax.XTick =0:25:100;
ax.YTick =0:25:100;
 ax.XTickLabel = {'0','25','50','75','100'};
ax.YTickLabel ={'0','25','50','75','100'};
ax.FontSize=13;