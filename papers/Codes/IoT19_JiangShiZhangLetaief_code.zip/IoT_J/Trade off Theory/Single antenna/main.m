%nonsmooth noiseless Phase transitions 
%
clc;clear;close all;

exp_num=50;
d=100;%signal demision

ss=0:d; %nonzeros
ms=0:d;%sample size

mu=0;%smooth parameter

Prob=zeros(length(ms),length(ss));
for jj=1:length(ss)
  s=ss(jj);   
  
  for kk=1:length(ms)
      suc_num=0;
      m=ms(kk);
      s 
      m   
%       if jj>4&&Prob(kk,jj-1)==0&&Prob(kk,jj-2)==0&&Prob(kk,jj-3)==0 &&Prob(kk,jj-4)==0 
%           Prob(kk,jj:end)=0;
%           continue;
%       end
%       if kk>4&&Prob(kk-1,jj)==1&&Prob(kk-2,jj)==1&&Prob(kk-3,jj)==1&&Prob(kk-4,jj)==1  
%           Prob(kk:end,jj)=1;
%           break;
%       end
     parfor ii=1:exp_num
            
        % Data     
        h=normrnd(0,sqrt(0.5),s,1)+normrnd(0,sqrt(0.5),s,1)*1i;
        x=zeros(d,1);
        x(randperm(d,s)) = h;        
%         x_tmp=zeros(d/block_size,block_size);
%         index=randperm(d/block_size,s);
%         x_tmp(index,:)=randsrc(s,block_size);      
%         x=reshape(x_tmp',[d,1]);

        A=normrnd(0,sqrt(0.5),m,d)+normrnd(0,sqrt(0.5),m,d)*1i;
        z=A*x;  
        
        % solve
        x_hat=solve_cvx(A,z,mu);
        err=norm(x-x_hat)
        if err<1e-5
            suc_num=suc_num+1;
        end
      end
      Prob(kk,jj)=suc_num/exp_num;
     
   end
end
save noiseless.mat Prob d  mu exp_num
