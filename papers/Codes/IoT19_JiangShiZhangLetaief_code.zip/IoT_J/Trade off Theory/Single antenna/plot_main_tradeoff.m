clc;clear;close all
%% The theoretical probability
d=100;
k=2;
mus=linspace(0,10,100);
x_inf_norm=sqrt(0.5);

sdim =sdim_group_l1_tradeoff(0.1,k,mus,x_inf_norm);

samplesize=sdim*d/k;
%% Plot
%\mu=0
load noiseless_tradeoff.mat

colormap('gray');   % set colormap
imagesc(Prob,[0,1]); % draw image and scale colormap to values range
hold on
contour(Prob,[0.95 0.95],'k','LineWidth',1);
contour(Prob,[0.5 0.5],'r','LineWidth',2);
contour(Prob,[0.05 0.05],'m','LineWidth',1);
plot(mus*100/10,samplesize,'y','LineWidth',2)
axis xy
axis square
axis([0 100 0 100])
xlabel('Smooth parameter $\mu$','Interpreter','latex',   'FontSize',10)
ylabel('Pilot length','Interpreter','latex','FontSize',10)
lgd=legend('95% success','50% success','5% success','Theory','Location','SouthEast');
lgd.FontSize = 13;
ax = gca;
ax.XTick =0:20:100;
ax.YTick =0:10:100;
ax.XTickLabel = {'0','2','4','6','8','10'};
ax.YTickLabel ={'0','10','20','30','40','50','60','70','80','90','100'};
ax.FontSize=13;