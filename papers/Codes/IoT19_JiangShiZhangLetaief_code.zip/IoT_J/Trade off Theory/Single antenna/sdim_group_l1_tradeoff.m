function [sdim_norm,opt_loc]=sdim_group_l1_tradeoff(rho,k,mus,x_sigma)
% SDIM_LONE The statistical dimension of l1 descent cone.
%
% INPUTS (*=optional)
%   rhos:    Vector of normalized sparsities (k/d) between zero and one.
%   k:         block size
%   mu:      smooth parameter
%   x_inf_norm:  max magnitude of blocks
%
% OUTPUTS:
%   sdim_norm: The normalized statistic dimension (sdim_norm = sdim/d).
%   opt_loc*: The optimal integration parameter


sdim_norm= zeros(size(mus));
opt_loc = zeros(size(mus));

for ii = 1:numel(mus)
    
    mu = mus(ii);
 
    c0=2^(k/2-1)*gamma(k/2);
    
%     a_bar=x_sigma*sqrt(pi/2);
%     b_bar=x_sigma^2*2;
   a_bar=x_sigma*sqrt(2)*gamma((k+1)/2)/gamma(k/2);
   b_bar=x_sigma^2*k;
   c1=1+2*mu*a_bar+mu^2*b_bar;
    
    fun_u=@(t) integral(@(u)(u/t-1).*u.^(k-1).*exp(-0.5*u.^2),t,inf);
    fcn = @(t) c1*rho/(1-rho) -fun_u(t)/c0;

    lowerBd = erfcinv(min(sqrt(2)/(1-rho),1-eps(1)));  % Nearly tight as tau->1
%     upperBd = sqrt(2/pi)*(1/rho-1); % Probably not tight as tau->0.
   upperBd=1000;
    try
        %TODO: Deal with some special known cases, use approximations for
        %out-of-bound numbers, etc.
        if rho < eps(1)
            sdim_norm(ii) = 0;
        elseif rho > 1-eps
            sdim_norm(ii) = k;
        else % Actually do the computation then
            t = fzero(fcn,[lowerBd,upperBd]);
            fiB=@(tt)integral(@(u)(u-tt).^2.*u.^(k-1).*exp(-0.5*u.^2),tt,inf );
            sdim_norm(ii) = rho*(k+t^2*c1)+(1-rho)/c0*fiB(t);
        end     
    catch errId
        warning(errId.identifier,errId.message);
        sdim_norm(ii) = NaN;
    end
    
    if nargout > 1
        opt_loc(ii) = t;
    end
end
end % En