function x=solve_cvx(A,b,mu)
d=size(A,2);
cvx_begin quiet
    variable x(d) complex 
    minimize( norm( x, 1 )+0.5*mu*norm(x)^2 )
    subject to
       norm(A*x-b)<=eps;
cvx_end
end