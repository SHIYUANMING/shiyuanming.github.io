function [select_worker, select_worker_num] = user_selection_random(options)
    
    num_worker = options.num_worker;
    chance = options.chance;
    select_num = options.select_num;
    select_worker = randsample_without_replacement(num_worker,select_num,chance);
    select_worker_num = select_num;
end

function y = randsample_without_replacement(N,K,w)

    p = 1:N;
    y = zeros(1,K);
    for i = 1:K
        y(i) = randsample(p,1,true,w);
        w(p == y(i)) = 0;
    end
end