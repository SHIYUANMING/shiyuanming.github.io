function [loss, acc_train, acc_test,channel_use_epoch]=train(data,lr,reg,num_of_round,...
    batch_size,W, params)
if ~isfield(params, 'H_amp')
    options.H_amp = 0;
else
    options.H_amp = params.H_amp;
end

loss = zeros(1,num_of_round);
acc_train = zeros(1,num_of_round);
acc_test = zeros(1,num_of_round);

X_train = data.X_train;
X_test = data.X_test;
y_train = data.y_train;
y_test = data.y_test;

H_channel_set = params.H_channel_set;
num_worker = params.num_worker;
cache_msg_num = params.cache_msg_num;
msg_size = params.msg_size;
worker = params.worker;
epoch = params.epoch;
verb = params.verbosity;
weight = params.weight;

% distributed SGD
loss0= compute_loss_grad(W,X_train,y_train,reg);
y_train_pred = predict(W,X_train);
acc_train0 = mean(y_train == y_train_pred);

y_test_pred = predict(W,X_test);
acc_test0 = mean(y_test == y_test_pred);
channel_use_epoch = zeros(num_of_round,1);


for it_round=1:num_of_round
%    if verb>=1
%        disp(['The message placement is ' mat2str(worker_msg) '\n']);
%    end
    options.over_the_air = params.over_the_air;

    %% worker_selection
    H_channel_coeff = H_channel_set(:,:,it_round);
    options.user_selection_algo = params.user_selection_algo;
    options.num_worker = num_worker;
    options.select_num = params.select_num;
    if ~isfield(params, 'chance')
        options.chance = 1/num_worker*ones(num_worker,1);
    else
        options.chance = params.chance;
    end
    [select_worker, select_worker_num] = user_selection_random(options);
   
    
    %% model update
    if select_worker_num>0
        W_worker = cell(num_worker,1);
    end
   for it_worker_ind = 1: select_worker_num
      it_worker = select_worker(it_worker_ind);%select_worker(it_worker_ind);
      local_data = worker{it_worker};
      W_worker{it_worker} = W;
      num_batch_local = cache_msg_num(it_worker)*msg_size/batch_size;
      for iter_epoch = 1:epoch
          indxs = local_data(randperm(length(local_data)));
          for it = 1:num_batch_local
             indx = indxs((it-1)*batch_size+1:it*batch_size);
             X_batch = X_train(indx,:);
             y_batch = y_train(indx,:);
              [~,grad] = compute_loss_grad(W_worker{it_worker},X_batch,y_batch, reg);
              W_worker{it_worker} = W_worker{it_worker}-lr*grad;
          end
      end
   end

   %% aggregation    over_the_air=0: average,  over_the_air = 1 with noise, over_the_air = 2 with min_mse
   options.weight = weight;
   options.noise_mat = squeeze(params.noise_set(:,:,it_round));
   options.mse_require = params.mse_require;
   if select_worker_num>0
       W = W_aggregation(W_worker,select_worker, H_channel_coeff, options);%   W = W_temp/num_worker;
   end
   [loss(it_round),~]= compute_loss_grad(W,X_train,y_train,reg);
   
   y_train_pred = predict(W,X_train);
   acc_train(it_round) = mean(y_train == y_train_pred);
   
   y_test_pred = predict(W,X_test);
   acc_test(it_round) = mean(y_test == y_test_pred);
   
   if verb
       fprintf(['SNR:%.1f Round: %d/%d, loss:%f, users:%d', mat2str(select_worker) '\n'],-10*log10(options.H_amp),it_round,num_of_round, loss(it_round),select_worker_num);
    end
end
fprintf('================\n')
loss = [loss0,loss];
acc_train = [acc_train0,acc_train];
acc_test = [acc_test0, acc_test];
end

function y=predict(W,X)
     [~,y] = max(X*W,[],2);
end