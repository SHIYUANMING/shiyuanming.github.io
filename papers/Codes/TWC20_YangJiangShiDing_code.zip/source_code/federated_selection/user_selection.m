function [select_worker,select_worker_num,min_mse] = user_selection(H_channel_coeff,mse_require,options)
    
if ~isfield(options, 'over_the_air')
    user_selection_algo = [];
else
    user_selection_algo = options.user_selection_algo;
end
num_worker = options.num_worker;

    if isempty(user_selection_algo)
        num_worker = options.num_worker;
        chance = options.chance;
        select_num = options.select_num;
        select_worker = randsample_without_replacement(num_worker,select_num,chance);
        select_worker_num = select_num;
%     
%         active_users = 1:num_worker; % all workers are selected
%         select_worker_num = num_worker;
        active_users=zeros(num_worker,1);
        active_users(select_worker)=1;
        min_mse = 0;
    elseif strcmp(user_selection_algo,'SDR_L1')
        params.verbosity = 0;
        [active_users,min_mse, select_worker_num] = user_selection_sdr_l1(H_channel_coeff,mse_require,params);
    elseif strcmp(user_selection_algo,'SDR_Re')
        params.maxiter = 1000;
        params.verbosity = 0;
        params.epsilon = 1e-5;
        p=0.5;
        [active_users,min_mse, select_worker_num] = user_selection_sdr_reweighted(H_channel_coeff,mse_require,p,params);
    elseif strcmp(user_selection_algo,'DC')
        params.maxiter = 1000;
        params.verbosity = 0;
        [active_users,min_mse, select_worker_num] = user_selection_DC(H_channel_coeff,mse_require,params);
    end
    select_worker = find(active_users~=0);




end
function y = randsample_without_replacement(N,K,w)

    p = 1:N;
    y = zeros(1,K);
    for i = 1:K
        y(i) = randsample(p,1,true,w);
        w(p == y(i)) = 0;
    end
end