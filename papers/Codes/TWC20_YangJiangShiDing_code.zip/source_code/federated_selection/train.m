function [loss, acc_train, acc_test,channel_use_epoch]=train(data,lr,reg,num_of_round,...
    batch_size,W, params)
loss = zeros(1,num_of_round);
acc_train = zeros(1,num_of_round);
acc_test = zeros(1,num_of_round);

X_train = data.X_train;
X_test = data.X_test;
y_train = data.y_train;
y_test = data.y_test;

[num_train, dim] = size(X_train);
% num_classes = max(y_train);

if ~isfield(params,'antenna_num')
    antenna_num = 1;
else
    antenna_num = params.antenna_num;
end
% user_loc = params.user_loc;
H_channel_set = params.H_channel_set;
mse_require = params.mse_require;
num_worker = params.num_worker;

cache_msg_num = params.cache_msg_num;
msg_size = params.msg_size;
worker = params.worker;

epoch = params.epoch;
verb = params.verbosity;
weight = params.weight;
% distributed SGD
loss0= compute_loss_grad(W,X_train,y_train,reg);
y_train_pred = predict(W,X_train);
acc_train0 = mean(y_train == y_train_pred);

y_test_pred = predict(W,X_test);
acc_test0 = mean(y_test == y_test_pred);
channel_use_epoch = zeros(num_of_round,1);

select_worker_num = num_worker;
for it_round=1:num_of_round
%    if verb>=1
%        disp(['The message placement is ' mat2str(worker_msg) '\n']);
%    end
    %% generate channel and noise
        options.H_amp = params.H_amp;
        options.noise_mat = params.noise_set(:,:,it_round);
        options.over_the_air = params.over_the_air;

%% worker_selection
    H_channel_coeff = H_channel_set(:,:,it_round);
    options.user_selection_algo = params.user_selection_algo;
    options.num_worker = num_worker;
    options.select_num = params.select_num;
    if ~isfield(params, 'chance')
        options.chance = 1/num_worker*ones(num_worker,1);
    else
        options.chance = params.chance;
    end
    [select_worker, select_worker_num,min_mse] = user_selection(H_channel_coeff,mse_require, options);
   
    
    %% model update
    if select_worker_num>0
        W_worker = cell(num_worker,1);
    end
   for it_worker_ind = 1: select_worker_num
      it_worker = select_worker(it_worker_ind);%select_worker(it_worker_ind);
      local_data = worker{it_worker};
      W_worker{it_worker} = W;
      num_batch_local = cache_msg_num(it_worker)*msg_size/batch_size;
      for iter_epoch = 1:epoch
          indxs = local_data(randperm(length(local_data)));
          for it = 1:num_batch_local
             indx = indxs((it-1)*batch_size+1:it*batch_size);
             X_batch = X_train(indx,:);
             y_batch = y_train(indx,:);
              [~,grad] = compute_loss_grad(W_worker{it_worker},X_batch,y_batch, reg);
              W_worker{it_worker} = W_worker{it_worker}-lr*grad;
          end
      end
   end
   %% aggregation    over_the_air=0: average,  over_the_air = 1 with noise, over_the_air = 2 with min_mse
   options.weight = weight;
   if select_worker_num>0
       options.min_mse = min_mse;
       [W, min_mse] = W_aggregation(W_worker,select_worker, H_channel_coeff, options);%   W = W_temp/num_worker;
   end
   
   [loss(it_round),~]= compute_loss_grad(W,X_train,y_train,reg);
   
   y_train_pred = predict(W,X_train);
   acc_train(it_round) = mean(y_train == y_train_pred);
   
   y_test_pred = predict(W,X_test);
   acc_test(it_round) = mean(y_test == y_test_pred);
   
   if verb && ~strcmp(params.over_the_air,'select')
       fprintf([params.over_the_air '  Round: %d/%d, loss:%f, mse:%.3e, users:%d\n'],it_round,num_of_round, loss(it_round),min_mse,select_worker_num);
   elseif verb
       fprintf([params.user_selection_algo '  Round: %d/%d, loss:%f, mse:%.3e, users:%d\n'],it_round,num_of_round, loss(it_round),min_mse,select_worker_num);
   end
end
fprintf('================\n')
loss = [loss0,loss];
acc_train = [acc_train0,acc_train];
acc_test = [acc_test0, acc_test];
end

function y=predict(W,X)
     [~,y] = max(X*W,[],2);
end