function f0 = obj_DC_effecient(M,X, Tset, c, r,rho,lambda)
    f0 = 0; % Objective value of DC problem
    [K, T] = size(M);
    for ii = 1:K
        x_r = M(ii,~Tset(ii,:));  
        x_abs = abs(x_r);
        x_sorted = sort(x_abs,'descend');
        f0 = f0 + rho * (norm(x_r,'fro')^2-x_sorted(1)^2);
    end

    for ii = 1:T
        x_c = M(~Tset(:,ii),ii);
        if ~isempty(x_c)
            x_abs = abs(x_c);
            x_sorted = sort(x_abs,'descend');
            f0 = f0 + lambda * (norm(x_c,'fro')^2-norm(x_sorted(1:min(c,length(x_abs))),'fro')^2);
        end
    end

    sdiag=svds(X,r);
    f0 = f0 + norm(X,'fro')^2- sum(sdiag.^2);
end