function [m, max_mse] = mse_minimization_DC(H,params)
maxiter = params.maxiter;
verb = params.verb;

    [N,K] = size(H);
        tmp = randn(N,N)+1i*randn(N,N);
        M = tmp*tmp';
        [u,~,v] = svd(M);
        M_partial = u(:,1)*v(:,1)';
        obj0 = 0;
        for  iter = 1:maxiter
            cvx_begin quiet
%             cvx_solver sedumi
            variable M(N,N) hermitian semidefinite
            minimize(2*trace(M)- real(trace(M_partial'* M)))
            subject to
                for k=1:K
                    real(H(:,k)'*M*H(:,k))>=1;
                end
            cvx_end
            
%             C = 2*eye(N,N)-M_partial*M_partial';
%             D = H(:,k)*H(:,k)';
%             lambda = eigs(C,N)/eigs(D,1);
            
            
            err = abs(cvx_optval-obj0);

            [u,s,v] = svd(M);
            M_partial = u(:,1)*v(:,1)';
            res = abs(norm(M,'fro')-s(1,1));
            if verb>=2
                fprintf('c:%d, iter:%d/%d, err:%.3e, res:%.3e\n', c, iter, maxiter, err, res);
            end
            obj0 = cvx_optval;
            if err<1e-8
                break;
            end
            if  res<1e-8
                break;
            end
        end
        [u,s,v] = svd(M);
        m = u(:,1)*sqrt(s(1,1));

        max_mse = 0;
        for iter=1:K
            tmp = norm(m)^2/norm(m'*H(:,iter))^2;
            if tmp>max_mse
                max_mse = tmp;
            end
        end

end