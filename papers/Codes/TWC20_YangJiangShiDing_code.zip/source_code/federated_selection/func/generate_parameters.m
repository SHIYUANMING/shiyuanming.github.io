function [Ax, Afun]=generate_parameters(Tset,K,T,H)
%generate_model �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

find_col = @(i,j)(i-1)*T+j;
Ax = sparse(K*T, K*K*T);

for k = 1:K
    for j = 1:T
        for i = 1:K
            if Tset(i,j)
                    tmp = find_col(i,j);
                    Ax( (j-1)*K+k, (tmp-1)*K+k) = H(k,i);
            end
        end
    end
end
 
Afun = @(X)reshape(Ax*X(:),[K,T]);
end
