function Y = row_normalize(X)
Y = zeros(size(X));
for ii = 1:size(X)
    x = X(ii,:);
    max_x = max(abs(x));
    Y(ii,:) = x./max_x;
end

end