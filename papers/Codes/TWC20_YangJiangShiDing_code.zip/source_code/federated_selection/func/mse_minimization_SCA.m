function [m, max_mse] = mse_minimization_SCA(H,a0,params)
    maxiter = params.maxiter;
    [N,K] = size(H);
    if isempty(a0)
        cvx_begin quiet
%         cvx_solver sedumi
        variable M(N,N) hermitian semidefinite
        minimize(trace(M))
        subject to
            for k=1:K
                real(H(:,k)'*M*H(:,k))>=1;
            end
        cvx_end

        [u,s,~] = svd(M);
        a0 = u(:,1)*sqrt(s(1,1));
    end
    
    
    C0 = randn(K,2);
    for k=1:K
        C0(k,:)=[real(a0'*H(:,k)),imag(a0'*H(:,k))];
    end
    
    for  iter = 1:maxiter
        cvx_begin quiet
%         cvx_solver sedumi
        variable a(N,1) complex
        variable C(K,2)
        minimize(sum_square_abs(a))
        subject to
            for k=1:K
                C(k,:)==[real(a'*H(:,k)),imag(a'*H(:,k))];
                sum_square_abs(C0(k,:))+2*C0(k,1)*(C(k,1)-C0(k,1))+2*C0(k,2)*(C(k,2)-C0(k,2))>=1;
            end
        cvx_end
        
        if norm(C-C0)<1e-4
            break;
        end
        C0 = C;
        if sum(isnan(a))
            a=a0;
            fprintf('!err!');
            break;
        end
    end
    
    m=a;

    max_mse = 0;
    for iter=1:K
        tmp = norm(m)^2/norm(m'*H(:,iter))^2;
        if tmp>max_mse
            max_mse = tmp;
        end
    end
end