function [sub_X, sub_M] = DC_subgradient_effecient(M,X, Tset, c, r,rho,lambda)
    Y1 = zeros(size(M));
    Y2 = zeros(size(M));
    [K, T] = size(M);
%     [U,D,V] = svd(X);
%     if r<K
%         D(r*K+r+1:K+1:end) = 0;
%     end
    [U,D,V] = svds(X,r);
    sub_X = 2*U*D*V';

    for ii = 1:K
        x = M(ii,~Tset(ii,:));
        x_abs = abs(x);
        [x_sorted, ~] = sort(x_abs,'descend');
        max_r = x_sorted(1);
        x(x_abs<max_r) = 0;
        x(x_abs>=max_r) = 2*x(x_abs>=max_r);
        Y1(ii,~Tset(ii,:)) = x;
    end

    for ii = 1:T
        x = M(~Tset(:,ii),ii);
        if ~isempty(x)
            x_abs = abs(x);
            [x_sorted, ~] = sort(x_abs,'descend');
            max_r = x_sorted(min(c,length(x_abs)));
            x(x_abs < max_r) = 0;
            x(x_abs >= max_r) = 2*x(x_abs >= max_r);
            Y2(~Tset(:,ii),ii) =  x;
        end
    end
    sub_M = rho * Y1 + lambda * Y2;
end