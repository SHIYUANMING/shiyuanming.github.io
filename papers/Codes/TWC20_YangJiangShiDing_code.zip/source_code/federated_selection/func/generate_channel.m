function [Hn, H] = generate_channel(X_cord)
    K = size(X_cord,2);
    H = zeros(K,K);
    for i = 1:K
        for j = 1:K
            if i~=j
                distance = norm(X_cord(:,i)-X_cord(:,j));
                H(i,j) = 10^((-128.1-37.6*log10(distance))/20)*(randn(1)/sqrt(2)+1i*randn(1)/sqrt(2));
            end
        end
    end
    Hn=H;
    Hn = Hn/max(Hn(:));
end