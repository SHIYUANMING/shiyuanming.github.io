clear all; clc;
rng('default');rng(1);
N = 6; K = 20;

gamma_set = [-15:10:35];%[-10:5:35];%[-10:2:-2, -1:4, 6:2:24];

testnum=500; 
user_num_l1 = zeros(length(gamma_set),testnum);
user_num_reweighted = zeros(length(gamma_set),testnum);
user_num_DC = zeros(length(gamma_set),testnum);
user_num_global = zeros(length(gamma_set),testnum);

params.maxiter = 100;
params.epsilon = 1e-5;
params.verb = 1;
p=0.5;

Max_Iter = 3000; % Maximum number of iterations
epsilon = 1e-5; % The relative error tolerance
parfor ti = 1:testnum
    H = zeros(N,K);
    for k = 1:K
        H(:,k)=(randn(N,1)/sqrt(2)+1i*randn(N,1)/sqrt(2));%10^(-148.1/20)*
    end
    user_num_l1_tmp = zeros(length(gamma_set),1);
    user_num_reweighted_tmp = zeros(length(gamma_set),1);
    user_num_DC_tmp = zeros(length(gamma_set),1);
    user_num_global_tmp = zeros(length(gamma_set),1);
    for ri =1:length(gamma_set)
        gamma = 10^(gamma_set(ri)/10);
        fprintf('testnum: %d, r:%.2e,', ti, gamma_set(ri));
        [m, feasibility] = feasibility_sdr(H, gamma);
        user_num_l1_tmp(ri) = feasibility;
        fprintf(' --SDR L1 feasibility: %d',  feasibility);

        [m, feasibility] = feasibility_DC(H,gamma,params);
        user_num_DC_tmp(ri)=feasibility;
        fprintf(' --DC feasibility: %d ', feasibility);
        
        [m, feasibility] = feasibility_branchbound(H,gamma,Max_Iter,epsilon);
        user_num_global_tmp(ri)=feasibility;
        fprintf(' --branchbound  feasibility: %d ', feasibility);
        
        fprintf('\n');
    end
    user_num_l1(:,ti) = user_num_l1_tmp;
    user_num_reweighted(:,ti) = user_num_reweighted_tmp;
    user_num_DC(:,ti) = user_num_DC_tmp;
    user_num_global(:,ti) = user_num_global_tmp;
end
save('feasibility.mat');
figure,plot(gamma_set, mean(user_num_l1, 2),'s-', 'LineWidth',1.5); hold on
% plot(gamma_set, mean(user_num_reweighted,2),'d-', 'LineWidth',1.5);
plot(gamma_set, mean(user_num_global,2),'d-', 'LineWidth',1.5);
plot(gamma_set, mean(user_num_DC,2),'p-', 'LineWidth',1.5,'MarkerSize',3);
lgnd = legend({'SDR','Global Optimization','Proposed DC'},'Interpreter','latex');
set(lgnd,'color','none');
xlabel('$\gamma$ [dB]','Interpreter','latex');
ylabel('Probability of feasibility');
ylim([0,1]);
xlim([min(gamma_set), max(gamma_set)]);
set(gca,'FontSize',18,'FontName','Times New Roman');