clear all; clc;
rng('default');rng(1);
K = 20;
N_set = [2:8];%[2:2:18];%[-10:2:-2, -1:4, 6:2:24];
Nmax = max(N_set);
N_set_len = length(N_set);
gamma_set = [2,3,4];
gamma_set_len = length(gamma_set);
testnum=500; 
user_num_DC = zeros(gamma_set_len, N_set_len,testnum);

params.maxiter = 100;
params.epsilon = 1e-5;
params.verb = 1;
p=0.5;

Max_Iter = 3000; % Maximum number of iterations
epsilon = 0.0001; % The relative error tolerance

parfor ti = 1:testnum
    Hmax = zeros(Nmax,K);
    for k = 1:K
        Hmax(:,k)=(randn(Nmax,1)/sqrt(2)+1i*randn(Nmax,1)/sqrt(2));%10^(-148.1/20)*
    end
    user_num_DC_tmp = zeros(gamma_set_len, N_set_len);
    for gi =1:length(gamma_set)
        gamma_db = gamma_set(gi);
        gamma = 10^(gamma_db/10);
        for ni =1:length(N_set)
            N = N_set(ni);
            H = Hmax(1:N,:);
            [m, feasibility] = feasibility_DC(H,gamma,params);
            user_num_DC_tmp(gi,ni)=feasibility;
            fprintf('testnum: %d, antenna:%d, DC feasibility: %d \n', ti, N_set(ni),feasibility);
        end
    end
    user_num_DC(:,:,ti)=user_num_DC_tmp;
end
save('antenna.mat');
figure,plot(N_set, mean(squeeze(user_num_DC(1,:,:)), 2),'s-', 'LineWidth',1.5); hold on
plot(N_set, mean(squeeze(user_num_DC(2,:,:)),2),'d-', 'LineWidth',1.5);
plot(N_set, mean(squeeze(user_num_DC(3,:,:)),2),'p-', 'LineWidth',1.5);
lgnd = legend({['$\gamma=$' num2str(gamma_set(1))],['$\gamma=$' num2str(gamma_set(2))],['$\gamma=$' num2str(gamma_set(3))]},'Interpreter','latex');
set(lgnd,'color','none');
xlabel('# antennas');
ylabel('Probability of feasibility');
ylim([0,1]);
xlim([min(N_set), max(N_set)]);
set(gca,'FontSize',18,'FontName','Times New Roman');