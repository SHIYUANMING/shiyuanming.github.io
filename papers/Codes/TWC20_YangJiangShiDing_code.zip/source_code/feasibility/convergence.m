clear all; clc;
rng('default');rng(1);
N = 6; K = 20;

params.maxiter = 1000;
params.epsilon = 1e-5;
params.verb = 3;
p=0.5;


H = randn(N,K);
for k = 1:K
    H(:,k)=(randn(N,1)/sqrt(2)+1i*randn(N,1)/sqrt(2));%10^(-148.1/20)*
end
M0 = randn(N,N)+1i*randn(N,N); M0=M0*M0';
gamma = 10^(5/10);
[m, feasibility,obj_set] = converge_DC(H,gamma,params,M0);
gamma = 10^(3/10);
[m2, feasibility2,obj_set2] = converge_DC(H,gamma,params,M0);
save('convergence.mat');
figure,semilogy((1:length(obj_set))-1, obj_set,'-', 'LineWidth',1.5); hold on
semilogy((1:length(obj_set2))-1, obj_set2,'-', 'LineWidth',1.5); 
legend('\gamma=5','\gamma=3');
xlabel('Iteration','Interpreter','latex');
ylabel('Objective value');
set(gca,'FontSize',14,'FontName','Times New Roman');
xlim([0,50])
ylim([1e-6,inf])
set(gca,'FontSize',14,'FontName','Times New Roman');