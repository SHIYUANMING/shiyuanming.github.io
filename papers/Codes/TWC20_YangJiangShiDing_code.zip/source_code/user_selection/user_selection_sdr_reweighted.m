function [m, num_of_users,active_user] = user_selection_sdr_reweighted(H,gamma,p,params)
maxiter = params.maxiter;
epsilon = params.epsilon;
verb = params.verbosity;
    [N,K] = size(H);
    t0 = randn(K,1);
    w = p/2*(t0.^2+epsilon^2).^(p/2-1);
    for  iter = 1:maxiter
        cvx_begin quiet
        cvx_solver sdpt3
        variable M(N,N) hermitian semidefinite
        variable t(K,1)
        minimize(sum(w.*(t.^2)))
        subject to
            for k=1:K
                trace(M)-gamma*real(H(:,k)'*M*H(:,k))<=t(k);
            end
            trace(M)>=1;
            t>=0;
        cvx_end
        w = p/2*(t.^2+epsilon^2).^(p/2-1);
        if norm(t-t0)<1e-5
            break;
        end
        t0 = t;
    end
    
    [val,ind] = sort(t,'ascend');
    for active_user_num = K:-1:1
        active_user = ind(1:active_user_num);
        [m, feasibility] = feasibility_sdr(H(:,active_user),gamma);
        if verb>=2
            fprintf(' try user num: %d,  feasible:%d\n', active_user_num,feasibility);
        end
        if feasibility
            num_of_users = active_user_num;
            break;
        end
    end
    if ~feasibility
        num_of_users = 0;
        active_user = [];
        m=[];
    end
end