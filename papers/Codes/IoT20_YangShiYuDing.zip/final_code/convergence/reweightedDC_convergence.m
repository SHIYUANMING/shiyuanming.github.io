function [obj_set,number_of_task_set]=reweightedDC_convergence(params,K,N,Hkn,QoS,V0)
verb = params.verbosity;
params.r_set = 10^(QoS/10)*ones(K,1);
params.H = Hkn;
L = params.L;
epsilon=1e-5;
amcoeff=params.amcoeff; 
Pc = params.Pc;
%% preparation: check the feasibility of the problem under the channel realization
%% Stage I: when feasible, solve it with three stage reweighted algorithm
    if verb>=2
        fprintf('Stage I: inducing group sparsity with reweighted least square\n');
    end
    alternating_max=50; alternating_abs=1;
    value2=0;
    mu=1*ones(K,N);
    number_of_task_set = zeros(alternating_max,1);
    obj_set = zeros(alternating_max,1);
    my_obj=0;
    for n=1:N
        for k = 1:K
            w_kn = trace(V0(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L, ((k-1)*N+n-1)*L+1:((k-1)*N+n)*L));
            my_obj = my_obj+1/amcoeff*w_kn+Pc*log(1+w_kn/epsilon)/log(1+1/epsilon);
            mu(k,n)= (1/log(1+1/epsilon))/(w_kn+epsilon);
        end
    end
    rho = 10;
    obj0 =  my_obj+rho*(trace(V0)-norm(V0,2)); 
    obj_set(1) = obj0;
    
    
        

    for alternating =1:alternating_max %interation numbers

        value1=value2; %recode the old objective value
        
        params.weight=mu;
        [V_IRLS, feasible_IRLS, power_beamform,rankisone] = reweightedDC_convergence_iter(params,V0);
        if ~feasible_IRLS
            obj_set=nan; 
            number_of_task_set=nan;
            return;
        end
    
        mu= (1/log(1+1/epsilon))*1./(power_beamform+epsilon);
        
        my_obj=0;
        for n=1:N
            for k = 1:K
                w_kn = trace(V_IRLS(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L, ((k-1)*N+n-1)*L+1:((k-1)*N+n)*L));
                my_obj = my_obj+1/amcoeff*w_kn+Pc*log(1+w_kn/epsilon)/log(1+1/epsilon);
            end
        end
        obj0 =  my_obj+rho*(trace(V_IRLS)-norm(V_IRLS,2)); 
        obj_set(alternating+1) = obj0;
       
        
        [u,s,v] = svd(full(V_IRLS));
        beamformer = u(:,1)*sqrt(s(1));
        Wsolution = zeros(K,N,L);
        
        activeset = zeros(K,N);
        for n = 1:N
            for k=1:K
                Wsolution(k,n,:)=beamformer(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L);
                activeset(k,n) = norm(squeeze(Wsolution(k,n,:)))>1e-3;
            end
        end
        trans_power = 1/amcoeff*norm(beamformer)^2;
        
        number_of_task = sum(activeset(:));
%         power_task = Pc*sum(activeset(:));
%         total_power = trans_power+power_task;
%         obj_set(alternating) = total_power;
        number_of_task_set(alternating+1)=number_of_task;
        
        
        value2=sum(power_beamform(:));
        alternating_abs(alternating)=abs(value1-value2); %absolute value of the adjacent objective values
        if verb>=2
            fprintf('iter:%d, rel error:%.3e, obj:%.3e\n',alternating,alternating_abs(alternating),obj_set(alternating+1));
        end
%         if alternating_abs(alternating)<1e-6
%             break;
%         end
        V0=V_IRLS;
    end
    obj_set = obj_set(1:alternating+1);
    number_of_task_set = number_of_task_set(1:alternating+1);
    
    if ~feasible_IRLS||~rankisone
        obj_set=nan; 
        number_of_task_set = nan;
    else
        [u,s,v] = svd(full(V_IRLS));
        beamformer = u(:,1)*sqrt(s(1));
        Wsolution = zeros(K,N,L);
        
        activeset = zeros(K,N);
        for n = 1:N
            for k=1:K
                Wsolution(k,n,:)=beamformer(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L);
                activeset(k,n) = norm(squeeze(Wsolution(k,n,:)))>1e-3;
            end
        end
        trans_power = 1/amcoeff*norm(beamformer)^2;
        
        number_of_task = sum(activeset(:));
        power_task = Pc*sum(activeset(:));
        total_power = trans_power+power_task;
        feasibility = 1;
    end
 
end