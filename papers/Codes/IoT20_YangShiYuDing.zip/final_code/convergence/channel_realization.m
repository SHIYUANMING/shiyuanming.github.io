function [Hkn_set,H_set] =channel_realization(L, K, N, Area, S, LC, testnum,channel_gain)
% Generate channel matrix

%INPUT:
%N      =# RRHs
%K      =# MUs
%L_set    =# antennas at each RRH
%Area      =length of the area
%epsilon  = spherical error model

%OUTPUT:
% H     = (sum(L_set) x K) channel matrix
% Theta   =  (sum(L_set) x sum(L_set) x K) channel matrix
test_flag = 0;
%%%%%%%%%%%%%%%%Network Realization%%%%%%%%%%%%%%%%%%%%%%%%
B_position=Area.*(rand(2,N)-0.5);  %%RRH positions
% B_position =  [([1:2:2*N-1]/(2*N)-1/2)*Area;zeros(1,N)];
U_position=Area.*(rand(2,K)-0.5);  %% user positions
% distUB = mydist(B_position,U_position);
% H_set = cell(testnum,1);
Hkn_set = cell(testnum,1);
H_set = cell(testnum,1);
% H_trueset = cell(testnum,1);
% D_set = cell(testnum,1);
% Sigma_set = cell(testnum,1);
% s_set = cell(testnum,1);
% H_estimate = cell(testnum,1);

%%  step 1: compute the size of the ellipsoid  s_point
epsilon = 0.05;  delta =0.05; 
tmp = 0;
for k = 0:1:LC/2
    tmp = tmp+ nchoosek(LC/2,k)*(1-epsilon)^k*epsilon^(LC/2-k);
    %fprintf('k=%d, tmp=%.3f\n',k,tmp);
    if tmp>=1-delta
%             fprintf('optimal k=%d\n',k);
        break;
    end
end
ind = k;
    
%%  step 2: generate random channel coefficients
for tt = 1:testnum
    H = zeros(N,L,K,LC); %Theta = zeros(N,L,K,LC);
    H_true = zeros(N,L,K); 
     %%%%%Generate Large-Scale Fading%%%%%%%%%%%%%
     D = zeros(K,N);
     
    Sigma = cell(K,N);
%     Delta = cell(K,N);
    mu = cell(K,N);
    s_point = cell(K,N);
    succ = zeros(K,N);
    Hkn = zeros(N*L,K,S*N+1);
    for k=1:K
        for n=1:N
               d=norm(B_position(:,n)-U_position(:,k));
%                if abs(distUB(n,k)-d)>1e-8
%                    fprintf('err\n');
%                end
               D(n,k) = channel_gain*10^(-128.1/20)*d^(-1.88);%sqrt(exp(normrnd(0,10^0.8))*10^(0.9)); ;%channel_gain*10^(-148.1/20)*d^(-1.88)*sqrt(exp(normrnd(0,10^0.8))*10^(0.9)); %4.4*10^5*d^(-1.88)*10^(-normrnd(0,6.3)/20); %10^(-128.1/20)*d^(-1.88);
               %% Geneate estimated channel
%                B_kn = normrnd(0,1/sqrt(2),L,S)+1i*normrnd(0,1/sqrt(2),L,S);
%                theta = randn(S,LC);
               theta = normrnd(0,1/sqrt(2),S,LC)+1i*normrnd(0,1/sqrt(2),S,LC);
%                theta = theta-mean(theta,2);
%                theta = theta/sqrt(S)%repmat(sqrt(sum(theta.^2)),[S,1]);
               H_true(n,:,k) = D(n,k)*(normrnd(0,1/sqrt(2),L,1)+1i*normrnd(0,1/sqrt(2),L,1));
               H(n,:,k,:)=repmat(vec(H_true(n,:,k)), [1,LC])+1e-2*D(n,k)*theta;   %noise normalized to 1   %%% change here!!!!!!
               
               %% learning shape
               D1 = squeeze(H(n,:,k,1:LC/2));
               D2 = squeeze(H(n,:,k,LC/2+1:end));
               mu{k,n} = mean(D1,2);
               Sigma{k,n} = (D1-repmat(mu{k,n},[1,LC/2]))*(D1-repmat(mu{k,n},[1,LC/2]))'/LC*2;
               s = zeros(LC/2,1);
                for t = 1:LC/2
                    s(t) =  (D2(:,t)-mu{k,n})'*Sigma{k,n}^(-1)*(D2(:,t)-mu{k,n});
                end
                ssort = sort(s);
                s_point{k,n} = ssort(ind);
               
                [Utmp,Stmp,~]=svd(Sigma{k,n});
                Delta = Utmp(:,1:S)*sqrtm(Stmp(1:S,1:S));
                tmp = zeros(L,S*N+1);
                tmp(:,1) = mu{k,n};
                tmp(:,(n-1)*S+2:n*S+1)=sqrt(s_point{k,n})*Delta;
                Hkn((n-1)*L+1:n*L,k,:) = tmp;
                
                %% test shape
                if test_flag
                     for rn = 1:1000
                        theta = randn(S,1)/sqrt(S);
                        hn = vec(H_true(n,:,k))+1e-3*D(n,k)*theta;
                        succ_rn = real((hn-mu{k,n})'*Sigma{k,n}^(-1)*(hn-mu{k,n})-s_point{k,n})<=0;
                        succ(k,n) = succ(k,n)+succ_rn;
                     end
                    fprintf('k=%d,n=%d, succ:%.3f\n', k,n,succ(k,n)/1000);
                end
        end
    end
    Hkn_set{tt} = Hkn;
    H_set{tt}=H;
end


end