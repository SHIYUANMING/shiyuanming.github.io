clc;clear all;
rng('default'); rng(1);
warning('off');
%cvx_solver sedumi
% cvx_solver sdpt3
% cvx_solver mosek
cvx_quiet(true);
%cvx_solver mosek
%cvx_solver scs
%cvx_solver_settings('MAX_ITERS', 10^4, 'SCALE', 100);

%% Problem Data (I)

LC=200; %# channel realizarions
verbosity = 2;
DCBF=1;

%%
Area= 1.6; % KM
N=4; %Number of RAUs
L=2;  % Antennas of each RAU
K=4; %Number of Mobile Users in Each Multicast Group

% Q=[4:2:16];%[3:3:15]';%[-2:0]';%[8:-2:0]';  %QoS in dB
%Q=8;
% epsilon=0.05;  %Shape of the errors
params.ranktol = 1e-4;
%%11111

% Pc=5.6*ones(K,1);  %power consumption of the fronthaul link: P_{nk}^C
amcoeff=1/4; %amplifier efficiency coefficient: eta
params.amcoeff = amcoeff; 
%% Problem Data for Params (II)
params.K=K;
params.L = L;
% params.delta_set=ones(M,1);
params.N=N;
transmit_power = 1;
params.P_set=transmit_power*ones(N,1);   %set of transmit power constraints for all the RAUs
params.Pc = 0.60 ; % 0.1823
noise_power = -136;
mysnr=10*log10(transmit_power)-noise_power;%143;
channel_gain =10^(mysnr/20);
params.sigma_square = 1; %transmit_power*10^(-mysnr/10);
params.verbosity = verbosity;


S = L;
params.S = S;
params.rankone=true; %return rankone solution


Hkn_set=channel_realization(L, K, N, Area, S, LC, 1,channel_gain);
Hkn = Hkn_set{1};


tmp = (randn(K*N*L,K*N*L)+1i*randn(K*N*L,K*N*L))/sqrt(2);
V0 = tmp*tmp';

QoS = 4;
[obj_set1, number_of_task_set1]=reweightedDC_convergence(params,K,N,Hkn,QoS,V0);
QoS = 6;
[obj_set2, number_of_task_set2]=reweightedDC_convergence(params,K,N,Hkn,QoS,V0);
QoS = 8;
[obj_set3, number_of_task_set3]=reweightedDC_convergence(params,K,N,Hkn,QoS,V0);
save('convergence.mat');


LW = 2;
figure; plot(1:length(obj_set1)-1,obj_set1(2:end),'-x','MarkerIndices',[1,10:10:length(obj_set1)],'LineWidth',LW, 'MarkerSize',8); hold on;
    plot(1:length(obj_set2)-1,obj_set2(2:end),'-s','MarkerIndices',[1,10:10:length(obj_set2)],'LineWidth',LW, 'MarkerSize',8);
    plot(1:length(obj_set3)-1,obj_set3(2:end),'-d','MarkerIndices',[1,10:10:length(obj_set3)],'LineWidth',LW, 'MarkerSize',8);
lgd=legend({'$\gamma=4$dB', '$\gamma=6$dB','$\gamma=8$dB'},'interpreter','latex');  
% set(lgd,'color','none');
xlabel('Iteration');
ylabel('Objective value');
ylim([2,7])
yticks([2:1:7])
xlim([1,40])
xticks([1,10:10:40])
set(gca,'FontName','Times New Roman','FontSize',14);

figure; plot(1:length(number_of_task_set1)-1,number_of_task_set1(2:end),'-x','MarkerIndices',[1,10:10:length(number_of_task_set1)],'LineWidth',LW, 'MarkerSize',8); hold on;
    plot(1:length(number_of_task_set2)-1,number_of_task_set2(2:end),'-s','MarkerIndices',[1,10:10:length(number_of_task_set2)],'LineWidth',LW, 'MarkerSize',8);
    plot(1:length(number_of_task_set3)-1,number_of_task_set3(2:end),'-d','MarkerIndices',[1,10:10:length(number_of_task_set3)],'LineWidth',LW, 'MarkerSize',8);
lgd=legend({'$\gamma=4$dB', '$\gamma=6$dB','$\gamma=8$dB'},'interpreter','latex');  
xlabel('Iteration');
ylabel('Total # of tasks');
xlim([1,40])
xticks([1,10:10:40])
ylim([4,16])
set(gca,'FontName','Times New Roman','FontSize',14);