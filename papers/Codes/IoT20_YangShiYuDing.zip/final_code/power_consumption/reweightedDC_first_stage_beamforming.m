function [Vsolution, feasibility,power_beamform,rankisone] = reweightedDC_first_stage_beamforming(params,V0)

%prob_to_socp: maps PARAMS into a struct of SOCP matrices
%input struct 'parms' has the following fields:
%params.N;   %'L': # RRHs
%params.K;    %'K': # MUs
%params.L_set;  %set of antennas at all the RRHs
%params.Active_number;   %number of active RRHs
%params.delta_set; %set of noise covariance

%%%%%%%%%%%%%%Problem Instances%%%%%%%%%%%%%
%params.r_set;  %set of SINR thresholds
%params.H;  %Channel Realization
%params.P_set;   %set of transmit power constraints at all the RRHs

%%%%%%%%Problem Data%%%%%%%
verb = params.verbosity;
K=params.K;   %Numbers of Mobile Users
r_set=params.r_set;     %Nx1 vector: QoS Requirements of Mobile Users for each Muliticast Group: assuming all the users have the same QoS requirments in the same group
L = params.L;
% delta_set=params.delta_set;  %Mx1 vector: noise covariance: assuming same value in the same group
ranktol = params.ranktol;
N=params.N;   %Lx1 vector: RAU antennas set
P_set=params.P_set;  %Nx1 vector: RAU transmit power set
S = params.S;
amcoeff=params.amcoeff; 
sigma_square = params.sigma_square;
H=params.H;  %NxMxK channel matrix: N=sum(N_set), M=length(K_set), K equals the number of mobile users in each group (assuming each group has the same number of mobile users)
Pc = params.Pc;
% activeset = params.activeset;
% weight=params.weight(activeset); %length(Active_index)x1: weigth for each group beamformer
mu = params.weight;
%%%%%%%%CVX%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
V0=[];
if isempty(V0) || sum(isnan(V0(:)))  
    tmp = randn(K*N*L,K*N*L)/sqrt(2)+1i*randn(K*N*L,K*N*L)/sqrt(2);
    V0 = tmp*tmp';
end
[uv,~,~] = svd(full(V0));
V_partial = uv(:,1)*uv(:,1)';
maxiter = 50;
obj0= 1;
rho = 10;
for iter = 1:maxiter
    cvx_quiet(true)
    cvx_begin sdp
    variable V(K*N*L,K*N*L) hermitian semidefinite;   %Variable for beamforming matrix, V_ij^l = v_il*vjl' = V(((i-1)*K+l-1)*L+1:((i-1)*K+l)*L,((j-1)*K+l-1)*L+1:((j-1)*K+l)*L);
    variable lambda(K,N);  % K variables for the S-Lemma in the QoS constraints
    my_obj=0;
        for n=1:N
            for k = 1:K
                my_obj = my_obj+(1/amcoeff+mu(k,n)*Pc)*trace(V(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L, ((k-1)*N+n-1)*L+1:((k-1)*N+n)*L)); % power consumption
            end
        end
    minimize (my_obj+rho*(trace(V)-real(trace(V_partial'*V))))  % group sparsity inducing minimization
    subject to
    
    %% RAUs Transmit Power Constraints
    %% QoS Constraints
    expressions Qk(S*N+1,S*N+1,K)
    expressions QR(S*N+1,S*N+1,K)
    for k=1:K
        gamma = r_set(k);
        for l =1:K
            if l==k
                eta = 1/gamma;
            else
                eta = -1;
            end
            tmp = eta*squeeze(H(:,k,:))'*V((l-1)*N*L+1:l*N*L, (l-1)*N*L+1:l*N*L)*squeeze(H(:,k,:));
            Qk(:,:,k)=Qk(:,:,k)+0.5*(tmp+tmp');
        end
        QR(1,1,k) = -sum(lambda(k,:))-sigma_square;
        for n=1:N
            QR((n-1)*S+2:n*S+1,(n-1)*S+2:n*S+1,k)=lambda(k,n)*eye(S);
        end
        (squeeze(Qk(:,:,k)+QR(:,:,k)))+(squeeze(Qk(:,:,k)+QR(:,:,k)))'==hermitian_semidefinite(N*L+1);
    end
    lambda(:)>=0;
    expression power_rau(N,1)
    for n = 1:N
        for k=1:K
            power_rau(n) = power_rau(n)+trace(V(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L, ((k-1)*N+n-1)*L+1:((k-1)*N+n)*L));
        end
        power_rau(n)<=P_set(n);
    end
    
    cvx_end
    
    if strcmp(cvx_status,'Infeasible') || strcmp(cvx_status,'Failed')
        feasibility = 0;         rankisone = nan;
        Vsolution = nan;     power_beamform = nan;
        return;
    end
    err = abs(obj0-cvx_optval)/obj0;
    if verb>=3
        fprintf("  DC-1st iter:%d, obj:%.2e,err:%.2e\n",iter,cvx_optval,err);
    end
    if err<1e-4
        break;
    end
    
    [uv,s,~] = svd(full(V));
    if s(2,2)<1e-6
        break;
    end
    V_partial = uv(:,1)*uv(:,1)';
    V0 = V;
    obj0 = cvx_optval;
end
    feasibility = 1;
    Vsolution = V;       
    power_beamform = zeros(K,N);
    [u,s,v]=svd(full(V));
    rankisone=s(2,2)<=ranktol;
    for n = 1:N
        for k = 1:K
            V_tmp = V(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L, ((k-1)*N+n-1)*L+1:((k-1)*N+n)*L);
            power_beamform(k,n) = trace(V_tmp);
        end
    end
end 
