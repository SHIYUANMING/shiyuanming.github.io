clc;clear all;
rng('default'); rng(1);
warning('off');
%cvx_solver sedumi
% cvx_solver sdpt3
% cvx_solver mosek
cvx_quiet(true);
%cvx_solver mosek
%cvx_solver scs
%cvx_solver_settings('MAX_ITERS', 10^4, 'SCALE', 100);

%% Problem Data (I)

LC=200; %# channel realizarions
verbosity = 1;
DCBF=1;

%%
Area= 1.6; % KM
N=4; %Number of RAUs
L=2;  % Antennas of each RAU
K=4; %Number of Mobile Users in Each Multicast Group

Q=[4:2:12];%[3:3:15]';%[-2:0]';%[8:-2:0]';  %QoS in dB
%Q=8;
% epsilon=0.05;  %Shape of the errors
params.ranktol = 1e-4;
%%11111

% Pc=5.6*ones(K,1);  %power consumption of the fronthaul link: P_{nk}^C
amcoeff=1/4; %amplifier efficiency coefficient: eta
params.amcoeff = amcoeff; 
%% Problem Data for Params (II)
params.K=K;
params.L = L;
% params.delta_set=ones(M,1);
params.N=N;
transmit_power = 1;
params.P_set=transmit_power*ones(N,1);   %set of transmit power constraints for all the RAUs
params.Pc = 0.60 ; % 0.1823
noise_power = -136;
mysnr=10*log10(transmit_power)-noise_power;%143;
channel_gain =10^(mysnr/20);
params.sigma_square = 1; %transmit_power*10^(-mysnr/10);
params.verbosity = verbosity;

testnum=10;
realization_num=20;

S = L;
params.S = S;
params.rankone=true; %return rankone solution


TotalPower_DCRBF = zeros(length(Q),testnum,realization_num);
TransmitPower_DCRBF = zeros(length(Q),testnum,realization_num);
A_number_DCRBF = zeros(length(Q),testnum,realization_num);

TotalPower_ReDCBF = zeros(length(Q),testnum,realization_num);
TransmitPower_ReDCBF = zeros(length(Q),testnum,realization_num);
A_number_ReDCBF = zeros(length(Q),testnum,realization_num);

TotalPower_L12BF = zeros(length(Q),testnum,realization_num);
TransmitPower_L12BF = zeros(length(Q),testnum,realization_num);
A_number_L12BF = zeros(length(Q),testnum,realization_num);

TotalPower_ReBF = zeros(length(Q),testnum,realization_num);
TransmitPower_ReBF = zeros(length(Q),testnum,realization_num);
A_number_ReBF = zeros(length(Q),testnum,realization_num);

TotalPower_all = zeros(length(Q),testnum,realization_num);
TransmitPower_all = zeros(length(Q),testnum,realization_num);
A_number_all = zeros(length(Q),testnum,realization_num);

feasibility_set = zeros(length(Q),testnum,realization_num);

for ti = 1:realization_num

Hkn_set=channel_realization(L, K, N, Area, S, LC, testnum,channel_gain);
parfor tt = 1:testnum
%     H = H_set{tt};
    Hkn = Hkn_set{tt};
    
    tmp_TotalPower_DCRBF = zeros(length(Q),1);
    tmp_TransmitPower_DCRBF = zeros(length(Q),1);
    tmp_A_number_DCRBF = zeros(length(Q),1);
    tmp_rankisone_DCRBF = zeros(length(Q),1);
    
    tmp_TotalPower_ReDCBF = zeros(length(Q),1);
    tmp_TransmitPower_ReDCBF = zeros(length(Q),1);
    tmp_A_number_ReDCBF = zeros(length(Q),1);
    tmp_rankisone_ReDCBF = zeros(length(Q),1);
    
    tmp_TotalPower_L12BF = zeros(length(Q),1);
    tmp_TransmitPower_L12BF = zeros(length(Q),1);
    tmp_A_number_L12BF = zeros(length(Q),1);
    tmp_rankisone_L12BF = zeros(length(Q),1);
    
    tmp_TotalPower_ReBF = zeros(length(Q),1);
    tmp_TransmitPower_ReBF = zeros(length(Q),1);
    tmp_A_number_ReBF = zeros(length(Q),1);
    tmp_rankisone_ReBF = zeros(length(Q),1);
   
    tmp_TotalPower_all = zeros(length(Q),1);
    tmp_TransmitPower_all = zeros(length(Q),1);
    tmp_A_number_all = zeros(length(Q),1);
    tmp_rankisone_all = zeros(length(Q),1);
    
    tmp_feasibility_set = zeros(length(Q),1);
    
    for lq=length(Q):-1:1
        r_set=10^(Q(lq)/10)*ones(K,1);
        QoS = Q(lq);
        
        [Vsolution_all, rankisone_all,power_task_all, trans_power_all,number_of_task_all,activeset_all,total_power_all,out_status, feasibility_all]=all_beamforming(params,K,N,Hkn,QoS);
        tmp_TotalPower_all(lq)=trans_power_all+sum(power_task_all(:));  %recode current values +(1/amcoeff)*norm(Vsolution,'fro')^2
        tmp_TransmitPower_all(lq)=trans_power_all;
        tmp_A_number_all(lq)=number_of_task_all;
        tmp_rankisone_all(lq) = rankisone_all;
        
        if ~feasibility_all
            tmp_feasibility_set(lq) =0;
            if verbosity>=1
                fprintf('----realization:%d testnum:%d, QoS:%d, feasibility:%d, status: %s \n', ti, tt, QoS, tmp_feasibility_set(lq), out_status);
            end
            break;
        else
            tmp_feasibility_set(lq) =1;
        end

        [Vsolution_L12BF, rankisone_L12BF, power_task_L12BF, trans_power_L12BF,number_of_task_L12BF,activeset_L12BF,total_power_L12BF,feasibility_L12BF] = L12_three_stage_beamforming(params,K,N,Hkn,QoS);     
        tmp_TotalPower_L12BF(lq)=total_power_L12BF;%trans_power_L12BF+power_task_L12BF;  %recode current values +(1/amcoeff)*norm(Vsolution,'fro')^2
        tmp_TransmitPower_L12BF(lq)=trans_power_L12BF;
        tmp_A_number_L12BF(lq)=number_of_task_L12BF;
        tmp_rankisone_L12BF(lq)=rankisone_L12BF;
        
%         if ~feasibility_L12BF
%             tmp_feasibility_set(lq) =0;
%             continue;
%         else
%             tmp_feasibility_set(lq) =1;
%         end
        
        
        [Vsolution_ReDCBF, rankisone_ReDCBF, power_task_ReDCBF, trans_power_ReDCBF,number_of_task_ReDCBF,activeset_ReDCBF, total_power_ReDCBF,feasibility_ReDCBF] = reweightedDC_three_stage_beamforming(params,K,N,Hkn,QoS);     
        tmp_TotalPower_ReDCBF(lq)=trans_power_ReDCBF+power_task_ReDCBF;  %recode current values +(1/amcoeff)*norm(Vsolution,'fro')^2
        tmp_TransmitPower_ReDCBF(lq)=trans_power_ReDCBF;
        tmp_A_number_ReDCBF(lq)=number_of_task_ReDCBF;
        tmp_rankisone_ReDCBF(lq)=rankisone_ReDCBF;
        
%         if ~feasibility_ReDCBF
%             tmp_feasibility_set(lq) =0;
%             continue;
%         else
%             tmp_feasibility_set(lq) =1;
%         end

        [Vsolution_ReBF, rankisone_ReBF,power_task_ReBF, trans_power_ReBF,number_of_task_ReBF,activeset_ReBF,total_power_ReBF,feasibility_ReBF]=reweighted_three_stage_beamforming(params,K,N,Hkn,QoS);
        tmp_TotalPower_ReBF(lq)=total_power_ReBF;%trans_power_ReBF+sum(power_task_ReBF(:));  %recode current values +(1/amcoeff)*norm(Vsolution,'fro')^2
        tmp_TransmitPower_ReBF(lq)=trans_power_ReBF;
        tmp_A_number_ReBF(lq)=number_of_task_ReBF;
        tmp_rankisone_ReBF(lq) = rankisone_ReBF;
        
%         if ~feasibility_ReBF
%             tmp_feasibility_set(lq) =0;
%             continue;
%         else
%             tmp_feasibility_set(lq) =1;
%         end    
        
%         [Vsolution_DCRBF, rankisone_DCRBF, power_task_DCRBF, trans_power_DCRBF,number_of_task_DCRBF,activeset_DCRBF, total_power_DCRBF,feasibility_DCRBF] = DCR_three_stage_beamforming(params,K,N,Hkn,QoS);     
%         tmp_TotalPower_DCRBF(lq)=trans_power_DCRBF+power_task_DCRBF;  %recode current values +(1/amcoeff)*norm(Vsolution,'fro')^2
%         tmp_TransmitPower_DCRBF(lq)=trans_power_DCRBF;
%         tmp_A_number_DCRBF(lq)=number_of_task_DCRBF;
%         tmp_rankisone_DCRBF(lq)=rankisone_DCRBF;
        
%         if ~feasibility_DCRBF
%             tmp_feasibility_set(lq) =0;
%             continue;
%         else
%             tmp_feasibility_set(lq) =1;
%         end
%         
        if verbosity>=1
%             fprintf('testnum:%d, QoS:%d, DC: number of tasks:%d, rankisone:%d, total power:%.2e, %.2e   L12: number of tasks:%d, rankisone:%d, total power:%.2e, %.2e   Re: number of tasks:%d, rankisone:%d, total power:%.2e, %.2e  All: number of tasks:%d, rankisone:%d, total power:%.2e, %.2e\n',tt, QoS,tmp_A_number_DCBF(lq),tmp_rankisone_DCBF(lq),tmp_TotalPower_DCBF(lq),tmp_TransmitPower_DCBF(lq), tmp_A_number_L12BF(lq),tmp_rankisone_L12BF(lq) ,tmp_TotalPower_L12BF(lq),tmp_TransmitPower_L12BF(lq), tmp_A_number_ReBF(lq),tmp_rankisone_ReBF(lq) ,tmp_TotalPower_ReBF(lq),tmp_TransmitPower_ReBF(lq),tmp_A_number_all(lq),tmp_rankisone_all(lq) ,tmp_TotalPower_all(lq),tmp_TransmitPower_all(lq));
            fprintf('ri: %d  test:%d, QoS:%d, ReDC/DCR/L12/Re/All: number of tasks:%d,%d,%d,%d,%d, total power:%.2e,%.2e,%.2e,%.2e,%.2e, transpower:%.2e,%.2e,%.2e,%.2e,%.2e\n',ti,tt, QoS,...
                tmp_A_number_ReDCBF(lq),tmp_A_number_DCRBF(lq),tmp_A_number_L12BF(lq), tmp_A_number_ReBF(lq), tmp_A_number_all(lq), ...
                tmp_TotalPower_ReDCBF(lq),tmp_TotalPower_DCRBF(lq),tmp_TotalPower_L12BF(lq),tmp_TotalPower_ReBF(lq),tmp_TotalPower_all(lq),...
                tmp_TransmitPower_ReDCBF(lq),tmp_TransmitPower_DCRBF(lq),tmp_TransmitPower_L12BF(lq),tmp_TransmitPower_ReBF(lq),tmp_TransmitPower_all(lq));
        end
    end
    
    TotalPower_L12BF(:,tt,ti) = tmp_TotalPower_L12BF;
    TransmitPower_L12BF(:,tt,ti) = tmp_TransmitPower_L12BF;
    A_number_L12BF(:,tt,ti) = tmp_A_number_L12BF;
    
    TotalPower_ReDCBF(:,tt,ti) = tmp_TotalPower_ReDCBF;
    TransmitPower_ReDCBF(:,tt,ti) = tmp_TransmitPower_ReDCBF;
    A_number_ReDCBF(:,tt,ti) = tmp_A_number_ReDCBF;
    
    TotalPower_DCRBF(:,tt,ti) = tmp_TotalPower_DCRBF;
    TransmitPower_DCRBF(:,tt,ti) = tmp_TransmitPower_DCRBF;
    A_number_DCRBF(:,tt,ti) = tmp_A_number_DCRBF;
    
    feasibility_set(:,tt,ti) = tmp_feasibility_set;
    
    TotalPower_ReBF(:,tt,ti) = tmp_TotalPower_ReBF;
    TransmitPower_ReBF(:,tt,ti) = tmp_TransmitPower_ReBF;
    A_number_ReBF(:,tt,ti) = tmp_A_number_ReBF;
       
    TotalPower_all(:,tt,ti) = tmp_TotalPower_all;
    TransmitPower_all(:,tt,ti) = tmp_TransmitPower_all;
    A_number_all(:,tt,ti) = tmp_A_number_all;
end

end

save('main_200.mat');

feasibility_set = reshape(feasibility_set,[length(Q),testnum*realization_num]);

ind = find(sum(feasibility_set==1,2)>0);
feasible_qos = ind(end);
feasibility = (sum(feasibility_set(1:feasible_qos,:)==0)==0);


TotalPower_L12BF(:,~feasibility) = nan;
TransmitPower_L12BF(:,~feasibility) = nan;
A_number_L12BF(:,~feasibility) = nan;

TotalPower_ReDCBF(:,~feasibility) = nan;
TransmitPower_ReDCBF(:,~feasibility) = nan;
A_number_ReDCBF(:,~feasibility) = nan;

TotalPower_ReBF(:,~feasibility) = nan;
TransmitPower_ReBF(:,~feasibility) = nan;
A_number_ReBF(:,~feasibility) = nan;

TotalPower_all(:,~feasibility) = nan;
TransmitPower_all(:,~feasibility) = nan;
A_number_all(:,~feasibility) = nan;
%% Plot everage network power consumption%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mean_TotalPower_L12BF = mean(reshape(TotalPower_L12BF,length(Q),[]),2,'omitnan');
mean_TransmitPower_L12BF = mean(reshape(TransmitPower_L12BF,length(Q),[]),2,'omitnan');
mean_A_number_L12BF = mean(reshape(A_number_L12BF,length(Q),[]),2,'omitnan');

mean_TotalPower_ReDCBF = mean(reshape(TotalPower_ReDCBF,length(Q),[]),2,'omitnan');
mean_TransmitPower_ReDCBF = mean(reshape(TransmitPower_ReDCBF,length(Q),[]),2,'omitnan');
mean_A_number_ReDCBF = mean(reshape(A_number_ReDCBF,length(Q),[]),2,'omitnan');

mean_TotalPower_ReBF = mean(reshape(TotalPower_ReBF,length(Q),[]),2,'omitnan');
mean_TransmitPower_ReBF = mean(reshape(TransmitPower_ReBF,length(Q),[]),2,'omitnan');
mean_A_number_ReBF = mean(reshape(A_number_ReBF,length(Q),[]),2,'omitnan');

mean_TotalPower_all = mean(reshape(TotalPower_all,length(Q),[]),2,'omitnan');
mean_TransmitPower_all = mean(reshape(TransmitPower_all,length(Q),[]),2,'omitnan');
mean_A_number_all = mean(reshape(A_number_all,length(Q),[]),2,'omitnan');


Qe = Q(1:feasible_qos);
TotalPower_ReDC = mean_TotalPower_ReDCBF(1:feasible_qos);
TotalPower_L12 = mean_TotalPower_L12BF(1:feasible_qos);
TotalPower_Re = mean_TotalPower_ReBF(1:feasible_qos);
TotalPower_all = mean_TotalPower_all(1:feasible_qos);

LW = 2;
figure; plot(Qe,TotalPower_ReDC,'-x','LineWidth',LW, 'MarkerSize',8); hold on;
    plot(Qe,TotalPower_Re,'-s','LineWidth',LW, 'MarkerSize',8); 
     plot(Qe,TotalPower_L12,'-d','LineWidth',LW, 'MarkerSize',8); %Network power consumptioin
    plot(Qe,TotalPower_all,'-p','LineWidth',LW, 'MarkerSize',8); 
lgd=legend({'reweighted+DC', 'reweighted +SDR','mixed $\ell_1/\ell_2$+SDR','CB+SDR'},'interpreter','latex');  
set(lgd,'color','none');
xlabel('target SINR [dB]','fontweight','b');
ylabel('total power consumption [W]','fontweight','b');
set(gca,'FontName','Times New Roman','FontSize',14);

TransmitPower_ReDC = mean_TransmitPower_ReDCBF(1:feasible_qos);
TransmitPower_L12 = mean_TransmitPower_L12BF(1:feasible_qos);
TransmitPower_Re = mean_TransmitPower_ReBF(1:feasible_qos);
TransmitPower_all = mean_TransmitPower_all(1:feasible_qos);

figure; plot(Qe,TransmitPower_ReDC,'-x','LineWidth',LW, 'MarkerSize',8); hold on;
    plot(Qe,TransmitPower_Re,'-s','LineWidth',LW, 'MarkerSize',8); 
     plot(Qe,TransmitPower_L12,'-d','LineWidth',LW, 'MarkerSize',8);
    plot(Qe,TransmitPower_all,'-p','LineWidth',LW, 'MarkerSize',8); 
lgd=legend({'reweighted+DC','reweighted +SDR','mixed $\ell_1/\ell_2$+SDR', 'CB+SDR'},'interpreter','latex');
set(lgd,'color','none');
xlabel('target SINR [dB]','fontweight','b');
ylabel('transmit power consumption [W]','fontweight','b');
set(gca,'FontName','Times New Roman','FontSize',14);

A_number_ReDC = mean_A_number_ReDCBF(1:feasible_qos);
A_number_L12 = mean_A_number_L12BF(1:feasible_qos);
A_number_Re = mean_A_number_ReBF(1:feasible_qos);
A_number_all = mean_A_number_all(1:feasible_qos);

figure; plot(Qe,A_number_ReDC,'-x','LineWidth',LW, 'MarkerSize',8); hold on;
    plot(Qe,A_number_Re,'-s','LineWidth',LW, 'MarkerSize',8);
    plot(Qe,A_number_L12,'-d','LineWidth',LW, 'MarkerSize',8);
    plot(Qe,A_number_all,'-p','LineWidth',LW, 'MarkerSize',8);
lgd=legend({'reweighted+DC', 'reweighted +SDR','mixed $\ell_1/\ell_2$+SDR','CB+SDR'},'interpreter','latex');
set(lgd,'color','none');
xlabel('target SINR [dB]','fontweight','b');
ylabel('total number of tasks','fontweight','b');
set(gca,'FontName','Times New Roman','FontSize',14);
ylim([7,17])