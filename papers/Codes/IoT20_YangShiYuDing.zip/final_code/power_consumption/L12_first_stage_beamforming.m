function [Vsolution, feasibility,power_beamform,rankisone,mu_out] = L12_first_stage_beamforming(params)

%prob_to_socp: maps PARAMS into a struct of SOCP matrices
%input struct 'parms' has the following fields:
%params.N;   %'L': # RRHs
%params.K;    %'K': # MUs
%params.L_set;  %set of antennas at all the RRHs
%params.Active_number;   %number of active RRHs
%params.delta_set; %set of noise covariance

%%%%%%%%%%%%%%Problem Instances%%%%%%%%%%%%%
%params.r_set;  %set of SINR thresholds
%params.H;  %Channel Realization
%params.P_set;   %set of transmit power constraints at all the RRHs

%%%%%%%%Problem Data%%%%%%%
% verb = params.verbosity;
K=params.K;   %Numbers of Mobile Users
r_set=params.r_set;     %Nx1 vector: QoS Requirements of Mobile Users for each Muliticast Group: assuming all the users have the same QoS requirments in the same group
L = params.L;
% delta_set=params.delta_set;  %Mx1 vector: noise covariance: assuming same value in the same group
ranktol = params.ranktol;
N=params.N;   %Lx1 vector: RAU antennas set
P_set=params.P_set;  %Nx1 vector: RAU transmit power set
S = params.S;

sigma_square = params.sigma_square;
H=params.H;  %NxMxK channel matrix: N=sum(N_set), M=length(K_set), K equals the number of mobile users in each group (assuming each group has the same number of mobile users)

% activeset = params.activeset;
% weight=params.weight(activeset); %length(Active_index)x1: weigth for each group beamformer
mu=params.mu;
epsilon = 1e-4;
%%%%%%%%CVX%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    cvx_quiet(true)
    cvx_begin sdp
    variable V(K*N*L,K*N*L) hermitian semidefinite;   %Variable for beamforming matrix, V_ij^l = v_il*vjl' = V(((i-1)*K+l-1)*L+1:((i-1)*K+l)*L,((j-1)*K+l-1)*L+1:((j-1)*K+l)*L);
    variable lambda(K,N);  % K variables for the S-Lemma in the QoS constraints
    variable t(K,N)
    
    minimize ((1./mu(:)')*t(:))  % group sparsity inducing minimization
    subject to
    
    %% constraint introduced from objective function
    for n = 1:N
        for k=1:K
            trace(V(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L, ((k-1)*N+n-1)*L+1:((k-1)*N+n)*L))<= t(k,n);
        end
    end

    %% RAUs Transmit Power Constraints
    %% QoS Constraints
    expressions Qk(S*N+1,S*N+1,K)
    expressions QR(S*N+1,S*N+1,K)
    for k=1:K
        gamma = r_set(k);
        for l =1:K
            if l==k
                eta = 1/gamma;
            else
                eta = -1;
            end
            tmp = eta*squeeze(H(:,k,:))'*V((l-1)*N*L+1:l*N*L, (l-1)*N*L+1:l*N*L)*squeeze(H(:,k,:));
            Qk(:,:,k)=Qk(:,:,k)+0.5*(tmp+tmp');
        end
        QR(1,1,k) = -sum(lambda(k,:))-sigma_square;
        for n=1:N
            QR((n-1)*S+2:n*S+1,(n-1)*S+2:n*S+1,k)=lambda(k,n)*eye(S);
        end
        (squeeze(Qk(:,:,k)+QR(:,:,k)))+(squeeze(Qk(:,:,k)+QR(:,:,k)))'==hermitian_semidefinite(N*L+1);
    end
    lambda(:)>=0;
    expression power_rau(N,1)
    for n = 1:N
        for k=1:K
            power_rau(n) = power_rau(n)+trace(V(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L, ((k-1)*N+n-1)*L+1:((k-1)*N+n)*L));
        end
        power_rau(n)<=P_set(n);
    end
    cvx_end
    
    if strcmp(cvx_status,'Infeasible') || sum(isnan(V(:)))>0
        feasibility = 0;         rankisone = nan;
        Vsolution = nan;     power_beamform = nan; mu_out= nan;
    else
        feasibility = 1;
        Vsolution = V;       power_beamform = zeros(K,N);
        [u,s,v]=svds(V);
        rankisone=s(2,2)<=ranktol;
        for n = 1:N
            for k = 1:K
                V_tmp = V(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L, ((k-1)*N+n-1)*L+1:((k-1)*N+n)*L);
                power_beamform(k,n) = trace(V_tmp);
            end
        end
        sum_trace = zeros(K,N);
        for n = 1:N
            for k=1:K
                sum_trace(k,n)= sqrt(trace(V(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L, ((k-1)*N+n-1)*L+1:((k-1)*N+n)*L)+epsilon*eye(L)));
            end
        end
        mu_out = sum_trace/sum(sum_trace(:));
    end
end 
