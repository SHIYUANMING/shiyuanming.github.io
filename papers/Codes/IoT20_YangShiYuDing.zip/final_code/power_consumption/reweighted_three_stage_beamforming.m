function [Wsolution, rankisone,power_task, trans_power,number_of_task,activeset, total_power, feasibility]=reweighted_three_stage_beamforming(params,K,N,Hkn,QoS)
verb = params.verbosity;
params.r_set = 10^(QoS/10)*ones(K,1);
params.H = Hkn;
L = params.L;
epsilon=1e-5;
amcoeff=params.amcoeff; 
H=params.H;
S = params.S;
r_set=params.r_set; 
P_set=params.P_set;
Pc = params.Pc;
sigma_square = params.sigma_square;
%% preparation: check the feasibility of the problem under the channel realization
%     params.activeset=repmat(1:K,[N,1])';
%     [feasibility,out_status,Vsolution]=feasibility_check_beamforming(params);
%     fprintf('Preparation: problem status:%s\n', out_status);
%     if ~feasibility
%         Wsolution = nan;  rankisone = nan;  power_task = nan; trans_power =nan; number_of_task = nan; activeset= nan;
%         return;
%     end

%% Stage I: when feasible, solve it with three stage reweighted algorithm
    if verb>=2
        fprintf('Stage I: inducing group sparsity with reweighted least square\n');
    end
    alternating_max=50; alternating_abs=1;
    value2=0;
    w=1*ones(K,N);
    
    for alternating =1:alternating_max %interation numbers

        value1=value2; %recode the old objective value
        
        
        params.weight=w;
        [V_IRLS, feasible_IRLS, power_beamform] = reweighted_first_stage_beamforming(params);
        
        value2=sum(power_beamform(:));
        w=(1/log(1+1/epsilon))*1./(power_beamform+epsilon);
        alternating_abs(alternating)=abs(value1-value2); %absolute value of the adjacent objective values
        if verb>=2
            fprintf('iter:%d, rel error:%.3e\n',alternating,alternating_abs(alternating));
        end
        if alternating_abs(alternating)<1e-6
            break;
        end
    end
    
%     activeset = power_beamform>1e-6;

    
%% Stage II: RRH Ordering Based on the Approximated Group Sparse Beamformer
if verb>=2
    fprintf('Stage II: Ordering...\n');
end
%         H_est = Hkn(:,:,1); 
%         Value_IRLS=zeros(K,N);
%         for n = 1:N
%             for k = 1:K
%                 Value_IRLS(k,n) = sqrt(amcoeff*norm(H_est((n-1)*L+1:n*L,k))^2)*sqrt(trace(V_IRLS(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L,((k-1)*N+n-1)*L+1:((k-1)*N+n)*L)));
%             end
%         end
        
        % Sparsity Parttern Based RRH Ordering 
      [Task_val,Task_index]=sort(power_beamform(:),'descend');
      Anum = sum(power_beamform(:)>1e-6);
      
        activeset = zeros(K,N);
%% Stage III: Process Deflation Procedure
if verb>=2
    fprintf('Stage III: Process Deflation Procedure\n');
end
activeset(Task_index(1:Anum-1)) = 1;
feasibility = 0;
        for number_of_task=Anum:K*N
            activeset(Task_index(number_of_task)) = 1;
            params.activeset=activeset;
            [Wsolution,feasible,rankisone,power_task,trans_power,out_status,total_power] = reweighted_third_stage_beamforming(params,activeset);
            feasibility = feasible & ~(sum(isnan(Wsolution(:))));
            if verb>=2
                fprintf('QoS:%d, number of tasks:%d, feasibility:%d, rankisone:%d, status:%s\n',QoS,number_of_task,feasibility,rankisone,out_status);
            end
            if feasibility==1
                break;
            end
        end   

        
end