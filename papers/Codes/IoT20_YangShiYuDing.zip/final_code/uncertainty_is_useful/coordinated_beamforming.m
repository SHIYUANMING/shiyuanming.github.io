function [beamformer,feasibility,out_status,total_power] = coordinated_beamforming(params)
%prob_to_socp: maps PARAMS into a struct of SOCP matrices
%input struct 'parms' has the following fields:
%params.N;   %'L': # RRHs
%params.K;    %'K': # MUs
%params.L_set;  %set of antennas at all the RRHs
%params.Active_number;   %number of active RRHs
%params.delta_set; %set of noise covariance

%%%%%%%%%%%%%%Problem Instances%%%%%%%%%%%%%
%params.r_set;  %set of SINR thresholds
%params.H;  %Channel Realization
%params.P_set;   %set of transmit power constraints at all the RRHs

%%%%%%%%Problem Data%%%%%%%
K=params.K;   %Numbers of Mobile Users
r_set=params.r_set;     %Nx1 vector: QoS Requirements of Mobile Users for each Muliticast Group: assuming all the users have the same QoS requirments in the same group
L = params.L;
Pc = params.Pc; % computing power
N=params.N;   %Lx1 vector: RAU antennas set
P_set=params.P_set;  %Nx1 vector: RAU transmit power set
S = params.L;
ranktol = params.ranktol;

sigma_square = params.sigma_square;
H=params.H;  %NxMxK channel matrix: N=sum(N_set), M=length(K_set), K equals the number of mobile users in each group (assuming each group has the same number of mobile users)
% Theta=params.Theta; %NxNxMxK channel covariance matrix

amcoeff=params.amcoeff;  %length(Active_index)x1: weigth for each group beamformer
rankone=params.rankone;  %reture rankone solution or not
epsilon = 1e-7;
cvx_quiet(true)

    cvx_begin sdp %quiet
%     cvx_precision best
    variable v(K,N,L) complex;   
    my_obj=0;
        for n=1:N
            for k = 1:K
                my_obj = my_obj+1/amcoeff*sum_square_abs(v(k,n,:))+Pc; % power consumption
            end
        end
    minimize(my_obj)  % group sparsity inducing minimization
    subject to
    %% RAUs Transmit Power Constraints
    %% QoS Constraints
%     expressions SINR(K,1)
    expressions HkVj(K,K)
    for k=1:K
        for j = 1:K
            for n = 1:N
                HkVj(k,j) = HkVj(k,j)+vec(H(n,:,k))'*vec(v(j,n,:));
            end
        end
    end
    for k = 1:K        
        gamma = r_set(k);
        norm([HkVj(k,:),sqrt(sigma_square)])<=sqrt(1+1/gamma)*real(HkVj(k,k));
        HkVj(k,k)==real(HkVj(k,k));
    end
                        
    expression power_rau(N,1)
    for n = 1:N
        for k=1:K
            power_rau(n) = power_rau(n)+sum_square_abs(v(k,n,:));
        end
        power_rau(n)<=P_set(n);
    end
    cvx_end

    
    feasibility = strcmp(cvx_status,'Solved'); % (strcmp(cvx_status,'Solved') | strcmp(cvx_status,'Inaccurate/Solved')) &
    out_status = cvx_status;
    if feasibility
        beamformer = v; total_power = cvx_optval;
    else
        beamformer = nan; total_power = nan;
    end
end 