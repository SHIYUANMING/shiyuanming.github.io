function [beamformer,feasibility,rankisone,power_task,beam_power,out_status,total_power,lambda] = reweighted_third_stage_beamforming(params,activeset)
%prob_to_socp: maps PARAMS into a struct of SOCP matrices
%input struct 'parms' has the following fields:
%params.N;   %'L': # RRHs
%params.K;    %'K': # MUs
%params.L_set;  %set of antennas at all the RRHs
%params.Active_number;   %number of active RRHs
%params.delta_set; %set of noise covariance

%%%%%%%%%%%%%%Problem Instances%%%%%%%%%%%%%
%params.r_set;  %set of SINR thresholds
%params.H;  %Channel Realization
%params.P_set;   %set of transmit power constraints at all the RRHs

%%%%%%%%Problem Data%%%%%%%
K=params.K;   %Numbers of Mobile Users
r_set=params.r_set;     %Nx1 vector: QoS Requirements of Mobile Users for each Muliticast Group: assuming all the users have the same QoS requirments in the same group
L = params.L;
Pc = params.Pc; % computing power
N=params.N;   %Lx1 vector: RAU antennas set
P_set=params.P_set;  %Nx1 vector: RAU transmit power set
S = params.L;
ranktol = params.ranktol;

sigma_square = params.sigma_square;
H=params.H;  %NxMxK channel matrix: N=sum(N_set), M=length(K_set), K equals the number of mobile users in each group (assuming each group has the same number of mobile users)
% Theta=params.Theta; %NxNxMxK channel covariance matrix

amcoeff=params.amcoeff;  %length(Active_index)x1: weigth for each group beamformer
rankone=params.rankone;  %reture rankone solution or not
epsilon = 1e-7;
cvx_quiet(true)

    cvx_begin sdp %quiet
%     cvx_precision best
    variable V(K*N*L,K*N*L) hermitian semidefinite;   %Variable for beamforming matrix, V_ij^l = v_il*vjl' = V(((i-1)*K+l-1)*L+1:((i-1)*K+l)*L,((j-1)*K+l-1)*L+1:((j-1)*K+l)*L);
    variable lambda(K,N)% nonnegative;  % K variables for the S-Lemma in the QoS constraints
    my_obj=0;
        for n=1:N
            for k = 1:K
                my_obj = my_obj+1/amcoeff*trace(V(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L, ((k-1)*N+n-1)*L+1:((k-1)*N+n)*L))+activeset(k,n)*Pc; % power consumption
            end
        end
    minimize(my_obj)  % group sparsity inducing minimization
    subject to
    
    lambda(:)>=0;
    %% RAUs Transmit Power Constraints
    %% QoS Constraints
    expressions Qk(S*N+1,S*N+1,K)
    expressions QR(S*N+1,S*N+1,K)
    for k=1:K                  
        gamma = r_set(k);
        for l =1:K
            if l==k
                eta = 1/gamma;
            else
                eta = -1;
            end
            tmp = eta*squeeze(H(:,k,:))'*V((l-1)*N*L+1:l*N*L, (l-1)*N*L+1:l*N*L)*squeeze(H(:,k,:));
            Qk(:,:,k)=Qk(:,:,k)+0.5*(tmp+tmp');
        end
        QR(1,1,k) = -sum(lambda(k,:))-sigma_square;
        for n=1:N
            QR((n-1)*S+2:n*S+1,(n-1)*S+2:n*S+1,k)=lambda(k,n)*eye(S);
        end
        (squeeze(Qk(:,:,k)+QR(:,:,k)))+(squeeze(Qk(:,:,k)+QR(:,:,k)))'==hermitian_semidefinite(S*N+1);
    end

    for n = 1:N
        for k = 1:K
            if (~activeset(k,n))
               trace(V(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L,((k-1)*N+n-1)*L+1:((k-1)*N+n)*L)) == 0;%zeros(L,L);
            end
        end
    end
                        
    expression power_rau(N,1)
    for n = 1:N
        for k=1:K
            power_rau(n) = power_rau(n)+activeset(k,n)*trace(V(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L, ((k-1)*N+n-1)*L+1:((k-1)*N+n)*L));
        end
        power_rau(n)<=P_set(n);
    end
    cvx_end

    
    feasibility = strcmp(cvx_status,'Solved'); % (strcmp(cvx_status,'Solved') | strcmp(cvx_status,'Inaccurate/Solved')) &
    out_status = cvx_status;
    
    if ~feasibility
        beamformer = nan; rankisone = nan; power_task = nan; beam_power = nan; total_power=nan; lambda = nan;
    else
        [u,s,~]=svd(full(V));
        rankisone=s(2,2)<=ranktol;
        if rankisone
            v_beam = u(:,1)*sqrt(s(1));
            beamformer = zeros(K,N,L);
            beam_power = 0;%1/amcoeff*norm(v_beam)^2;
            for n = 1:N
                for k = 1:K
                    if activeset(k,n)
                        beamformer(k,n,:) = v_beam(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L);
                        beam_power = beam_power+ real(trace(V(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L,((k-1)*N+n-1)*L+1:((k-1)*N+n)*L)));
                    end
                end
            end
            power_task = Pc*sum(activeset(:));
            total_power = beam_power+power_task;%cvx_optval;
        else
            num_of_samples = 10;
            W_set = cell(num_of_samples,1);
            obj_set = zeros(num_of_samples,1);
            lambda_set = cell(num_of_samples,1);
            for sample_ind = 1:num_of_samples
                [u,s,v] = svd(full(V));
                w = u*sqrt(s)*(randn(N*K*L,1)/sqrt(2)+1i*randn(N*K*L,1)/sqrt(2));

                cvx_begin sdp
%                 cvx_precision best
                variable rand_power(K)% nonnegative;
                variable lambda(K,N)% nonnegative; 
                my_obj=0;
                    for n=1:N
                        for k = 1:K
                            if activeset(k,n)
                                my_obj = my_obj+1/amcoeff*rand_power(k)*norm(w(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L))^2+Pc; % power consumption
                            end
                        end
                    end
                minimize(my_obj)  % group sparsity inducing minimization
                subject to
                
                vec(rand_power)>=0;
                vec(lambda)>=0;
                %% RAUs Transmit Power Constraints
                %% QoS Constraints
                expressions Qk(S*N+1,S*N+1,K)
                expressions QR(S*N+1,S*N+1,K)
                for k=1:K                  
                    gamma = r_set(k);
                    for l =1:K
                        if l==k
                            eta = 1/gamma;
                        else
                            eta = -1;
                        end
                        for i=1:N
                            for j=1:N
                                Qk(:,:,k)=Qk(:,:,k)+rand_power(l)*eta*squeeze(H((i-1)*L+1:i*L,k,:))'*w(((l-1)*N+i-1)*L+1:((l-1)*N+i)*L)*w(((l-1)*N+j-1)*L+1:((l-1)*N+j)*L)'*squeeze(H((j-1)*L+1:j*L,k,:));
                            end
                        end
                    end
                    QR(1,1,k) = -sum(lambda(k,:))-sigma_square;
                    for n=1:N
                        QR((n-1)*S+2:n*S+1,(n-1)*S+2:n*S+1,k)=lambda(k,n)*eye(S);
                    end
                    (squeeze(Qk(:,:,k)+QR(:,:,k)))+(squeeze(Qk(:,:,k)+QR(:,:,k)))'==hermitian_semidefinite(S*N+1);
                end

                for n = 1:N
                    for k = 1:K
                        if (~activeset(k,n))
                            rand_power(k)*norm(w(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L)) == 0;
                        end
                    end
                end
                
                expression power_rau(N,1)
                for n = 1:N
                    for k=1:K
                        if activeset(k,n)
                            power_rau(n) = power_rau(n)+rand_power(k)*norm(w(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L))^2;
                        end
                    end
                    power_rau(n)<=P_set(n);
                end
                cvx_end
    
                if strcmp(cvx_status,'Solved')
                    wsolution = zeros(K,N,L);
                    for n = 1:N
                        for k=1:K
                            if activeset(k,n)
                                wsolution(k,n,:)=sqrt(rand_power(k))*w(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L);
                            end
                        end
                    end

                    obj_set(sample_ind) = cvx_optval;
                    W_set{sample_ind} = wsolution;
                else
                    obj_set(sample_ind) = inf;
                end
                lambda_set{sample_ind} = lambda;
            end
            [total_power, opt_ind]=min(obj_set);
            lambda = lambda_set{opt_ind};
            if ~isinf(total_power) && ~isnan(total_power)
                beamformer = W_set{opt_ind};
                beam_power = 1/amcoeff*norm(beamformer(:))^2;
                power_task = Pc*sum(activeset(:));
                feasibility = 1;
            else
                beamformer = nan; power_task = nan; beam_power = nan; total_power=nan;
                feasibility = 0;
            end
        end
    end
end 