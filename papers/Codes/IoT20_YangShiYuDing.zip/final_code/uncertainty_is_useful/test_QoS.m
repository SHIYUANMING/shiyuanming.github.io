function feasibility = test_QoS(Vsolution_all,H_true,QoS)

[N,L,K] = size(H_true);
r_set=10^(QoS/10)*ones(K,1);
feasibility = zeros(K,1);

% sigma_square=1;
% HkVj = zeros(K,K);
%     for k=1:K
%         for j = 1:K
%             for n = 1:N
%                 HkVj(k,j) = HkVj(k,j)+vec(H_true(n,:,k))'*vec(Vsolution_all(j,n,:));
%             end
%         end
%     end
%     
%     for k = 1:K        
%         gamma = r_set(k);
%         norm([HkVj(k,:),sqrt(sigma_square)])-sqrt(1+1/gamma)*abs(HkVj(k,k))
%     end
%     
for k = 1:K
    sinrk = 0;
    tmp = 0;
    for n = 1:N
        tmp =  tmp+ vec(H_true(n,:,k))'*vec(Vsolution_all(k,n,:));
    end
    sinrk = sinrk+abs(tmp)^2/r_set(k);
    for j = 1:K
        if j ~= k
            tmp = 0;
            for n = 1:N
                tmp = tmp + vec(H_true(n,:,k))'*vec(Vsolution_all(j,n,:));
            end
            sinrk = sinrk - abs(tmp)^2;
        end
    end
    if sinrk<1
        feasibility(k) = 0;
    else
        feasibility(k) = 1;
    end
end