clc;clear all;
addpath('./func');
rng('default'); rng(1);
warning('off');
%cvx_solver sedumi
% cvx_solver sdpt3
% cvx_solver mosek
cvx_quiet(true);
%cvx_solver mosek
%cvx_solver scs
%cvx_solver_settings('MAX_ITERS', 10^4, 'SCALE', 100);

%% Problem Data (I)

LC=1000; %# channel realizarions
testnum = 200;
testnum_D = 200;

epsilon = 0.05;  delta =0.05;
verbosity = 1;
%%
Area= 1.6; % KM
N=4; %Number of RAUs
L=2;  % Antennas of each RAU
K=4; %Number of Mobile Users in Each Multicast Group

QoS = 8;%=[4:2:12];
params.ranktol = 1e-4;
amcoeff=1/4; %amplifier efficiency coefficient: eta
params.amcoeff = amcoeff; 
%% Problem Data for Params (II)
params.K=K;
params.L = L;
% params.delta_set=ones(M,1);
params.N=N;
transmit_power = 1;
params.P_set=transmit_power*ones(N,1);   %set of transmit power constraints for all the RAUs
params.Pc = 0.60 ; % 0.1823
noise_power = -136;
mysnr=10*log10(transmit_power)-noise_power;%143;
channel_gain =10^(mysnr/20);
params.sigma_square = 1; %transmit_power*10^(-mysnr/10);
params.verbosity = verbosity;


S = L;
params.S = S;
params.rankone=true; %return rankone solution


TotalPower_all = zeros(testnum,testnum_D);
TotalPower_random = zeros(testnum,testnum_D);
robust_feasibility_set = zeros(testnum,testnum_D);
random_feasibility_set = zeros(testnum,testnum_D);
robust_QoS = zeros(K,testnum,testnum_D);
random_QoS = zeros(K,testnum,testnum_D);

[B_position,U_position] =loc_realization(K, N, Area);


for ti = 1:testnum_D
    [H_robust_set,H_test_true_set, H_test_observation_set] =channel_uncertainty_realization3(L, K, N, B_position, U_position, LC,channel_gain,testnum);
    tmp_TotalPower_all = zeros(testnum,1);
    tmp_TotalPower_random = zeros(testnum,1);
    tmp_robust_feasibility_set = zeros(testnum,1);
    tmp_random_feasibility_set = zeros(testnum,1);
    tmp_robust_QoS = zeros(K,testnum);    
    tmp_random_QoS = zeros(K,testnum);    
        
    parfor tt = 1:testnum
    %     H = H_set{tt};
        Hkn = H_robust_set{tt};
        H_obs = H_test_observation_set{tt};
        H_true = H_test_true_set{tt};

        

        [Vsolution_all, rankisone_all,power_task_all, trans_power_all,number_of_task_all,activeset_all,total_power_all,out_status, feasibility_all]=all_beamforming(params,K,N,Hkn,QoS);
        tmp_TotalPower_all(tt)=trans_power_all+sum(power_task_all(:));  %recode current values +(1/amcoeff)*norm(Vsolution,'fro')^2
        tmp_robust_feasibility_set(tt) = feasibility_all;


        if feasibility_all
            tmp_robust_QoS(:,tt) = test_QoS(Vsolution_all,H_true,QoS);
        end

        [Vsolution_random, total_power_random,out_status_random, feasibility_random]=all_beamforming_random(params,K,N,H_obs,QoS);
        tmp_random_feasibility_set(tt) = feasibility_random;
        tmp_TotalPower_random(tt)=total_power_random;

        if feasibility_random
            tmp_random_QoS(:,tt) = test_QoS(Vsolution_random,H_true,QoS);
        end


        if verbosity>=1
           fprintf(['test:%d, QoS:%d, Robust/Random: total power:%.2e,%.2e, feasibility: %d,%d Target-QoS:',mat2str(tmp_robust_QoS(:,tt)),mat2str(tmp_random_QoS(:,tt)), '\n'],tt, QoS,tmp_TotalPower_all(tt),tmp_TotalPower_random(tt),tmp_robust_feasibility_set(tt),tmp_random_feasibility_set(tt));
        end
    end
    robust_feasibility_set(:,ti) = tmp_robust_feasibility_set;
    random_feasibility_set(:,ti) = tmp_random_feasibility_set;

    robust_QoS(:,:,ti) = tmp_robust_QoS;
    random_QoS(:,:,ti) = tmp_random_QoS;

    TotalPower_random(:,ti) = tmp_TotalPower_random;       
    TotalPower_all(:,ti) = tmp_TotalPower_all;
end

save('main_feasibility_uncertainty3(sample=1000).mat');



mean_TotalPower_all = mean(TotalPower_all(:));
mean_TotalPower_random = mean(TotalPower_random(:));

robust_QoS_tmp = reshape(robust_QoS,[K,testnum*testnum_D]);
mean_robust_QoS = mean(robust_QoS_tmp,2);

random_QoS_tmp = reshape(random_QoS,[K,testnum*testnum_D]);
mean_random_QoS = mean(random_QoS_tmp,2);



LW = 2;
figure; plot(Q,mean_TotalPower_random,'-d','LineWidth',LW, 'MarkerSize',8); hold on;
    plot(Q,mean_TotalPower_all,'-p','LineWidth',LW, 'MarkerSize',8); 
lgd=legend({'random', 'robust'},'interpreter','latex');  
set(lgd,'color','none');
xlabel('target SINR [dB]','fontweight','b');
ylabel('total power consumption [W]','fontweight','b');
set(gca,'FontName','Times New Roman','FontSize',14);

figure; plot(Q,mean_random_QoS,'-d','LineWidth',LW, 'MarkerSize',8); hold on;
    plot(Q,mean_robust_QoS,'-p','LineWidth',LW, 'MarkerSize',8);
lgd=legend({'random', 'robust'},'interpreter','latex'); 
set(lgd,'color','none');
xlabel('Users','fontweight','b');
ylabel('probability of feasibility','fontweight','b');
set(gca,'FontName','Times New Roman','FontSize',14);