function [Wsolution, rankisone,power_task, trans_power,number_of_task,activeset,total_power,out_status, feasibility]=all_beamforming(params,K,N,Hkn,QoS)
verb = params.verbosity;
params.r_set = 10^(QoS/10)*ones(K,1);
params.H = Hkn;
number_of_task = K*N;
activeset = ones(K,N);
%% Stage III: Process Deflation Procedure

params.activeset=activeset;
[Wsolution,feasibility,rankisone,power_task,trans_power,out_status,total_power,lambda] = reweighted_third_stage_beamforming(params,activeset);

if verb>=2
    fprintf('QoS:%d, number of tasks:%d, feasibility:%d, rankisone:%d, status:%s\n',QoS,number_of_task,feasibility,rankisone,out_status);
end

end