function [H_robust_set,H_test_true_set, H_test_observation_set] =channel_uncertainty_realization3(L, K, N, B_position, U_position, LC,channel_gain,testnum)


H_robust_set = cell(testnum,1);
H_test_true_set = cell(testnum,1);
H_test_observation_set = cell(testnum,1);
%%  step 1: compute the size of the ellipsoid  s_point
epsilon = 0.05;  delta =0.05;
tmp = 0;
for k = 0:1:LC/2
    tmp = tmp+ nchoosek(LC/2,k)*(1-epsilon)^k*epsilon^(LC/2-k);
    if tmp>=1-delta
        break;
    end
end
ind = k;

%%  step 2: generate random channel coefficients
% training robust for once
H_true_train = zeros(N,L,K); 
H_train_robust = zeros(N,L,K,LC); %Theta = zeros(N,L,K,LC);
D = zeros(K,N);%Generate Large-Scale Fading
Sigma = cell(K,N);
mu = cell(K,N);
s_point = cell(K,N);
Hkn_training = zeros(N*L,K,L*N+1);
%% training data
for k=1:K
    for n=1:N
        d=norm(B_position(:,n)-U_position(:,k));
        D(n,k) = channel_gain*10^(-128.1/20)*d^(-1.88);
        H_true_train(n,:,k) = D(n,k)*(normrnd(0,1/sqrt(2),L,1)+1i*normrnd(0,1/sqrt(2),L,1));
        theta = normrnd(0,1/sqrt(2),L,LC)+1i*normrnd(0,1/sqrt(2),L,LC);
        H_train_robust(n,:,k,:)=repmat(vec(H_true_train(n,:,k)), [1,LC])+1e-2*D(n,k)*theta;   %noise normalized to 1
       %% learning shape
        D1 = squeeze(H_train_robust(n,:,k,1:LC/2));
        D2 = squeeze(H_train_robust(n,:,k,LC/2+1:end));
        mu{k,n} = mean(D1,2);
        Sigma{k,n} = (D1-repmat(mu{k,n},[1,LC/2]))*(D1-repmat(mu{k,n},[1,LC/2]))'/LC*2;
        s = zeros(LC/2,1);
        for t = 1:LC/2
            s(t) =  (D2(:,t)-mu{k,n})'*Sigma{k,n}^(-1)*(D2(:,t)-mu{k,n});
        end
        ssort = sort(s);
        s_point{k,n} = ssort(ind);

        [Utmp,Stmp,~]=svd(Sigma{k,n});
        Delta = Utmp(:,1:L)*sqrtm(Stmp(1:L,1:L));
        tmp = zeros(L,L*N+1);
        tmp(:,1) = mu{k,n};
        tmp(:,(n-1)*L+2:n*L+1)=sqrt(s_point{k,n})*Delta;
        Hkn_training((n-1)*L+1:n*L,k,:) = tmp;
    end
end

for dr = 1:testnum
    H_true_test = zeros(N,L,K);
    H_test_observe = zeros(N,L,K);
    %% test data
    for k=1:K
        for n=1:N
            d=norm(B_position(:,n)-U_position(:,k));
            D(n,k) = channel_gain*10^(-128.1/20)*d^(-1.88);
            H_true_test(n,:,k) = D(n,k)*(normrnd(0,1/sqrt(2),L,1)+1i*normrnd(0,1/sqrt(2),L,1));
            theta = normrnd(0,1/sqrt(2),1,L)+1i*normrnd(0,1/sqrt(2),1,L);
            H_test_observe(n,:,k) = H_true_test(n,:,k)+1e-2*D(n,k)*theta;
        end
    end
    H_test_true_set{dr} = H_true_test;
    H_test_observation_set{dr} = H_test_observe;
    
    %% build robust approximation

    
%     Hkn = zeros(N*L,K,L*N+1);
    Hkn = Hkn_training;
    for k=1:K
        for n=1:N
            Hkn((n-1)*L+1:n*L,k,1)= H_test_observe(n,:,k);
        end
    end
    H_robust_set{dr} = Hkn;
    
    
end

end