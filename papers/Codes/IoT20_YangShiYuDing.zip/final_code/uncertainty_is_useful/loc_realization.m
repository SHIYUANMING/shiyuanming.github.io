function [B_position,U_position] =loc_realization(K, N, Area)
% Generate random located APs and MUs

    B_position = Area.*(rand(2,N)-0.5); %AP position
    U_position = Area.*(rand(2,K)-0.5); %MU position

end