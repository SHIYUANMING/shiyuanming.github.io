function [Wsolution, total_power,out_status, feasibility]=all_beamforming_random(params,K,N,H,QoS)
verb = params.verbosity;
params.r_set = 10^(QoS/10)*ones(K,1);
params.H = H;
%% Stage III: Process Deflation Procedure

% params.activeset=activeset;
[Wsolution,feasibility,out_status,total_power] = coordinated_beamforming(params);

if verb>=2
    fprintf('QoS:%d, feasibility:%d,status:%s\n',QoS,feasibility,out_status);
end

end