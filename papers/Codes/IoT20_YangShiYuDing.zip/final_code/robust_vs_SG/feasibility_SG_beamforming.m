function [Wsolution, rankisone,power_task, trans_power,number_of_task,activeset, total_power, feasibility]=reweightedDC_SG_beamforming(params,K,N,H_mat,QoS)
verb = params.verbosity;
params.r_set = 10^(QoS/10)*ones(K,1);
L = params.L;
epsilon=1e-5;
amcoeff=params.amcoeff; 
r_set=params.r_set; 
Pc = params.Pc;
%% preparation: check the feasibility of the problem under the channel realization
%% Stage I: when feasible, solve it with three stage reweighted algorithm
    if verb>=2
        fprintf('Stage I: inducing group sparsity with reweighted least square\n');
    end
    alternating_max=50; alternating_abs=1;
    value2=0;
    mu=1*ones(K,N);
    tmp = randn(K*N*L,K*N*L)/sqrt(2)+1i*randn(K*N*L,K*N*L)/sqrt(2);
    V0=tmp*tmp';
    for alternating =1:alternating_max %interation numbers

        value1=value2; %recode the old objective value
        
        
        params.weight=mu;
        [V_IRLS, feasible_IRLS, power_beamform] = SG_beamforming(params,H_mat,V0);
        if ~feasible_IRLS
            Wsolution = nan;
            power_task=nan; 
            trans_power=nan;
            number_of_task=nan; 
            activeset=nan;
            total_power=nan; 
            feasibility=0;
            return;
        end
        mu= (1/log(1+1/epsilon))*1./(power_beamform+epsilon);
        value2=sum(power_beamform(:));
        alternating_abs(alternating)=abs(value1-value2); %absolute value of the adjacent objective values
        if verb>=2
            fprintf('iter:%d, rel error:%.3e\n',alternating,alternating_abs(alternating));
        end
        if alternating_abs(alternating)<1e-6
            break;
        end
        V0=V_IRLS;
    end
    
    if ~feasible_IRLS||~rankisone
        Wsolution = nan;
        power_task=nan; 
        trans_power=nan;
        number_of_task=nan; 
        activeset=nan;
        total_power=nan; 
        feasibility=0;
    else
        [u,s,v] = svd(full(V_IRLS));
        beamformer = u(:,1)*sqrt(s(1));
        Wsolution = zeros(K,N,L);
        
        activeset = zeros(K,N);
        for n = 1:N
            for k=1:K
                Wsolution(k,n,:)=beamformer(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L);
                activeset(k,n) = norm(squeeze(Wsolution(k,n,:)))>1e-3;
            end
        end
        trans_power = 1/amcoeff*norm(beamformer)^2;
        
        number_of_task = sum(activeset(:));
        power_task = Pc*sum(activeset(:));
        total_power = trans_power+power_task;
        feasibility = 1;
    end
 
end