clc;clear all;
rng('default'); rng(1);
warning('off');
% cvx_solver sedumi
cvx_solver sdpt3
% cvx_solver mosek
cvx_quiet(true);
%cvx_solver mosek
%cvx_solver scs
%cvx_solver_settings('MAX_ITERS', 10^4, 'SCALE', 100);

%% Problem Data (I)

LC=200; %# channel realizarions
verbosity = 1;
DCBF=1;

%%
Area= 1.6; % KM
N=4; %Number of RAUs
L=2;  % Antennas of each RAU
K=4; %Number of Mobile Users in Each Multicast Group

Q=[2:3:26];%[2,4:2:12,16,20,24,28];%[3:3:15]';%[-2:0]';%[8:-2:0]';  %QoS in dB
%Q=8;
% epsilon=0.05;  %Shape of the errors
params.ranktol = 1e-4;
%%11111

% Pc=5.6*ones(K,1);  %power consumption of the fronthaul link: P_{nk}^C
amcoeff=1/4; %amplifier efficiency coefficient: eta
params.amcoeff = amcoeff; 
%% Problem Data for Params (II)
params.K=K;
params.L = L;
% params.delta_set=ones(M,1);
params.N=N;
transmit_power = 1;
params.P_set=transmit_power*ones(N,1);   %set of transmit power constraints for all the RAUs
params.Pc = 0.60 ; % 0.1823
noise_power = -136;
mysnr=10*log10(transmit_power)-noise_power;%143;
channel_gain =10^(mysnr/20);
params.sigma_square = 1; %transmit_power*10^(-mysnr/10);
params.verbosity = verbosity;


S = L;
params.S = S;
params.rankone=true; %return rankone solution


testnum = 25;

[Hkn_set,H_set]=channel_realization(L, K, N, Area, S, LC, testnum,channel_gain);



feasibility_set_SG = zeros(length(Q),testnum);
feasibility_set_robust = zeros(length(Q),testnum);

parfor ti = 1:testnum
    Hkn = Hkn_set{ti};
    H_mat = H_set{ti};
    tmp_feasibility_set_SG = zeros(length(Q),1);
    tmp_feasibility_set_robust = zeros(length(Q),1);
    for lq=1:length(Q)
        r_set=10^(Q(lq)/10)*ones(K,1);
        QoS = Q(lq);
        [feasibility_SG,out_status_SG,Vsolution_SG, feasible_SG] = feasibility_check_SG(params,QoS,H_mat);
        [feasibility,out_status,Vsolution, feasible] = feasibility_check_Robust(params,QoS,Hkn);
        tmp_feasibility_set_SG(lq) =feasible_SG;
        tmp_feasibility_set_robust(lq) =feasible;
        if verbosity>=1
            fprintf('testnum:%d, QoS:%d, SG/Robust feasibility:  %d/%d, status: %s/%s \n', ti, QoS, tmp_feasibility_set_SG(lq),tmp_feasibility_set_robust(lq), out_status_SG,out_status);
        end
    end
    feasibility_set_SG(:,ti)=tmp_feasibility_set_SG;
    feasibility_set_robust(:,ti)=tmp_feasibility_set_robust;
end
  

save('main_robust_SG.mat');


LW = 2;
figure; plot(Q,mean(feasibility_set_SG,2),'-x','LineWidth',LW, 'MarkerSize',8); hold on;
    plot(Q,mean(feasibility_set_robust,2),'-s','LineWidth',LW, 'MarkerSize',8); 
legend({'Scenario Generation', 'Proposed Approach'});
xlabel('target SINR [dB]','fontweight','b');
ylabel('probability of feasibility','fontweight','b');
set(gca,'FontName','Times New Roman','FontSize',14);