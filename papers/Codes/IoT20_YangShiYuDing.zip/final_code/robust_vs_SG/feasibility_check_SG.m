function [feasibility,out_status,Vsolution, feasible] = feasibility_check_SG(params,QoS,H_mat)

%prob_to_socp: maps PARAMS into a struct of SOCP matrices
%input struct 'parms' has the following fields:
%params.N;   %'L': # RRHs
%params.K;    %'K': # MUs
%params.L_set;  %set of antennas at all the RRHs
%params.Active_number;   %number of active RRHs
%params.delta_set; %set of noise covariance

%%%%%%%%%%%%%%Problem Instances%%%%%%%%%%%%%
%params.r_set;  %set of SINR thresholds
%params.H;  %Channel Realization
%params.P_set;   %set of transmit power constraints at all the RRHs

%%%%%%%%Problem Data%%%%%%%
% verb = params.verbosity;
K=params.K;   %Numbers of Mobile Users
N=params.N;   %Lx1 vector: RAU antennas set
r_set = 10^(QoS/10)*ones(K,1);
% r_set=params.r_set;     %Nx1 vector: QoS Requirements of Mobile Users for each Muliticast Group: assuming all the users have the same QoS requirments in the same group
L = params.L;
% delta_set=params.delta_set;  %Mx1 vector: noise covariance: assuming same value in the same group
% ranktol = params.ranktol;

P_set=params.P_set;  %Nx1 vector: RAU transmit power set
S = params.S;

sigma_square = params.sigma_square;
LC = size(H_mat,4);
% LC = 30;
% H_samples = zeros(N*L,K,LC);
% for lc = 1:LC
%     for k = 1:K
%         for n = 1:N
%             H_samples((n-1)*L+1:n*L,k,lc) = H_mat(n,:,k,lc);
%         end
%     end
% end


%%%%%%%%CVX%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    cvx_quiet(true)
    cvx_begin sdp
    variable V(K*N*L,K*N*L) hermitian semidefinite;   %Variable for beamforming matrix, V_ij^l = v_il*vjl' = V(((i-1)*K+l-1)*L+1:((i-1)*K+l)*L,((j-1)*K+l-1)*L+1:((j-1)*K+l)*L);
    minimize (0)  % group sparsity inducing minimization
    subject to

    expressions QR(K,LC)
%     expressions QR(S*N+1,S*N+1,K)
    for lc = 1:LC
        H_si = squeeze(H_mat(:,:,:,lc));
        for k=1:K
            gamma = r_set(k);
            for l =1:K
                if l==k
                    eta = 1/gamma;
                else
                    eta = -1;
                end
                for n=1:N
                    QR(k,lc) = QR(k,lc)+eta*vec(H_si(n,:,k))'*V(((l-1)*N+n-1)*L+1:((l-1)*N+n)*L, ((l-1)*N+n-1)*L+1:((l-1)*N+n)*L)*vec(H_si(n,:,k));
                end
            end
            real(QR(k,lc))-sigma_square>=0;
        end
    end
    expression power_rau(N,1)
    for n = 1:N
        for k=1:K
            power_rau(n) = power_rau(n)+trace(V(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L, ((k-1)*N+n-1)*L+1:((k-1)*N+n)*L));
        end
        power_rau(n)<=P_set(n);
    end
    
    cvx_end



%     cvx_quiet(true)
%     cvx_begin 
%     variable V(K*N*L,1) complex;   %Variable for beamforming vector, V = [v_{11},...,v_{N1},..,v_{NK}]
% %     minimize (sum_square_abs(V))  % group sparsity inducing minimization
%     subject to
% 
%     expression VL(K+1,K,LC)
%     %% QoS Constraints
%     for lc = 1:LC
%         H_si = squeeze(H_mat(:,:,:,lc));
%         for k=1:K
%             gamma = r_set(k);
%             for l = 1:K
%                 for n = 1:N
%                     VL(l,k,lc)=VL(l,k,lc)+vec(H_si(n,:,k))'*V(((l-1)*N+n-1)*L+1:((l-1)*N+n)*L);
%                 end
%             end
%             VL(K+1,k,lc) = sqrt(sigma_square);
%             norm(squeeze(VL(:,k,lc)))<=sqrt(1+1/gamma)*real(VL(k,k,lc));%real(V((k-1)*N*L+1:k*N*L)'*vec(H_samples(:,k,lc)));
%             VL(k,k,lc) == real(VL(k,k,lc));
% %             V((k-1)*N*L+1:k*N*L)'*vec(H_samples(:,k,lc))== real(V((k-1)*N*L+1:k*N*L)'*vec(H_samples(:,k,lc)));
%         end
%     end
%     %% RAUs Transmit Power Constraints
%     expression power_rau(N,1)
%     for n = 1:N
%         for k=1:K
%             power_rau(n) = power_rau(n)+sum_square_abs(V(((k-1)*N+n-1)*L+1:((k-1)*N+n)*L));
%         end
%         power_rau(n)<=P_set(n);
%     end
% 
%     cvx_end
    
    out_status = cvx_status;
    feasibility = strcmp(cvx_status,'Solved');%~strcmp(cvx_status,'Infeasible');
    Vsolution = V;
    feasible = ~(strcmp(cvx_status,'Infeasible')||strcmp(cvx_status,'Failed'));
end