function [ch]= channel(K, M, N, pL_AU, pL_AI, pL_IU)
% K: number of user
% M: number of antenna at AP
% N: number of elements at IRS
%% small scale fading
beta = 0; % 0 - Rayleigh, 1 - LoS
gain = 1;
% downlink channel
Gd = sqrt(pL_AI)*channel_rician(beta, N, M); % AP to IRS
gd = channel_rician(0, M, K);
hd = channel_rician(0, N, K);
for k = 1:K
    gd(:, k) = sqrt(pL_AU(k))*gd(:, k);                                          % AP to user
    hd(:, k) = sqrt(pL_IU(k))*hd(:, k)*gain;                                     % IRS to user
end
% uplink channel
% Gu = Gd';
% gu = gd;
% hu = hd;
Gu = sqrt(pL_AI)*channel_rician(beta, M, N);   % IRS to AP
gu = channel_rician(0, M, K);
hu = channel_rician(0, N, K);
for k = 1:K
    gu(:, k) = sqrt(pL_AU(k))*gu(:, k);                                          % user to AP
    hu(:, k) = sqrt(pL_IU(k))*hu(:, k)*gain;                                     % user to IRS
end
%% phase-shift matrices
thetaD = randn(N, 1) + 1j*rand(N, 1);
thetaD = thetaD./abs(thetaD);
ThetaD = diag(thetaD);
ThetaU = ThetaD';

fd = nan(size(gd'));
for k = 1:K
    fd(k, :) = hd(:, k)'*ThetaD*Gd + gd(:, k)';
end
fu = fd';

%% efficiency of conversion
efficiency = rand(K, 1)*100;
%%
ch.hd = hd;
ch.Gd = Gd;
ch.gd = gd;
ch.hu = hu;
ch.Gu = Gu;
ch.gu = gu;
ch.fd = fd;
ch.fu = fu;
ch.efficiency = efficiency;

ch.tu = ThetaU;
ch.td = ThetaD;
end