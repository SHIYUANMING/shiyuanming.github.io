function [p, feasible] = find_P_DC(v, ch, params, fd, fu)
gu = ch.gu;
hu = ch.hu;
Gu = ch.Gu;
eff = ch.efficiency;
verb = params.verb;
pmax = params.pmax;
iter_max = params.iter_max;

[~, K] = size(ch.fu);
[~, N] = size(ch.Gu);

%% select an initial point
tmp = randn(N+1, N+1) + 1j*randn(N+1, N+1);
P = tmp*tmp';
[U, ~, ~] = svd(P);
P_partial = U(:, 1)*U(:, 1)';

%%
obj0 = 0;
for  iter = 1:iter_max
    %% solve subproblems
    cvx_begin quiet
    variable P(N+1,N+1) hermitian semidefinite
    minimize (real(trace((eye(N+1) - P_partial')*P)))
    subject to
        s = 0;
        for k = 1:K
            a_H = v'*Gu*diag(hu(:, k));
            a = a_H';
            c = v'*gu(:, k);
            R = [a*a', a*c; c'*a', 0];
            Ck = eff(k)*(norm(fd(k, :))^2)*pmax;
            s = s + inv_pos(real(Ck*(trace(R*P)+c'*c)));
        end
        1 - s >= 0;
        real(diag(P)) == 1;
    cvx_end
    
    if strcmp(cvx_status, 'Infeasible') == 1 || isnan(norm(P)) || isinf(norm(P))
        feasible = 0;
        p = nan;
        return;
    end
    err = abs(cvx_optval - obj0);
    obj0 = cvx_optval;
    
    %% subgradient
    [U, S] = svd(P);
    P_partial = U(:, 1)*U(:, 1)';
    res = abs(norm(P, 'fro') - S(1, 1));
    if verb
        fprintf(' iter:%d/%d, err:%.3e, res:%.3e\n', iter, iter_max, err, res);
    end
    if err < 1e-6 && res < 1e-8
        break;
    end
end
[U, S] = svd(P);
p_bar = U(:, 1)*sqrt(S(1, 1));
p = p_bar(1:N)/p_bar(end);
p = p./abs(p);
feasible = check_feasible(v, p, [], ch, fd, fu, pmax);

end