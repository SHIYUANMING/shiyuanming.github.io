function [feasible] = check_feasible_EP(v, p, q, ch, fd, fu, pmax)
gu = ch.gu;
hu = ch.hu;
Gu = ch.Gu;
gd = ch.gd;
hd = ch.hd;
Gd = ch.Gd;
eff = ch.efficiency;
[~, K] = size(gu);

feasible = 1;
if isempty(p)
    for k = 1:K
        Ck = eff(k)*(norm(fd(k, :))^2)*pmax/K;
        temp = real(Ck*(norm(v'*fu(:, k))^2));
        if temp + 1e-6 < 1
            feasible = 0;
        end
    end
elseif isempty(q)
    Theta = diag(p);
    for k = 1:K
        Ck = eff(k)*(norm(fd(k, :))^2)*pmax/K;
        temp = real(Ck*(norm(v'*(Gu*Theta*hu(:, k)+gu(:, k)))^2));
        if temp + 1e-6 < 1
            feasible = 0;
        end
    end
else
    Theta = diag(q);
    for k = 1:K
        Ck = eff(k)*(norm(v'*fu(:, k))^2)*pmax/K;
        temp = real(Ck*(norm(hd(:, k)'*Theta*Gd+gd(:, k)')^2));
        if temp + 1e-6 < 1
            feasible = 0;
        end
    end
end

end