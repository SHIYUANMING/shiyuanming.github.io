function [v, mse, feasible, Rv] = find_V_SDR_EP(ch, fd, fu, pmax)
eff = ch.efficiency;
[M, K] = size(fu);
%%
cvx_begin quiet
cvx_solver sdpt3
variable V(M, M) hermitian semidefinite
minimize (real(trace(V)))
subject to
    for k = 1:K
        Ck = eff(k)*(norm(fd(k, :))^2)*pmax/K;
        real(Ck*trace(V*fu(:, k)*fu(:, k)')) >= 1;
    end
cvx_end

if strcmp(cvx_status, 'Infeasible') == 1
    feasible = 0;
    mse = nan;
    v = [];
    Rv = [];
    return;
end

[Vt, S] = svd(V);
sv = diag(S);
rank_err = sum(sv(2:end));
label = rank_err/sv(1);
if label < 1e-6
    Rv = 1;
    v = Vt(:, 1)*sqrt(S(1, 1));
else
    Rv = nan;
    z = chol(V, 'lower');
    xi = (randn(M, 1) + 1j*randn(M, 1))/sqrt(2);
    xi = z*xi;
    minConstraint = inf;
    for k = 1:K
        Ck = eff(k)*(norm(fd(k, :))^2)*pmax/K;
        temp = real(Ck*(norm(xi'*fu(:, k))^2));
        if temp < minConstraint
            minConstraint = temp;
        end
    end
    v = xi/sqrt(minConstraint);
end

%% check feasibility
feasible = 1;
if check_feasible_EP(v, [], [], ch, fd, fu, pmax) == 0
    feasible = 0;
    mse = nan;
    return;
end

%% compute MSE
mse = 0;
for iter = 1:K
    temp = ((norm(v)^2)*K)/(eff(iter)*pmax*(norm(fd(iter, :))^2)*(norm(v'*fu(:, iter))^2));
    if temp > mse
        mse = temp;
    end
end

end