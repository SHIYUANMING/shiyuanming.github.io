clc, clear;
% close all;
% rng(0);
%%
K = 8; % number of users
M = 20; % number of antennas at AP
N = 30; % number of elements at IRS

params.iter_max = 5e2;
params.pmax = 1e3;
params.noise = 1e-6;

params.verb = true;
params.rho = 1;

for fi = 1:1
    [pL_AU, pL_AI, pL_IU] = location(K);
    [ch] = channel(K, M, N, pL_AU, pL_AI, pL_IU);
    %%
    fprintf('***** SDR_EP *****\n');
    [mse_sdr_ep] = alterMin_SDR_EP(ch, params);
    fprintf('***** DC_EP *****\n');
    [mse_dc_ep] = alterMin_DC_EP(ch, params);
    fprintf('***** SDR *****\n');
    [mse_sdr] = alterMin_SDR(ch, params);
    fprintf('***** DC *****\n');
    [mse_dc] = alterMin_DC(ch, params);
    
    %%
    figure;
    subplot(2, 1, 1);
    semilogy(mse_sdr_ep, 'bv-.', 'LineWidth', 2, 'MarkerSize', 8);
    hold on;
    semilogy(mse_dc_ep, '>-.', 'LineWidth', 2, 'MarkerSize', 8);
    xlabel('Iterations');
    ylabel('MSE');
    legend('Alternating SDR (EPA)', 'Alternating DC (EPA)');
    grid on;
    
    figure;
    subplot(2, 1, 2);
    semilogy(mse_sdr, 'o-', 'LineWidth', 2, 'MarkerSize', 8);
    hold on;
    semilogy(mse_dc, 's-', 'LineWidth', 2, 'MarkerSize', 8);
    xlabel('Iterations');
    ylabel('MSE');
    legend('Alternating SDR', 'Alternating DC');
    grid on;
end