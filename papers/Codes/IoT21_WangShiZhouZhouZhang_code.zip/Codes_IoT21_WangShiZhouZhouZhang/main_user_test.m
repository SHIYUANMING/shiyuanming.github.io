clc, clear;
%%
K = 8:2:20; % number of devices
M = 20;     % number of antennas at AP
N = 30;     % number of elements at IRS

params.iter_max = 5e2;
params.pmax = 1e3;
params.noise = 1e-6;
params.verb = false;
params.rho = 1;
pmax = params.pmax;
noise = params.noise;

cnt = 24;
loc = 5;
%%
mse_nIRS = nan(length(K), 1);
mse_DC_EP = nan(length(K), 1);
mse_DC = nan(length(K), 1);
%%
for i = 1:length(K)
    k = K(i);
    
    t_nIRS = 0;
    t_DC_EP = 0;
    t_DC = 0;
    
    fprintf('K = %d\n', i)
    
    n_no = 0;
    n_yes = 0;
    
    label = true;
    ln = 0;
    %%
    while true
        ln = ln + 1;
        [pL_AU, pL_AI, pL_IU] = location(k);
        parfor c = 1:cnt
            tag_sdr_ep = true;
            tag_dc_ep = true;
            tag_sdr = true;
            
            [ch] = channel(k, M, N, pL_AU, pL_AI, pL_IU);
            
            %% without IRS
            n_no = n_no + 1;
            [v0, ~, feasible, Rv] = find_V_nIRS_SDR(ch, pmax);
            if feasible
                [m_nIRS] =  find_V_nIRS_DC(ch, params, v0, Rv);
                m_nIRS = m_nIRS*noise;
            else
                m_nIRS = 0;
            end
            if isequal(m_nIRS, 0) || isequal(feasible, 0)
                n_no = n_no - 1;
            end
            t_nIRS = t_nIRS + m_nIRS;
            
            if label
                %% with IRS (EPA)
                n_yes = n_yes + 1;
                [m_DC_EP] = alterMin_DC_EP(ch, params);
                tmp2_ep = m_DC_EP(~isnan(m_DC_EP));
                if isempty(tmp2_ep)
                    n_yes = n_yes - 1;
                    tag_dc_ep = false;
                    
                    tmp2_ep = 0;
                end
                t_DC_EP = t_DC_EP + tmp2_ep(end);
                
                %% with IRS
                if tag_dc_ep
                    [m_DC] = alterMin_DC(ch, params);
                    tmp2 = m_DC(~isnan(m_DC));
                    if isempty(tmp2)
                        n_yes = n_yes - 1;
                        
                        tmp2 = 0;
                        t_DC_EP = t_DC_EP - tmp2_ep(end);
                    end
                    t_DC = t_DC + tmp2(end);
                end
            end
        end
        %%
        if n_yes >= loc*cnt
            label = false;
        end
        if (n_no >= loc*cnt) || ((ln >= 10*loc*cnt) && ~label)
            break;
        end
    end
    if isequal(t_nIRS, 0)
        mse_nIRS(i) = nan;
    else
        mse_nIRS(i) = t_nIRS/n_no;
    end
    mse_DC_EP(i) = t_DC_EP/n_yes;
    mse_DC(i) = t_DC/n_yes;
end
%%
save main_user_test.mat;
%%
figure;
fig1 = semilogy(K, mse_nIRS, 'd-', 'LineWidth', 2, 'MarkerSize', 8);
hold on;
grid on;
fig3 = semilogy(K, mse_DC_EP, 'x-', 'LineWidth', 2, 'MarkerSize', 8);
fig5 = semilogy(K, mse_DC, 's-', 'LineWidth', 2, 'MarkerSize', 8);
set(fig1, 'MarkerFaceColor', get(fig1, 'Color'));
set(fig3, 'MarkerFaceColor', get(fig3, 'Color'));
set(fig5, 'MarkerFaceColor', get(fig5, 'Color'));
xlabel('Number of IoT devices', 'FontSize', 14);
ylabel('MSE', 'FontSize', 14);
legend('Without IRS', 'With IRS (EPA)', 'With IRS');