function [mse_set] = alterMin_SDR_EP(ch, params)
hd = ch.hd;
Gd = ch.Gd;
gd = ch.gd;
hu = ch.hu;
Gu = ch.Gu;
gu = ch.gu;
fd = ch.fd;
fu = ch.fu;

noise = params.noise;
pmax = params.pmax;
iter_max = params.iter_max;

[~, K] = size(gu);
%%
mse_set = nan(iter_max,1);
for i = 1:iter_max
    if params.verb
        fprintf('Solving... %d/%d.\n', i, iter_max);
    end
    %% aggregation beamforming vector
    [v, mse, feasibleV] = find_V_SDR_EP(ch, fd, fu, pmax);
    mse_set(i) = mse*noise;
    if i > 1 && abs(mse_set(i) - mse_set(i-1)) < 1e-4
        break;
    end
    if feasibleV == 0
        mse_set = nan;
        if params.verb
            fprintf('The solution v_sdr_ep is infeasible.\n');
        end
        break;
    end
	%% uplink phase-shift  
    [thetaU, feasibleP] = find_P_SDR_EP(v, ch, fd, fu, pmax);
    if feasibleP == 0
        if params.verb
            fprintf('The solution p_sdr_ep is infeasible.\n');
        end
        break;
    else
        ThetaU = diag(thetaU);
        fu = nan(size(gu));
        for k = 1:K
            fu(:, k) = Gu*ThetaU*hu(:, k) + gu(:, k);
        end
    end
	%% downlink phase-shift
    [thetaD, feasibleQ] = find_Q_SDR_EP(v, ThetaU, ch, fd, fu, pmax);
    if feasibleQ == 0
        if params.verb
            fprintf('The solution q_sdr_ep is infeasible.\n');
        end
        break;
    else
        ThetaD = diag(thetaD);
        fd = nan(size(gd'));
        for k = 1:K
            fd(k, :) = hd(:, k)'*ThetaD*Gd + gd(:, k)';
        end
    end
end
end