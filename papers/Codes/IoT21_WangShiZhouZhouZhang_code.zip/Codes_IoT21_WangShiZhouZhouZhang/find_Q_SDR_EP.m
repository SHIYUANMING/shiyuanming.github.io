function [q, feasible, Rq]= find_Q_SDR_EP(v, ThetaU, ch, fd, fu, pmax)
gu = ch.gu;
Gu = ch.Gu;
hu = ch.hu;
hd = ch.hd;
gd = ch.gd;
Gd = ch.Gd;
eff = ch.efficiency;

[~,K] = size(gu);
[~,N] = size(Gu);

cvx_begin quiet
variable Q(N+1,N+1) hermitian semidefinite
minimize (0)
subject to
    for k = 1:K
        a = diag(hd(:, k)')*Gd;
        b = [a; gd(:, k)'];
        Ck = eff(k)*(norm(v'*(Gu*ThetaU*hu(:, k) + gu(:, k)))^2)*pmax/K;
        real(Ck*trace(Q*(b*b'))) >= 1;
    end
    real(diag(Q)) == 1;
cvx_end

if strcmp(cvx_status, 'Infeasible') == 1
    feasible = 0;
    q = [];
    return;
end

[U, S] = svd(Q);
sv = diag(S);
rank_err = sum(sv(2:end));
label = rank_err/sv(1);
if label < 1e-6
    Rq = 1;
    q_bar = conj(U(:, 1)*sqrt(S(1, 1)));
    q = q_bar(1: N)/q_bar(end);
    feasible = check_feasible_EP(v, p, q, ch, fd, fu, pmax);
else
    Rq = nan;
    for i = 1:1000
        z = chol(Q, 'lower');
        xi = (randn(N+1, 1) + 1j*randn(N+1, 1))/sqrt(2);
        xi = z*xi;
        minConstraint = inf;
        for k = 1:K
            a = diag(hd(:, k)')*Gd;
            b = [a; gd(:, k)'];
            Ck = eff(k)*(norm(v'*(Gu*ThetaU*hu(:, k) + gu(:, k)))^2)*pmax/K;
            temp = real(Ck*trace(xi*xi'*(b*b')));
            if temp < minConstraint
                minConstraint = temp;
            end
        end
        q_bar = conj(xi/sqrt(minConstraint));
        q = q_bar(1: N)/q_bar(end);
        q = q./abs(q);
        feasible = check_feasible_EP(v, diag(ThetaU), q, ch, fd, fu, pmax);
        if feasible == 1
            break;
        end
    end
end

if feasible == 0
    q = [];
end

end