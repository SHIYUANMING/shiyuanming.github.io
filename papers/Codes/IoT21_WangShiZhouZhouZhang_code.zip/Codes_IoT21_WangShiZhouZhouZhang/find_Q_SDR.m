function [q, feasible]= find_Q_SDR(v, ThetaU, ch, fd, fu, pmax)
gu = ch.gu;
Gu = ch.Gu;
hu = ch.hu;
hd = ch.hd;
gd = ch.gd;
Gd = ch.Gd;
eff = ch.efficiency;

[~, K] = size(gu);
[~, N] = size(Gu);

cvx_begin quiet
variable Q(N+1, N+1) hermitian semidefinite
minimize (0)
subject to
    s = 0;
    for k = 1:K
        a = diag(hd(:, k)')*Gd;
        b = [a; gd(:, k)'];
        Ck = eff(k)*(norm(v'*(Gu*ThetaU*hu(:, k) + gu(:, k)))^2)*pmax;
        s = s + inv_pos(real(Ck*trace(Q*(b*b'))));
    end
    1 - s >= 0;
    real(diag(Q)) == 1;
cvx_end

if strcmp(cvx_status, 'Infeasible') == 1
    feasible = 0;
    q = [];
    return;
end

[U, S] = svd(Q);
sv = diag(S);
rank_err = sum(sv(2:end));
label = rank_err/sv(1);
if label < 1e-6
    q_bar = conj(U(:, 1)*sqrt(S(1, 1)));
    q = q_bar(1: N)/q_bar(end); % get q
    feasible = check_feasible(v, p, q, ch, fd, fu, pmax);
else
    for i = 1:1000
        maxSum = 0;
        [U, S] = svd(Q);
        for cnt = 1:1e2
            z = (randn(N+1, 1) + 1j*randn(N+1, 1))/sqrt(2);
            qn = U*sqrt(S)*z;
            s = 0;
            for k = 1:K
                a = diag(hd(:, k)')*Gd;
                b = [a; gd(:, k)'];
                Ck = eff(k)*(norm(v'*(Gu*ThetaU*hu(:, k) + gu(:, k)))^2)*pmax;
                s = s + inv_pos(real(Ck*trace(qn*qn'*(b*b'))));
            end
            if 1 - s >= 0
                temp = s;
                if temp > maxSum
                    maxSum = temp;
                    q_opt = qn;
                end
            end
        end
        q_bar = conj(q_opt);
        q = q_bar(1: N)/q_bar(end);
        q = q./abs(q);
        feasible = check_feasible(v, diag(ThetaU), q, ch, fd, fu, pmax);
        if feasible == 1
            break;
        end
    end
end

end