function [v, mse, feasible, Rv] = find_V_SDR(ch, fd, fu, pmax)
%% find optimal aggregation beamforming vector
eff = ch.efficiency;
[M, K] = size(fu);
%%
cvx_begin sdp quiet
cvx_solver sdpt3
variable V(M, M) hermitian semidefinite
minimize (real(trace(V)))
subject to
    s = 0;
    for k = 1:K
        Ck = eff(k)*(norm(fd(k, :))^2)*pmax;
        s = s + inv_pos(real(Ck*trace(V*fu(:, k)*fu(:, k)')));
    end
    1 - s >= 0;
cvx_end
%%
if strcmp(cvx_status, 'Infeasible') == 1
    v = [];
    mse = nan;
    feasible = 0;
    Rv = [];
    return;
end
%%
[Vt, S] = svd(V); % u:eigenvectors, s:eigenvalues
sv = diag(S);
rank_err = sum(sv(2:end));
label = rank_err/sv(1);
if label < 1e-6
    Rv = 1;
    v = Vt(:, 1)*sqrt(S(1, 1));   
else
    maxSum = 0;
    [Vt, S] = svd(V);
    for cnt = 1:1e2
        while true
            z = (randn(M, 1) + 1j*randn(M, 1))/sqrt(2);
            vm = Vt*sqrt(S)*z;
            if check_feasible(vm, [], [], ch, fd, fu, pmax) == 1
                break;
            end
        end
        s = 0;
        for k = 1:K
            Ck = eff(k)*(norm(fd(k, :))^2)*pmax;
            s = s + inv_pos(real(Ck*(norm(vm'*fu(:, k))^2)));
        end
        if 1 - s >= 0
            temp = s;
            if temp > maxSum
                maxSum = temp;
                v_opt = vm;
            end
        end
    end
    v = v_opt;
end
%% check feasibility
feasible = 1;
if check_feasible(v, [], [], ch, fd, fu, pmax) == 0
    feasible = 0;
    mse = nan;
    return;
end
%% compute MSE
% mse = norm(v)^2 / min_cons, 
% where (min_cons >= 1) cannot be obtained for pk being unknown
mse = norm(v)^2; % upper bound

end