function [v, mse, feasible] = find_V_DC(ch, fd, fu, params, v0, Rv)
eff = ch.efficiency;
verb = params.verb;
rho = params.rho;
pmax = params.pmax;
iter_max = params.iter_max;

[M, K] = size(ch.fu);
%%
if ~isequal(Rv, 1)
    %% select an initial point
    if isempty(v0)
        tmp = randn(M, M) + 1j*randn(M, M);
        V = tmp*tmp';
        [U, ~, ~] = svd(V);
        V_partial = U(:, 1)*U(:, 1)'; % original iteration variable
    else
        [U, ~, ~] = svd(v0*v0');
        V_partial = U(:, 1)*U(:, 1)';
    end
    
    %%
    obj0 = 0;
    for  i = 1:iter_max
        %% solve convex subproblem
        cvx_begin sdp quiet
        cvx_solver sdpt3
        variable V(M, M) hermitian semidefinite
        minimize (real(trace(((1 + rho)*eye(M) - rho*V_partial')*V)))
        subject to
            s = 0;
            for k = 1:K
                Ck = eff(k)*(norm(fd(k, :))^2)*pmax;
                s = s + inv_pos(real(Ck*(fu(:, k)'*V*fu(:, k))));
            end
            1 - s >= 0;
        cvx_end
        
        if strcmp(cvx_status, 'Infeasible') || isnan(norm(V)) || isinf(norm(V))
            feasible = 0;
            mse = nan;
            v = nan;
            return;
        end
        
        err = abs(cvx_optval - obj0);
        obj0 = cvx_optval;
        
       %% subgradient
        [U, S] = svd(V);
        V_partial = U(:, 1)*U(:, 1)';
        res = abs(norm(V, 'fro') - S(1, 1));
        if verb
            fprintf(' iter:%d/%d, err:%.3e, res:%.3e\n', i, iter_max, err, res);
        end
        if err < 1e-13
            break;
        end
        if  res < 1e-8 && err < 1e-5
            break;
        end
    end
    [U, S] = svd(V);
    v = U(:, 1)*sqrt(S(1, 1));
else
    v = v0;
end

%% check feasibility
feasible = 1;
if check_feasible(v, [], [], ch, fd, fu, pmax) == 0
    feasible = 0;
    mse = nan;
    return;
end

%% compute MSE
% mse = norm(v)^2 / min_cons, 
% where (min_cons >= 1) cannot be obtained for pk being unknown
mse = norm(v)^2; % upper bound

end