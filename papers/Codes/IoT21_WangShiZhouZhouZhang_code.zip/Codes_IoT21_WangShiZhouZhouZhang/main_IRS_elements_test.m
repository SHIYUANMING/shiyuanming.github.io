clc, clear;
%%
K = 15;          % number of devices
M = 30;          % number of antennas at AP
N_set = 30:5:60; % number of elements at IRS

params.iter_max = 5e2;
params.pmax = 1e3;     % at AP (mW)
params.noise = 1e-6;   % at devices (mW)
params.verb = false;
params.rho = 1;
pmax = params.pmax;
noise = params.noise;

cnt = 12;
loc = 10;
%%
mse_rnd = zeros(length(N_set), 1);

mse_SDR_EP = zeros(length(N_set), 1);
mse_DC_EP = zeros(length(N_set), 1);

mse_SDR = zeros(length(N_set), 1);
mse_DC = zeros(length(N_set), 1);

n_cnt = zeros(length(N_set), 1);
%%
ln = 1;
label = zeros(length(N_set), 1);
while true
    fprintf('ln = %d\n', ln);
    [pL_AU, pL_AI, pL_IU] = location(K);
    for n = 1:length(N_set)
        if label(n)
            break;
        end
        
        N = N_set(n);
        %% with the same random phase-shifts
        thetaD = randn(N, 1) + 1j*rand(N, 1);
        thetaD = thetaD./abs(thetaD);
        ThetaD = diag(thetaD);
        ThetaU = ThetaD';
        
        %%
        t_rnd = 0;
        
        t_SDR_EP = 0;
        t_DC_EP = 0;
        
        t_SDR = 0;
        t_DC = 0;
        
        nt = 0;
        %%
        parfor i = 1:cnt
            %% generate random gaussian channel
            tag_sdr_ep = true;
            tag_dc_ep = true;
            tag_sdr = true;
            
            [ch] = channel(K, M, N, pL_AU, pL_AI, pL_IU);
            ch.fd = nan(size(ch.gd'));
            for k = 1:K
                ch.fd(k, :) = ch.hd(:, k)'*ThetaD*ch.Gd + ch.gd(:, k)';
            end
            ch.fu = nan(size(ch.gu));
            for k = 1:K
                ch.fu(:, k) = ch.Gu*ThetaU*ch.hu(:,k) + ch.gu(:,k);
            end
            
            %% equal power allocation
            nt = nt + 1;
            [m_SDR_EP] = alterMin_SDR_EP(ch, params);
            tmp_ep = m_SDR_EP(~isnan(m_SDR_EP));
            if isempty(tmp_ep)
                nt = nt - 1;
                tag_sdr_ep = false;
                
                tmp_ep = 0;
            end
            t_SDR_EP = t_SDR_EP + tmp_ep(end);
            
            if tag_sdr_ep
                [m_DC_EP] = alterMin_DC_EP(ch, params);
                tmp2_ep = m_DC_EP(~isnan(m_DC_EP));
                if isempty(tmp2_ep)
                    nt = nt - 1;
                    tag_dc_ep = false;
                    
                    tmp2_ep = 0;
                    t_SDR_EP = t_SDR_EP - tmp_ep(end);
                end
                t_DC_EP = t_DC_EP + tmp2_ep(end);
                
                %% general cases
                if tag_dc_ep
                    [m_SDR] = alterMin_SDR(ch, params);
                    tmp = m_SDR(~isnan(m_SDR));
                    if isempty(tmp)
                        nt = nt - 1;
                        tag_sdr = false;
                        
                        tmp = 0;
                        t_SDR_EP = t_SDR_EP - tmp_ep(end);
                        t_DC_EP = t_DC_EP - tmp2_ep(end);
                    end
                    t_SDR = t_SDR + tmp(end);
                    
                    if tag_sdr
                        [m_DC] = alterMin_DC(ch, params);
                        tmp2 = m_DC(~isnan(m_DC));
                        if isempty(tmp2)
                            nt = nt - 1;
                            
                            tmp2 = 0;
                            t_SDR_EP = t_SDR_EP - tmp_ep(end);
                            t_DC_EP = t_DC_EP - tmp2_ep(end);
                            t_SDR = t_SDR - tmp(end);
                        end
                        t_rnd = t_rnd + tmp2(1);
                        t_DC = t_DC + tmp2(end);
                    end
                end
            end
        end
        mse_rnd(n) = mse_rnd(n) + t_rnd;
        
        mse_SDR_EP(n) = mse_SDR_EP(n) + t_SDR_EP;
        mse_DC_EP(n) = mse_DC_EP(n) + t_DC_EP;
        
        mse_SDR(n) = mse_SDR(n) + t_SDR;
        mse_DC(n) = mse_DC(n) + t_DC;

        n_cnt(n) = n_cnt(n) + nt;
        %%
        if n_cnt(n) >= loc*cnt
            label(n) = 1;
        end
    end
    if isequal(norm(label, 1), length(N_set)) || (ln > 10*loc)
        break;
    end
    ln = ln + 1;
end
%%
for n = 1:length(N_set)
    mse_rnd(n) = mse_rnd(n)/n_cnt(n);
    
    mse_SDR_EP(n) = mse_SDR_EP(n)/n_cnt(n);
    mse_DC_EP(n) = mse_DC_EP(n)/n_cnt(n);
    
    mse_SDR(n) = mse_SDR(n)/n_cnt(n);
    mse_DC(n) = mse_DC(n)/n_cnt(n);
end
%%
save main_IRS_elements_test.mat;
%%
figure;
fig1 = semilogy(N_set, mse_rnd, 'h-', 'LineWidth', 2, 'MarkerSize', 8);
hold on;
grid on;
fig2 = semilogy(N_set, mse_SDR, 'o-', 'LineWidth', 2, 'MarkerSize', 8);
fig3 = semilogy(N_set, mse_DC, 's-', 'LineWidth', 2, 'MarkerSize', 8);
fig4 = semilogy(N_set, mse_SDR_EP, 'd-.', 'LineWidth', 2, 'MarkerSize', 8);
fig5 = semilogy(N_set, mse_DC_EP, '>-.', 'LineWidth', 2, 'MarkerSize', 8);
set(fig1, 'MarkerFaceColor', get(fig1, 'Color'));
set(fig2, 'MarkerFaceColor', get(fig2, 'Color'));
set(fig3, 'MarkerFaceColor', get(fig3, 'Color'));
set(fig4, 'MarkerFaceColor', get(fig4, 'Color'));
set(fig5, 'MarkerFaceColor', get(fig5, 'Color'));
xlabel('Number of elements at IRS', 'FontSize', 14);
ylabel('MSE', 'FontSize', 14);
legend('Random phase shift', 'Alternating SDR (EPA)', 'Alternating DC (EPA)', 'Alternating SDR', 'Alternating DC');