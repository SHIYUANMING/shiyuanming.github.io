function [p, feasible]= find_P_SDR(v, ch, fd, fu, pmax)
gu = ch.gu;
Gu = ch.Gu;
hu = ch.hu;
eff = ch.efficiency;

[~, K] = size(ch.gu);
[~, N] = size(ch.Gu);

cvx_begin quiet
variable P(N+1, N+1) hermitian semidefinite
minimize (0)
subject to
    s = 0;
    for k = 1:K
        a_H = v'*Gu*diag(hu(:, k));
        a = a_H';
        c = v'*gu(:, k);
        R = [a*a', a*c; c'*a', 0];
        Ck = eff(k)*(norm(fd(k, :))^2)*pmax;
        s = s + inv_pos(real(Ck*(trace(R*P)+c'*c)));
    end
    1 - s >= 0;
    real(diag(P)) == 1;
cvx_end

if strcmp(cvx_status, 'Infeasible') == 1
    feasible = 0;
    p = [];
    return;
end

[U, S] = svd(P);
sv = diag(S);
rank_err = sum(sv(2:end));
label = rank_err/sv(1);
if label < 1e-6
    p_bar = U(:, 1)*sqrt(S(1, 1));
    p = p_bar(1: N)/p_bar(end);
    feasible = check_feasible(v, p, [], ch, fd, fu, pmax);
else
    for i = 1:1000
        maxSum = 0;
        [U_P, S_P] = svd(P);
        p_opt = nan(N+1, 1);
        for cnt = 1:1e2
            z = (randn(N+1, 1) + 1j*randn(N+1, 1))/sqrt(2);
            pn = U_P*sqrt(S_P)*z;
            s = 0;
            for k = 1:K
                a_H = v'*Gu*diag(hu(:, k));
                a = a_H';
                c = v'*gu(:, k);
                R = [a*a', a*c; c'*a', 0];
                Ck = eff(k)*(norm(fd(k, :))^2)*pmax;
                alpha = real(pn'*R*pn);
                s = s + inv_pos(real(Ck*(alpha + c'*c)));
            end
            if 1 - s >= 0
                temp = s;
                if temp > maxSum
                    maxSum = temp;
                    p_opt = pn;
                end
            end
        end
        p_bar = p_opt;
        p = p_bar(1: N)/p_bar(end);
        p = p./abs(p);
        feasible = check_feasible(v, p, [], ch, fd, fu, pmax);
        if feasible == 1
            break;
        end
    end
end

end