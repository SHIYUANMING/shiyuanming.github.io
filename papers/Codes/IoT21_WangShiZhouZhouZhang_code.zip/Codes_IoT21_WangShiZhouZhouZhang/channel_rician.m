function [h] = channel_rician(beta, M, N)
h_LoS = ones(M, N);
h_NLoS = (randn(M, N) + 1j*randn(M, N))/sqrt(2);
h = sqrt(1/(1/beta + 1))*h_LoS + sqrt(1/(1+beta))*h_NLoS;
end 