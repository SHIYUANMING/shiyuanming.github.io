function [v, mse, feasible, Rv] = find_V_nIRS_SDR(ch, pmax)
fd = ch.gd';
fu = ch.gu;
eff = ch.efficiency;
[M, K] = size(fu);
%%
cvx_begin quiet
cvx_solver sdpt3
variable V(M, M) hermitian semidefinite
minimize (real(trace(V)))
subject to
    s = 0;
    for k = 1:K
        Ck = eff(k)*(norm(fd(k, :))^2)*pmax;
        s = s + inv_pos(real(Ck*trace(V*fu(:, k)*fu(:, k)')));
    end
    1 - s >= 0;
cvx_end

if strcmp(cvx_status, 'Infeasible') == 1
    v = [];
    mse = 0;
    feasible = 0;
    Rv = [];
    return;
end

[Vt, S] = svd(V);
sv = diag(S);
rank_err = sum(sv(2:end));
label = rank_err/sv(1);
if label < 1e-6
    Rv = 1;
    v = Vt(:, 1)*sqrt(S(1, 1));   
else
    Rv = nan;
    [Vt, S] = svd(V);
    temp = inf;
    v_opt = 0;
    for cnt = 1:10
        while true
            z = (randn(M, 1) + 1j*randn(M, 1))/sqrt(2);
            vm = Vt*sqrt(S)*z;
            if check_feasible(vm, [], [], ch, fd, fu, pmax) == 1
                break;
            end
        end
   
        cvx_begin quiet
        variable t nonnegative
        minimize (t)
        subject to
            s = 0;
            for k = 1:K
                Ck = eff(k)*(norm(fd(k, :))^2)*pmax;
                s = s + inv_pos(real(Ck*(norm(vm'*fu(:, k))^2)*t));
            end
            1 - s >= 0;
        cvx_end
        
        vnorm = norm(vm*sqrt(t));
        if vnorm < temp
            temp = vnorm;
            v_opt = vm*sqrt(t);
        end
    end
    v = v_opt;
end

%% check feasibility
feasible = 1;
s = 0;
for k = 1:K
    Ck = eff(k)*(norm(fd(k, :))^2)*pmax;
    s = s + inv_pos(real(Ck*(norm(v'*fu(:, k))^2)));
end
if s - 1e-6 > 1
    feasible = 0;
end

%% compute MSE
% mse = norm(v)^2 / min_cons, 
% where (min_cons >= 1) cannot be obtained for pk being unknown
mse = norm(v)^2; % upper bound

end