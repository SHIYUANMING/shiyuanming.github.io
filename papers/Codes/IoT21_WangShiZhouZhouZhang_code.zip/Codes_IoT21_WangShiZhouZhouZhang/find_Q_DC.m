function [q, feasible] = find_Q_DC(v, ThetaU, ch, params, fd, fu)
gu = ch.gu;
Gu = ch.Gu;
hu = ch.hu;
hd = ch.hd;
gd = ch.gd;
Gd = ch.Gd;
eff = ch.efficiency;
verb = params.verb;
pmax = params.pmax;
iter_max = params.iter_max;

[~,K] = size(gu);
[~,N] = size(Gu);
%% select an nitial point
tmp = randn(N+1, N+1) + 1j*randn(N+1, N+1);
Q = tmp*tmp';
[U, ~, ~] = svd(Q);
Q_partial = U(:, 1)*U(:, 1)';

%%
obj0 = 0;
for iter = 1:iter_max
    %% solve subproblems
    cvx_begin quiet
    cvx_solver sedumi
    variable Q(N+1, N+1) hermitian semidefinite
    minimize (real(trace((eye(N+1) - Q_partial')*Q)))
    subject to
        s = 0;
        for k = 1:K
            a = diag(hd(:, k)')*Gd;
            b = [a; gd(:, k)'];
            Ck = eff(k)*(norm(v'*(Gu*ThetaU*hu(:, k) + gu(:, k)))^2)*pmax;
            s = s + inv_pos(real(Ck*trace(Q*(b*b'))));
        end
        1 - s >= 0;
        real(diag(Q)) == 1;
    cvx_end
    
    if strcmp(cvx_status, 'Infeasible') == 1 || isnan(norm(Q)) || isinf(norm(Q))
        feasible = 0;
        q = nan;
        return;
    end
    err = abs(cvx_optval - obj0);
    obj0 = cvx_optval;
    
    %% subgradient
    [U, S] = svd(Q);
    Q_partial = U(:, 1)*U(:, 1)';
    res = abs(norm(Q, 'fro') - S(1, 1));
    if verb
        fprintf(' iter:%d/%d, err:%.3e, res:%.3e\n', iter, iter_max, err, res);
    end
    if err < 1e-6 && res < 1e-8
        break;
    end
end
[U, S] = svd(Q);
q_bar = conj(U(:, 1)*sqrt(S(1, 1)));
q = q_bar(1:N)/q_bar(end);
q = q./abs(q);
feasible = check_feasible(v, diag(ThetaU), q, ch, fd, fu, pmax);

end