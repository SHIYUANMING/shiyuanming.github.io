function [mse] = find_V_nIRS_DC(ch, params, v0, Rv)
fd = ch.gd';
fu = ch.gu;
eff = ch.efficiency;
iter_max = params.iter_max;
rho = params.rho;
pmax = params.pmax;
[M, K] = size(ch.fu);
%%
if ~isequal(Rv, 1)
    if isempty(v0)
        tmp = randn(M, M) + 1j*randn(M, M);
        V = tmp*tmp';
        [U, ~, ~] = svd(V);
        V_partial = U(:, 1)*U(:, 1)'; % original iteration variable
    else
        V_partial = v0*v0';
    end
    
    obj0 = 0;
    
    for  iter = 1:iter_max
       %% Solve convex subproblem
        cvx_begin quiet
        variable V(M, M) hermitian semidefinite
        minimize (real(trace(((1 + rho)*eye(M) - rho*V_partial')*V)))
        subject to
            s = 0;
            for k = 1:K
                Ck = eff(k)*(norm(fd(k, :))^2)*pmax;
                s = s + inv_pos(real(Ck*(fu(:, k)'*V*fu(:, k))));
            end
            1 - s >= 0;
        cvx_end
        
        if strcmp(cvx_status, 'Infeasible')
            mse = 0;
            return;
        end
        
        err = abs(cvx_optval - obj0);
        obj0 = cvx_optval;
        
       %% Subgradient
        [U, S] = svd(V);
        V_partial = U(:, 1)*U(:, 1)';
        res = abs(norm(V, 'fro') - S(1, 1));
        if err < 1e-13
            break;
        end
        if  res < 1e-8 && err < 1e-5
            break;
        end
    end
    [U, S] = svd(V);
    v = U(:, 1)*sqrt(S(1, 1));
else
    v = v0;
end

%% check feasibility
if check_feasible(v, [], [], ch, fd, fu, pmax) == 0
    mse = 0;
    return;
end

%% compute MSE
% mse = norm(v)^2 / min_cons, 
% where (min_cons >= 1) cannot be obtained for pk being unknown
mse = norm(v)^2; % upper bound

end