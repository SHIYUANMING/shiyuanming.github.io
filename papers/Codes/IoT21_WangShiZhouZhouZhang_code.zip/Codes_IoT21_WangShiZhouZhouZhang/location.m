function [pL_AU, pL_AI, pL_IU] = location(K)
%% K: number of IoT devices
location_AP = [0, 0, 0];
location_IRS = [20, 20, 0];

%% pathloss parameters
T0 = 1e0;
% path loss exponent alpha
a_AI = 2.2; % AP-IRS link
a_AU = 3.5; % AP-user link
a_IU = 2.3; % IRS-user link

%%
dis_AI = norm(location_AP-location_IRS);
pL_AI = path_loss(T0, dis_AI, 1, a_AI);
pL_AU = nan(K, 1);
pL_IU = nan(K, 1);

for k = 1:K
    x = 20 + 40*rand;
    y = -20 + 40*rand;
    location_user = [x, y, 0];
    
    dis_AU = norm(location_AP - location_user);
    pL_AU(k) = path_loss(T0, dis_AU, 1, a_AU);
    
    dis_IU = norm(location_IRS - location_user);
    pL_IU(k) = path_loss(T0, dis_IU, 1, a_IU);
end
end

function [pLoss] = path_loss(T0, d, d0, a)
pLoss = T0*(d/d0)^(-a);
end