function [x, cost,options,info] = gradientdescent(problem, x, options)

% A is the original matrix
if ~canGetCost(problem)
    warning('manopt:getCost', ...
        'No cost provided. The algorithm will likely abort.');
end
if ~canGetGradient(problem)
    warning('manopt:getGradient', ...
        'No gradient provided. The algorithm will likely abort.');
end

% Set local defaults here
localdefaults.minstepsize = 1e-10;
localdefaults.maxiter = 1000;
localdefaults.tolgradnorm = 1e-6;
localdefaults.storedepth = 20;
if ~canGetLinesearch(problem)
    localdefaults.linesearch = @linesearch_adaptive;
else
    localdefaults.linesearch = @linesearch_hint;
end

% Merge global and local defaults, then merge w/ user options, if any.
localdefaults = mergeOptions(getGlobalDefaults(), localdefaults);
if ~exist('options', 'var') || isempty(options)
    options = struct();
end
options = mergeOptions(localdefaults, options);
stepsize =options.stepsize;
% For convenience
lincomb = problem.M.lincomb;


% If no initial point x is given by the user, generate one at random.
if ~exist('x', 'var') || isempty(x)
    x = problem.M.rand();
end

% Compute cost-related quantities for x
[cost, grad] = getCostGrad(problem,  x);
gradnorm = problem.M.norm(x, grad);


% Iteration counter (at any point, iter is the number of fully executed
% iterations so far)
iter = 0;


% Save stats in a struct array info and preallocate.
%stats = savestats();
info  = struct();
info.cost(1) = cost;
if options.verbosity >= 2
    fprintf(' iter\t               cost val\t  \n');
end


% Start iterating until stopping criterion triggers
while true
    
      
    % Display iteration information
    if options.verbosity >= 2
       fprintf('%5d\t%+.16e\t\n', iter, cost);
    end
    
    
    % The line search algorithms require the directional derivative of the
    % cost at the current point x along the search direction.
    desc_dir = lincomb(x, -1, grad);
    normx = problem.M.norm(x,x)^2/2;
    newx = problem.M.retr(x, desc_dir,stepsize/normx);

     if iter >=options.maxiter || gradnorm <options.tolgradnorm
         break
     end
    
    

    % Compute the new cost-related quantities for newx
    [newcost, newgrad] = getCostGrad(problem, newx);
    newgradnorm = problem.M.norm(newx, newgrad);
 
    % Transfer iterate info
    x = newx;
    cost = newcost;
    grad = newgrad;
    gradnorm = newgradnorm;

    % iter is the number of iterations we have accomplished.
    iter = iter + 1;
    info.cost(iter + 1) = cost;
 
end
end

