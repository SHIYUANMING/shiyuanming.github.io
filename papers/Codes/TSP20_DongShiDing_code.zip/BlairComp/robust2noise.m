% Manopt and CVX should be installed. Please refer to
% https://www.manopt.org/ and http://cvxr.com/cvx/
% Fig.7  in the paper 'Blind Demixing for Low-Latency Communication'

clear all;
clc
rng('default');rng(1);%warning('off', 'manopt:getHessian:approx');
addpath('./fun');
testnum =10;
size_set =1536;
m_len = size(size_set,2);
s = 2;
snr_set_index =-4:2:0;
snr_set = 10.^(snr_set_index);
size_snr = size(snr_set,2);
allcost1 = zeros(m_len,size_snr,testnum);
allcost2 = zeros(m_len,size_snr,testnum);
allcost3 = zeros(m_len,size_snr,testnum);
allcost4 = zeros(m_len,size_snr,testnum);
allcost5 = zeros(m_len,size_snr,testnum);

r=1;
params.verbosity =0;
params.costtol = 1e-6;
params.maxiter = 500;
params.tolgradnorm = 1e-12;


n1 = 50; n2 = 50;
%parfor ki = 1:testnum
for ki = 1:testnum
    for i=1:m_len
      for t=1:size_snr

        m = size_set(i);
        omega = randn(m,1)+1i*randn(m,1);
        snr = snr_set(t);
        Ksize = [n1,n2,s,m];
        [X,y,C,x,h,g,z,y1 ] = generate_model_gaussian( m,n1,n2,s );  % Gaussian encoding matrices
        %[X,y,C,x,h,g,z,y1 ] = generate_model_hadamard( m,n1,n2,s ); % Hadamard-type encoding matrices

        y = y+snr*norm(y)*(omega/norm(omega))/sqrt(2);
        [A,B,FC] = generate_decon_matrix(m,n1,n2,s,C);

%% initialization
        [ hr,xr,d,mu] = RGD_initial(Ksize,A,B,FC,y);
        X0_fi = cellfun(@(h,x)h*x',hr,xr,'Uni',0);
        X0_rand =cellfun(@(h,x)[h;x],h,x,'Uni',0);
        X0_re = cellfun(@(h,x)[h;x],hr,xr,'Uni',0);
%%  Riemannian
        [Xout1, infos1]=Riemannian_fixedrank_TR(r, Ksize, X0_re, params, A, y);
        allcost1(i,t,ki)=sqrt(sum(cellfun(@(x,y)norm(x(1:n1,:)*x(n1+1:end,:)'-y)^2,Xout1,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost1(i,t,ki));
%% convex
        [Xout2, opt_value]=convex_cvx( Ksize,  A, y);
        allcost2(i,t,ki)=sqrt(sum(cellfun(@(x,y)norm(x-y,'fro')^2,Xout2,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('nnm, m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost2(i,t,ki));
%% Regularized GD
        [Xout3, infos3]=RGD( Ksize, A,B,mu,d, y,params,hr,xr);
        allcost3(i,t,ki)=sqrt(sum(cellfun(@(x,y)norm(x-y,'fro')^2,Xout3,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('rgd, m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost3(i,t,ki));
%% FIHIT 
        [Xout4, infos4]=FIHT( Ksize, A, y,params,X0_fi);
        allcost4(i,t,ki)=sqrt(sum(cellfun(@(x,y)norm(x-y,'fro')^2,Xout4,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('fihit, m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost4(i,t,ki));
%% gradient descent
        [Xout5, infos5]=Riemannian_fixedrank_CG(r, Ksize, X0_re, params, A, y);
        allcost5(i,t,ki)=sqrt(sum(cellfun(@(x,y)norm(x(1:n1,:)*x(n1+1:end,:)'-y)^2,Xout5,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost5(i,t,ki));

      end
   end
end

test_rmse1 = mean(allcost1,3);
test_rmse2 = mean(allcost2,3);
test_rmse3 = mean(allcost3,3);
test_rmse4 = mean(allcost4,3);
test_rmse5 = mean(allcost5,3);

figure,plot(-mag2db(snr_set),mag2db(test_rmse1(1,:)),'-s','LineWidth',1.5,'MarkerSize',6);hold on
plot(-mag2db(snr_set),mag2db(test_rmse2(1,:)),'-s','LineWidth',1.5,'MarkerSize',6);
plot(-mag2db(snr_set),mag2db(test_rmse3(1,:)),'-s','LineWidth',1.5,'MarkerSize',6);
plot(-mag2db(snr_set),mag2db(test_rmse4(1,:)),'-s','LineWidth',1.5,'MarkerSize',6);hold off
plot(-mag2db(snr_set),mag2db(test_rmse5(1,:)),'-s','LineWidth',1.5,'MarkerSize',6);

legend('PRTR','NNM','RGD','FIHIT','PRGD');
xlabel('snr','FontSize',14);
ylabel('Relative reconstruction error (dB)','FontSize',14);
axis tight;
