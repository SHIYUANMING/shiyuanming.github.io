% Manopt and CVX should be installed. Please refer to
% https://www.manopt.org/ and http://cvxr.com/cvx/
% Fig. 5 in the paper 'Blind Demixing for Low-Latency Communication'
clear all;
clc
rng('default');rng(1);%warning('off', 'manopt:getHessian:approx');
addpath('./fun');
testnum =1;
size_set =[512];
size_len = length(size_set);
s =2;
con_set = [1,10,20];
con_len = length(con_set);
allcost = zeros(size_len,con_len,testnum);
r=1;
params.verbosity =2;
params.costtol = 1e-6;
params.maxiter = 60;
params.tolgradnorm = 1e-8;

allcost1 = zeros(size_len,con_len,testnum);
allcost2 = zeros(size_len,con_len,testnum);
allcost3 = zeros(size_len,con_len,testnum);
allcost4 = zeros(size_len,con_len,testnum);
allcost5 = zeros(size_len,con_len,testnum);
for t=1:size_len
    m = size_set(t);
    n1 = 50;
    n2 = 50;
    for ks = 1:con_len
        con  = con_set(ks);
        Ksize = [n1,n2,s,m];
     for ki = 1:testnum
         [X,y,C,x,h,g,z,y1 ] = generate_model_conditionnumber( m,n1,n2,s,con );
         [A,B,FC,CK] = generate_decon_matrix(m,n1,n2,s,C);
%% initial 
        
        [ h0,x0,d,mu] = RGD_initial(Ksize,A,B,FC,y); 
        X0_re =cellfun(@(h,x)[h;x],h0,x0,'Uni',0);
        params.X_0 = X;
%%  Riemannian
        [Xout1, infos1]=Riemannian_fixedrank_TR(r, Ksize, X0_re, params, A, y);
        info{ks} = infos1;
        x1 = cellfun(@(x,y)x(1:n1,:)*x(n1+1:end,:)',Xout1,'Uni',0);
        allcost1(t,ks,ki)=sqrt(sum(cellfun(@(x,y)norm(x(1:n1,:)*x(n1+1:end,:)'-y,'fro')^2,Xout1,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost1(t,ks,ki));
      end
     end
end
figure,
for j = 1:con_len
    cost = [info{j}.cost];
  iter1 = size(cost,2);
  re1 = zeros(iter1,1);
  coh = zeros(iter1,1);
  t1 = zeros(iter1,1);
     for  i = 1:iter1
     
     re1(i) = cost(i);
     end
     iter_1 = 1:iter1;
     semilogy(iter_1,re1(iter_1),'LineWidth',2);hold on
end
legend('kappa = 1','kappa = 10','\kappa = 20');
xlabel('iteration','FontSize',14,'Interpreter','latex');
ylabel('RMSE','FontSize',14,'Interpreter','latex');
set(gca,'Fontsize',14,'Fontname', 'Times New Roman','GridLineStyle','--');
axis tight;
grid on




 