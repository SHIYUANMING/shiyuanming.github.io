% clc;
clear;
clear all;
% rng('default');
warning('off');
cvx_solver sedumi
% cvx_solver sdpt3
% cvx_solver sedumi
%cvx_solver mosek
%cvx_solver scs
%cvx_solver_settings('MAX_ITERS', 10^4, 'SCALE', 100);

cvx_quiet(true)
%% Problem Data (I)
LC=10; %# channel realizarions  %change here, initial is 50
verbosity = 1;
DCBF=1;

%%
Area= 1; % 1 KM
N=8; %Number of RAUs
L=2;  % Antennas of each RAU
K=15; %Number of Mobile Users in Each Multicast Group
N_set=L*ones(N,1);

Q=0:2:8;  %QoS in dB
%Q=8;
% epsilon=0.05;  %Shape of the errors
params.ranktol = 1e-3;
%%

% Pc=5.6*ones(K,1);  %power consumption of the fronthaul link: P_{nk}^C
amcoeff=1/4.*ones(N,1); %amplifier efficiency coefficient: eta
params.amcoeff = amcoeff;
%% Problem Data for Params (II)
params.K=K;
params.L = L;
params.delta_set=ones(K,1);  %set of noise
params.N=N;
transmit_power = 1*10^0;
params.P_set=transmit_power*ones(N,1);   %set of transmit power constraints for all the RAUs
params.Pc = 0.45.*ones(N,K);
params.N_set = N_set;
mysnr=134;
channel_gain =10^(mysnr/20) ;
params.sigma_square = 1; %transmit_power*10^(-mysnr/10);
params.verbosity = verbosity;


testnum=100;


params.rankone=true; %return rankone solution

TotalPower_logsum = zeros(length(Q),testnum);
TransmitPower_logsum = zeros(length(Q),testnum);
A_number_logsum = zeros(length(Q),testnum);

TotalPower_mixed_ell = zeros(length(Q),testnum);
TransmitPower_mixed_ell = zeros(length(Q),testnum);
A_number_mixed_ell = zeros(length(Q),testnum);

TotalPower_all = zeros(length(Q),testnum);
TransmitPower_all = zeros(length(Q),testnum);
A_number_all = zeros(length(Q),testnum);

feasibility_logsum = zeros(length(Q),testnum);
feasibility_mixed_ell = zeros(length(Q),testnum);
feasibility_all = zeros(length(Q), testnum);


Hkn_set = zeros(sum(N_set), K, testnum);

for i=1:testnum
%% 
Hkn_set(:,:,i)=channel_realization(N, K, N_set, Area, channel_gain);
%% 
end

tic;
for tt = 1:testnum
    
    Hkn = Hkn_set(:,:,tt);
    
    tmp_TotalPower_logsum = zeros(length(Q),1);
    tmp_TransmitPower_logsum = zeros(length(Q),1);
    tmp_A_number_logsum = zeros(length(Q),1);
    tmp_feasibility_logsum = zeros(length(Q),1);
    
    tmp_TotalPower_mixed_ell = zeros(length(Q),1);
    tmp_TransmitPower_mixed_ell = zeros(length(Q),1);
    tmp_A_number_mixed_ell = zeros(length(Q),1);
    tmp_feasibility_mixed_ell = zeros(length(Q),1);
    
    tmp_TotalPower_all = zeros(length(Q),1);
    tmp_TransmitPower_all = zeros(length(Q),1);
    tmp_A_number_all = zeros(length(Q),1);
    tmp_feasibility_all = zeros(length(Q),1);
    
    
    
    for lq=length(Q):-1:1 
        QoS = Q(lq);
        
        [feasibility, solution, opt_value]=feasibility_check_beamforming(params,K,N,Hkn,QoS);
        if verbosity>=1
            fprintf('----testnum:%d, QoS:%d, feasibility:%d\n', tt, QoS, feasibility);
        end
% %         tmp_feasibility_set(lq) = feasibility;
        if ~feasibility
%             if verbosity>=1
%                 fprintf('----testnum:%d, QoS:%d, feasibility:%d, status: %s \n', tt, QoS, feasibility, out_status);
%             end
%             tmp_TotalPower_DCBF(lq) = nan; tmp_TransmitPower_DCBF(lq)=nan; tmp_A_number_DCBF(lq)=nan;
            tmp_feasibility_logsum(lq) = 0;
            tmp_feasibility_mixed_ell(lq) = 0;
            tmp_feasibility_all(lq) = 0;
            continue;
        end
        

        %% log-sum GSBF
        [feasibility, total_power, trans_power, number_of_task]=proximal_three_stage_beamforming(params,K,N,Hkn,QoS);
        tmp_TotalPower_logsum(lq)=total_power;  %recode current values +(1/amcoeff)*norm(Vsolution,'fro')^2
        tmp_TransmitPower_logsum(lq)=trans_power;
        tmp_A_number_logsum(lq)=number_of_task;
        tmp_feasibility_logsum(lq) = feasibility;
         
        %% mixed l1,2 GSBF
        [feasibility, total_power, trans_power, number_of_task]=mixed_ell_three_stage_beamforming(params,K,N,Hkn,QoS);  
        tmp_TotalPower_mixed_ell(lq)=total_power;  %recode current values +(1/amcoeff)*norm(Vsolution,'fro')^2
        tmp_TransmitPower_mixed_ell(lq)=trans_power;
        tmp_A_number_mixed_ell(lq)=number_of_task;
        tmp_feasibility_mixed_ell(lq) = feasibility;
%         
%         %% Coordinated beamforming
        [feasibility, total_power, trans_power, number_of_task]=all_task_beamforming(params,K,N,Hkn,QoS);
        tmp_TotalPower_all(lq)=total_power;  %recode current values +(1/amcoeff)*norm(Vsolution,'fro')^2
        tmp_TransmitPower_all(lq)=trans_power;
        tmp_A_number_all(lq)=number_of_task;
        tmp_feasibility_all(lq) = feasibility;


    end
    
    TotalPower_logsum(:,tt) = tmp_TotalPower_logsum;
    TransmitPower_logsum(:,tt) = tmp_TransmitPower_logsum;
    A_number_logsum(:,tt) = tmp_A_number_logsum;
    feasibility_logsum(:,tt) = tmp_feasibility_logsum;
    
    TotalPower_mixed_ell(:,tt) = tmp_TotalPower_mixed_ell;
    TransmitPower_mixed_ell(:,tt) = tmp_TransmitPower_mixed_ell;
    A_number_mixed_ell(:,tt) = tmp_A_number_mixed_ell;
    feasibility_mixed_ell(:,tt) = tmp_feasibility_mixed_ell;
    
    TotalPower_all(:,tt) = tmp_TotalPower_all;
    TransmitPower_all(:,tt) = tmp_TransmitPower_all;
    A_number_all(:,tt) = tmp_A_number_all;
    feasibility_all(:,tt) = tmp_feasibility_all;
end
toc;
% save('test_no_uncertainty.mat');


mean_TotalPower_logsum = sum(TotalPower_logsum.*(feasibility_logsum),2)./sum(feasibility_logsum,2);
mean_TransmitPower_logsum = sum(TransmitPower_logsum.*(feasibility_logsum),2)./sum(feasibility_logsum,2);
mean_A_number_logsum = sum(A_number_logsum.*(feasibility_logsum),2)./sum(feasibility_logsum,2);
mean_TotalPower_mixed_ell = sum(TotalPower_mixed_ell.*feasibility_mixed_ell,2)./sum(feasibility_mixed_ell,2);
mean_TransmitPower_mixed_ell = sum(TransmitPower_mixed_ell.*feasibility_mixed_ell,2)./sum(feasibility_mixed_ell,2);
mean_A_number_mixed_ell = sum(A_number_mixed_ell.*feasibility_mixed_ell,2)./sum(feasibility_mixed_ell,2);
mean_TotalPower_all = sum(TotalPower_all.*feasibility_all,2)./sum(feasibility_all,2);
mean_TransmitPower_all = sum(TransmitPower_all.*feasibility_all,2)./sum(feasibility_all,2);
mean_A_number_all = sum(A_number_all.*feasibility_all,2)./sum(feasibility_all,2);

%% Plot the network power consumption%%%%%%%%%%%%
figure;    
plot(Q,mean_TotalPower_logsum,'-d','LineWidth',3, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,mean_TotalPower_mixed_ell,'->','LineWidth',3, 'MarkerSize',10);
plot(Q,mean_TotalPower_all,'-s','LineWidth',3, 'MarkerSize',10);
h = legend('Log-Sum Prox GSBF', 'Mixed $\ell_{1,2}$ GSBF', 'Coordinated Beamforming');
set(h, 'interpreter', 'latex');
xlabel('Target SINR [dB]','fontsize',12,'fontweight','b','fontname','helvetica');
ylabel('Total Power Consumption [W]','fontsize',14,'fontweight','b','fontname','helvetica');


%% Plot the transmit power consumption
figure;
plot(Q,mean_TransmitPower_logsum,'-d','LineWidth',3, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,mean_TransmitPower_mixed_ell,'->','LineWidth',3, 'MarkerSize',10);
plot(Q,mean_TransmitPower_all,'-s','LineWidth',3, 'MarkerSize',10);
h = legend('Log-Sum Prox GSBF', 'Mixed $\ell_{1,2}$ GSBF', 'Coordinated Beamforming');
set(h, 'interpreter', 'latex');
xlabel('Target SINR [dB]','fontsize',12,'fontweight','b','fontname','helvetica');
ylabel('Transmit Power Consumption [W]','fontsize',14,'fontweight','b','fontname','helvetica');

%% Plot the computation power
% figure;
% plot(Q,mean_TotalPower_logsum-mean_TransmitPower_logsum,'-d','LineWidth',3, 'MarkerSize',10); %Network power consumptioin
% hold on;
% plot(Q,mean_TotalPower_mixed_ell-mean_TransmitPower_mixed_ell,'->','LineWidth',3, 'MarkerSize',10);
% plot(Q,mean_TotalPower_all-mean_TransmitPower_all,'-s','LineWidth',3, 'MarkerSize',10);
% h = legend('Log-Sum GSBF', 'Mixed $\ell_{1,2}$ GSBF', 'Coordinated Beamforming');
% set(h, 'interpreter', 'latex');
% xlabel('Target SINR [dB]','fontsize',12,'fontweight','b','fontname','helvetica');
% ylabel('Average Computation Power Consumption','fontsize',14,'fontweight','b','fontname','helvetica');


%% Plot average number of active tasks
figure;
plot(Q,mean_A_number_logsum,'-d','LineWidth',3, 'MarkerSize',10); %Network power consumptioin
hold on;
plot(Q,mean_A_number_mixed_ell,'->','LineWidth',3, 'MarkerSize',10);
plot(Q,mean_A_number_all,'-s','LineWidth',3, 'MarkerSize',10);
h = legend('Log-Sum Prox GSBF', 'Mixed $\ell_{1,2}$ GSBF', 'Coordinated Beamforming');
set(h, 'interpreter', 'latex');
xlabel('Target SINR [dB]','fontsize',12,'fontweight','b','fontname','helvetica');
ylabel('Average Number of Computed Tasks','fontsize',14,'fontweight','b','fontname','helvetica');
