function [feasible1, TotalPower, TransmitPower, num_of_A_optimal]=proximal_three_stage_beamforming(params,K,N,Hkn,QoS)
verb = params.verbosity;
params.r_set = 10^(QoS/10)*ones(K,1);
params.H = Hkn;
L = params.L;
epsilon=0.01; % rewighted paprameter: 1/p
params.beta = 0.1;
amcoeff=params.amcoeff; 
Pc=params.Pc;
N_set = params.N_set;

%% Stage I: iteratively solve the reweighted problem
if verb>=2
    fprintf('Stage I: inducing group sparsity with reweighted least square\n');
end
alternating_max=25; 
alternating_abs=10^9;
value2=0;
%     w=sqrt(Pc./amcoeff);  % w's shape is (N, K)
w=ones(N,K);
V = zeros(sum(N_set),K);
for alternating =1:alternating_max %interation numbers
    
    value1=value2; %recode the old objective value
    
    params.weight=w;
    params.V_last = V;
    [feasible1, v_norm, ~, V] = proximal_first_stage_beamforming(params);  %vsparse = obj
    
    %======== reweighted l1 norm ==========%
    value2=sum((v_norm(:)+epsilon).^(-1));
    w=(v_norm+epsilon).^(-1);
    
    Omega_v_value(alternating) = sum(sum(sqrt(Pc./amcoeff).*log(1.+v_norm./epsilon)));
%     improvement(alternating) = sum(sum(square_abs(V-params.V_last)));
    
    alternating_abs(alternating)=abs(value1-value2); %absolute value of the adjacent objective values
    if verb>=2
        fprintf('iter:%d, rel error:%.3e\n',alternating,alternating_abs(alternating));
    end
    if alternating_abs(alternating)<1e-8
        break;
    end
end
    
%% uncomment this code to plot the convergence curve
% figure(1);
%plot(1:alternating,log10(Omega_v_value),'Color',[0.00 0.45 0.74],'Marker','o','LineWidth',3, 'MarkerSize',9)% % semilogy(1:alternating, improvement);
% xlabel('#Iterations','fontsize',12,'fontweight','b','fontname','helvetica');
% ylabel('\Omega(v) in log-scale','fontsize',14,'fontweight','b','fontname','helvetica');
%% Stage II: RRH Ordering Based on the Approximated Group Sparse Beamformer
    if verb>=2
        fprintf('Stage II: Ordering...\n');
    end
    H_est = Hkn; 
    Value_IRLS=zeros(N,K);
    for n = 1:N
        for k = 1:K
            if n==1
                Value_IRLS(n,k) = sqrt(amcoeff(n).*norm(H_est(1:N_set(n),k))^2/Pc(n,k))*v_norm(n,k);
            else
                Value_IRLS(n,k) = sqrt(amcoeff(n).*norm(H_est(sum(N_set(1:n-1))+1:sum(N_set(1:n)),k))^2/Pc(n,k))*v_norm(n,k);
            end
        end
    end

     [~,index]=sort(Value_IRLS(:), 'descend');   %RRH ordering
%% Stage III: Refine beamforming vector
% for c=K:K*N
%     params.c = c;
%     inactive_task_index = index(c+1:end);
%     active_task_index = index(1:c);
%     [feasible, v_norm, v_norm_square] = powermin_cvx(params, inactive_task_index, active_task_index);  %power minimization given the active RRH set
%     if feasible==1
%         TotalPower=sum(sum(1./amcoeff.*v_norm_square)) + sum(Pc(index(1:c)));  %network power consumption
%         TransmitPower= sum(sum(1./amcoeff.*v_norm_square));
%         num_of_A_optimal = c;
%         break;
%     end
% end

lb=K; ub=K*N;
while lb<ub
%     fprintf("lb is %d, ub is %d.\n", lb, ub);
    c = ceil((lb+ub)/2);
    params.c = c;
    inactive_task_index = index(c+1:end);
    active_task_index = index(1:c);
    [feasible2, v_norm, v_norm_square] = powermin_cvx(params,inactive_task_index,active_task_index);
    if ~feasible2  % if it's infeasible, then we need to activate more link.
        lb = c;
        continue;
    else
        ub = c;
        if ub-lb==1
            break;
        end
    end
end
TotalPower=sum(sum(1./amcoeff.*v_norm_square)) + sum(Pc(index(1:c)));  %network power consumption
TransmitPower= sum(sum(1./amcoeff.*v_norm_square));
num_of_A_optimal = c;
        
end