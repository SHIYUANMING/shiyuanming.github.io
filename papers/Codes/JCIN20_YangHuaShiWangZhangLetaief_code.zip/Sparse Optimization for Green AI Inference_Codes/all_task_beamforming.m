function [feasible, TotalPower, TransmitPower, num_of_A_optimal]=all_task_beamforming(params,K,N,Hkn,QoS)
verb = params.verbosity;
params.r_set = 10^(QoS/10)*ones(K,1);
params.H = Hkn;
L = params.L;
p =0.6;
amcoeff=params.amcoeff; 
Pc=params.Pc;
N_set = params.N_set;
%% preparation: check the feasibility of the problem under the channel realization
%     params.activeset=repmat(1:K,[N,1])';
%     [feasibility,out_status,Vsolution]=feasibility_check_beamforming(params);
%     fprintf('Preparation: problem status:%s\n', out_status);
%     if ~feasibility
%         Wsolution = nan;  rankisone = nan;  power_task = nan; trans_power =nan; number_of_task = nan; activeset= nan;
%         return;
%     end

% %% Stage I: when feasible, solve it with three stage reweighted algorithm
%     if verb>=2
%         fprintf('Stage I: inducing group sparsity with reweighted least square\n');
%     end
%     alternating_max=20; alternating_abs=10^99;
%     value2=0;
%     w=sqrt(Pc./amcoeff);  % w's shape is (N, K)
% %     w=ones(N,K);
%     for alternating =1:alternating_max %interation numbers
% 
%         value1=value2; %recode the old objective value
%         
%         params.weight=w;
%         [feasible1, v_sparse, power_beamform] = reweighted_first_stage_beamforming(params);  %vsparse = obj
%         
%         %======== reweighted l2 norm ==========%
% %         value2=sum((power_beamform(:)+epsilon^2).^(p/2));
% %         w=(power_beamform+epsilon^2).^(p/2-1);
%         %======== reweighted l1 norm ==========%
%         value2=sum((v_sparse(:)+epsilon).^(-1));
%         w=(v_sparse+epsilon).^(-1);
% 
% 
%         
%         alternating_abs(alternating)=abs(value1-value2); %absolute value of the adjacent objective values
%         if verb>=2
%             fprintf('iter:%d, rel error:%.3e\n',alternating,alternating_abs(alternating));
%         end
%         if alternating_abs(alternating)<1e-8
%             break;
%         end
%     end
%     
% %% Stage II: RRH Ordering Based on the Approximated Group Sparse Beamformer
%     if verb>=2
%         fprintf('Stage II: Ordering...\n');
%     end
%     H_est = Hkn; 
%     Value_IRLS=zeros(N,K);
%     for n = 1:N
%         for k = 1:K
%             if n==1
%                 Value_IRLS(n,k) = sqrt(amcoeff(n).*norm(H_est(1:N_set(n),k))^2/Pc(n,k))*v_sparse(n,k);
%             else
%                 Value_IRLS(n,k) = sqrt(amcoeff(n).*norm(H_est(sum(N_set(1:n-1))+1:sum(N_set(1:n)),k))^2/Pc(n,k))*v_sparse(n,k);
%             end
%         end
%     end
% 
%      [BS,BS_index]=sort(Value_IRLS(:), 'descend');   %RRH ordering
%% Stage III: Refine beamforming vector
c = N*K;
params.c = c;
inactive_task_index = [];
active_task_index = 1:N*K;
[feasible, v_norm, v_norm_square] = powermin_cvx(params, inactive_task_index, active_task_index);  %power minimization given the active RRH set
if feasible==1
    TotalPower=sum(sum(1./amcoeff.*v_norm_square)) + sum(Pc(:));  %network power consumption
    TransmitPower= sum(sum(1./amcoeff.*v_norm_square));
    num_of_A_optimal = c;
end

        
end