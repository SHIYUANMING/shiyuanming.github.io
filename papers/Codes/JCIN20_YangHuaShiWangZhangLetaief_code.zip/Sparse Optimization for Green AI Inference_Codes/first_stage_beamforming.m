function [feasible,v_norm,obj_value] = first_stage_beamforming(params)

% verb = params.verbosity;
K=params.K;   %Numbers of Mobile Users
r_set=params.r_set;     %Kx1 vector: QoS Requirements of Mobile Users for each Muliticast Group: assuming all the users have the same QoS requirments in the same group
N_set = params.N_set;   %Nx1 vector: antennas on each RAU
delta_set=params.delta_set;  %Kx1 vector: noise covariance
N=params.N;   %Number of RAUs
P_set=params.P_set;  %Nx1 vector: RAU transmit power set


H=params.H;  % sum(N_set)*K channel matrix


weight=params.weight;
cvx_begin quiet
variable V(sum(N_set), K) complex;   %Variable for N x K beamforming matrix
expression obj(N,K);
for j=1:K
    obj(1,j) = norm(V(1:N_set(1),j),2);
end
for i=2:N
    for j=1:K
        obj(i,j) = norm(V(sum(N_set(1:i-1))+1 : sum(params.N_set(1:i)),j),2);
    end
end

minimize sum(sum((weight.*obj)))
subject to
    for l=1:N    %%%Transmit Power Constraints
        %%
        if l==1
            norm(V(1:N_set(1),:),'fro')<=sqrt(P_set(l));
        else
            norm(V(sum(N_set(1:l-1))+1:sum(N_set(1:l)),:),'fro')<=sqrt(P_set(l));
        end
    end

    for k=1:K        %%%%%%%%%QoS constraints
        %%
        norm([H(:,k)'*V, delta_set(k)],'fro')<=sqrt(1+1/r_set(k))*real(params.H(:,k)'*V(:,k));
    end
cvx_end
 
 
%% build output

     if  strfind(cvx_status,'Solved')
         feasible=true;
         v_norm=obj;
         obj_value = sum(sum(weight.*(obj)));
     else
         feasible=false;
         v_norm=nan;
         obj_value=nan;
     end
    
 

end 
