function [feasible1, TotalPower, TransmitPower, num_of_A_optimal]=mixed_ell_three_stage_beamforming(params,K,N,Hkn,QoS)
verb = params.verbosity;
params.r_set = 10^(QoS/10)*ones(K,1);
params.H = Hkn;
L = params.L;
p =1;
amcoeff=params.amcoeff; 
Pc=params.Pc;
N_set = params.N_set;
%% preparation: check the feasibility of the problem under the channel realization
%     params.activeset=repmat(1:K,[N,1])';
%     [feasibility,out_status,Vsolution]=feasibility_check_beamforming(params);
%     fprintf('Preparation: problem status:%s\n', out_status);
%     if ~feasibility
%         Wsolution = nan;  rankisone = nan;  power_task = nan; trans_power =nan; number_of_task = nan; activeset= nan;
%         return;
%     end

%% Stage I: when feasible, solve it with three stage reweighted algorithm
    if verb>=2
        fprintf('Stage I: inducing group sparsity with reweighted least square\n');
    end

    w=sqrt(Pc./amcoeff);  % w's shape is (N, K)
%     w = ones(N,K);
    params.weight=w;
    [feasible1, v_norm, obj_value] = first_stage_beamforming(params);
        

    
%% Stage II: RRH Ordering Based on the Approximated Group Sparse Beamformer
    if verb>=2
        fprintf('Stage II: Ordering...\n');
    end
    H_est = Hkn; 
    Value_IRLS=zeros(N,K);
    for n = 1:N
        for k = 1:K
            if n==1
                Value_IRLS(n,k) = sqrt(amcoeff(n).*norm(H_est(1:N_set(n),k))^2/Pc(n,k))*v_norm(n,k);
            else
                Value_IRLS(n,k) = sqrt(amcoeff(n).*norm(H_est(sum(N_set(1:n-1))+1:sum(N_set(1:n)),k))^2/Pc(n,k))*v_norm(n,k);
            end
        end
    end

     [~,index]=sort(Value_IRLS(:), 'descend');   %RRH ordering

%% Stage III: Refine beamforming vector
% for c=K:K*N
%     params.c = c;
%     inactive_task_index = index(c+1:end);
%     active_task_index = index(1:c);
%     [feasible, v_norm, v_norm_square] = powermin_cvx(params, inactive_task_index, active_task_index);  %power minimization given the active RRH set
%     if feasible==1
%         TotalPower=sum(sum(1./amcoeff.*v_norm_square)) + sum(Pc(index(1:c)));  %network power consumption
%         TransmitPower= sum(sum(1./amcoeff.*v_norm_square));
%         num_of_A_optimal = c;
%         break;
%     end
% end

lb=K; ub=K*N;
while lb<ub
%     fprintf("lb is %d, ub is %d.\n", lb, ub);
    c = ceil((lb+ub)/2);
    params.c = c;
    inactive_task_index = index(c+1:end);
    active_task_index = index(1:c);
    [feasible2, v_norm, v_norm_square] = powermin_cvx(params,inactive_task_index,active_task_index);
    if ~feasible2  % if it's infeasible, then we need to activate more link.
        lb = c;
        continue;
    else
        ub = c;
        if ub-lb==1
            break;
        end
    end
end
TotalPower=sum(sum(1./amcoeff.*v_norm_square)) + sum(Pc(index(1:c)));  %network power consumption
TransmitPower= sum(sum(1./amcoeff.*v_norm_square));
num_of_A_optimal = c;
        
end