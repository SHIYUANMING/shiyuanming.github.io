function [feasible, v_norm, v_norm_square] = powermin_cvx(params, inactive_task_index,active_task_index)

K=params.K;
N=params.N;
N_set=params.N_set;
L=N_set(1);
c = params.c;
Pc = params.Pc;
amcoeff = repmat(params.amcoeff,1,K);
P_set = params.P_set;
H = params.H;
Pc = params.Pc;
delta_set = params.delta_set;
r_set = params.r_set;

cum_nset = cumsum([0;N_set(:)]);

cvx_begin quiet
variable V(sum(params.N_set), K) complex;   %Variable for N x K beamforming matrix
expression obj(N,K);
for i=1:N
    for j=1:K
%         obj(i,j) = norm(V(sum(params.N_set(1:i-1))+1:sum(params.N_set(1:i)),j), 'fro');
    obj(i,j) = sum_square_abs(V(cum_nset(i)+1:cum_nset(i+1),j));
    end
end

% active_mat = zeros(sum(N_set),K);
% for k=1:K
%     for n=1:N
%         if active_set(n,k)==1
%             active_mat(cum_nset(n)+1:cum_nset(n+1), k) = 1;
%         end
%     end
% end
active_mat = zeros(N,K);
for it=1:length(active_task_index)
    idx = active_task_index(it);
    [row,col] = ind2sub([N,K], idx);
    active_mat(row,col) = 1;
end

minimize sum(sum(1./amcoeff.*obj)) + sum(sum(active_mat.*Pc))
subject to
    %% Transmit Power Constraints
     for l=1:N    
         sum(obj(l,:)) <= P_set(l);
     end
     
     %% QoS constraints
     for k=1:K        
        norm([H(:,k)'*V, delta_set(k)],'fro')<=sqrt(1+1/r_set(k))*real(H(:,k)'*V(:,k)); 
     end
     
     %% sparsity constraint
     if ~isempty(inactive_task_index)
         for it_idx=1:length(inactive_task_index)
             idx = inactive_task_index(it_idx);
             [row,col] = ind2sub([N,K],idx);
             V((row-1)*L+1:row*L,col) == zeros(L,1);
         end
     end
cvx_end
     

%build output
%%
obj2 = zeros(N,K);
for j=1:K
    obj2(1,j) = norm(V(1:params.N_set(1),j),'fro');
end
for i=2:N
    for j=1:K
        obj2(i,j) = norm(V(1+cum_nset(i):cum_nset(i+1),j),'fro');
    end
end


if strfind(cvx_status,'Solved')
    feasible=true;
    v_norm = obj2;
    v_norm_square = obj;
%     [~, index] = sort(obj(:), 'descend');
%     power_beamformer = sum(obj(index(c+1:end)));
%     if power_beamformer<1e-4
%         feasible=true;
%         v_norm = obj;
%     else
%         feasible=false;
%         v_norm=[];
%     end
else
    feasible=false;
    v_norm=[];
    v_norm_square = [];
end
 
end
     
     