function [feasible,v_sparse,obj_value] = feasibility_check_beamforming(params,K,N,Hkn,QoS)

%prob_to_socp: maps PARAMS into a struct of SOCP matrices
%input struct 'parms' has the following fields:
%params.N;   %'L': # RRHs
%params.K;    %'K': # MUs
%params.L_set;  %set of antennas at all the RRHs
%params.Active_number;   %number of active RRHs
%params.delta_set; %set of noise covariance

%%%%%%%%%%%%%%Problem Instances%%%%%%%%%%%%%
%params.r_set;  %set of SINR thresholds
%params.H;  %Channel Realization
%params.P_set;   %set of transmit power constraints at all the RRHs

%%%%%%%%Problem Data%%%%%%%
% verb = params.verbosity;

r_set = 10^(QoS/10)*ones(K,1);     %Kx1 vector: QoS Requirements of Mobile Users for each Muliticast Group: assuming all the users have the same QoS requirments in the same group
N_set = params.N_set;   %Nx1 vector: antennas on each RAU
delta_set=params.delta_set;  %Kx1 vector: noise covariance
P_set=params.P_set;  %Nx1 vector: RAU transmit power set
cum_nset = cumsum([0;N_set(:)]);

H=Hkn;  % sum(N_set)*K channel matrix

% activeset = params.activeset;
% weight=params.weight(activeset); %length(Active_index)x1: weigth for each group beamformer
weight=ones(N,K);
%%%%%%%%CVX%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    cvx_begin quiet
    variable W(sum(N_set), K) complex;   %Variable for N x K beamforming matrix
    expression obj(N,K);
    for i=1:N
        for j=1:K
        obj(i,j) = norm(W(cum_nset(i)+1:cum_nset(i+1),j),2);
        end
    end

    minimize sum(sum((weight.*obj)))
    subject to
     for l=1:N    %%%Transmit Power Constraints
         %%
         if l==1
             norm(W(1:N_set(1),:),'fro')<=sqrt(P_set(l));
         else
             norm(W(sum(N_set(1:l-1))+1:sum(N_set(1:l)),:),'fro')<=sqrt(P_set(l));
         end
     end
     
     for k=1:K        %%%%%%%%%QoS constraints
      %%
         norm([H(:,k)'*W, delta_set(k)],'fro')<=sqrt(1+1/r_set(k))*real(H(:,k)'*W(:,k));   
     end
     cvx_end
%output = evalc('cvx_end');
 obj_value = sum(sum(weight.*(obj)));
%build output
%%
     if  strfind(cvx_status,'Solved')
         feasible=true;
         v_sparse=obj;%double(obj<1e-4);
%          obj_zeronum=sum(sum(obj<1e-4))
%          Wsolution=W;
     else
         feasible=false;
         v_sparse=[];
%          Wsolution=[];
     end
    
 

end 
