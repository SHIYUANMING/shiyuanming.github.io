% Manopt and CVX should be installed. Please refer to
% https://www.manopt.org/ and http://cvxr.com/cvx/
% Fig. 3/ Fig.4  in the paper 'Blind Demixing for Low-Latency Communication'

clear all;
clc
rng('default');rng(1);%warning('off', 'manopt:getHessian:approx');
addpath('./fun');
testnum =1;
size_set =1250;
size_len = length(size_set);
user_set =5;
user_len = length(user_set);
allcost = zeros(size_len,user_len,testnum);
r=1;
params.verbosity =2;
params.costtol = 1e-6;
params.maxiter = 80;
params.tolgradnorm = 1e-15;
params.stepsize = 0.01;

allcost1 = zeros(size_len,user_len,testnum);
allcost2 = zeros(size_len,user_len,testnum);
allcost3 = zeros(size_len,user_len,testnum);
allcost4 = zeros(size_len,user_len,testnum);
allcost5 = zeros(size_len,user_len,testnum);

n1 =50; n2 =50;
for t=1:size_len
    m = size_set(t);
    for ks = 1:user_len
        s = user_set(ks);
        Ksize = [n1,n2,s,m];
     % parfor ki = 1:testnum
     for ki = 1:testnum
         [X,y,C,x,h,g,z,y1 ] = generate_model_gaussian( m,n1,n2,s );  % Gaussian encoding matrices
         %[X,y,C,x,h,g,z,y1 ] = generate_model_hadamard( m,n1,n2,s ); % Hadamard-type encoding matrices
         [A,B,FC] = generate_decon_matrix(m,n1,n2,s,C);
%% initial 
        
         [ h,x,d,mu] = RGD_initial(Ksize,A,B,FC,y); 
         X0_re =cellfun(@(h,x)[h;x],h,x,'Uni',0);
         X0_fi = cellfun(@(h,x)h*x',h,x,'Uni',0);
%%  Riemannian trust-region
        [Xout1, infos1]=Riemannian_fixedrank_TR(r, Ksize,X0_re, params, A, y);
        x1 = cellfun(@(x,y)x(1:n1,:)*x(n1+1:end,:)',Xout1,'Uni',0);
        allcost1(t,ks,ki)=sqrt(sum(cellfun(@(x,y)norm(x(1:n1,:)*x(n1+1:end,:)'-y,'fro')^2,Xout1,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost1(t,ks,ki));
%% convex
%         [Xout2, opt_value]=convex_cvx( Ksize,  A, y);
%         allcost2(t,ks,ki)=sqrt(sum(cellfun(@(x,y)norm(x-y,'fro')^2,Xout2,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
%         fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost2(t,ks,ki));
%% Regularized GD
        [Xout3, infos3]=RGD( Ksize, A,B,mu,d, y,params,h,x);
        allcost3(t,ks,ki)=sqrt(sum(cellfun(@(x,y)norm(x-y,'fro')^2,Xout3,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost3(t,ks,ki));
%% FIHIT 
        [Xout4, infos4]=FIHT( Ksize, A, y,params,X0_fi);
        allcost4(t,ks,ki)=sqrt(sum(cellfun(@(x,y)norm(x-y,'fro')^2,Xout4,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost4(t,ks,ki));
%% Riemannian gradient
        [Xout5, infos5]=Riemannian_fixedrank_GD(r, Ksize, X0_re, params, A, y);
        allcost5(t,ks,ki)=sqrt(sum(cellfun(@(x,y)norm(x(1:n1,:)*x(n1+1:end,:)'-y,'fro')^2,Xout5,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost5(t,ks,ki));

      end
     end
end

iter1 = size(infos1,2);
re1 = zeros(iter1,1);
t1 = zeros(iter1,1);
for  i = 1:iter1
   re1(i) = infos1(i).cost;
   t1(i) = infos1(i).time;
end


iter3 = size(infos3,2);
re3 = zeros(iter3,1);
t3 = zeros(iter3,1);
for  i = 1:iter3
   re3(i) = infos3(i).cost;
   t3(i) = infos3(i).time;
end

iter4 = size(infos4,2);
re4 = zeros(iter4,1);
t4 = zeros(iter4,1);
for  i = 1:iter4
   re4(i) = infos4(i).cost;
   t4(i) = infos4(i).time;
end

iter5 = size(infos5,2);
re5 = zeros(iter5,1);
t5 = zeros(iter5,1);
for  i = 1:iter5
   re5(i) = infos5(i).cost;
   t5(i) = infos5(i).time;
end
iter_1 = 1:iter1;
iter_3 = 1:iter3;
iter_4 = 1:iter4;
iter_5 = 1:iter5;

t_1 = 1:t1;
t_3 = 1:t3;
t_4 = 1:t4;
t_5 = 1:t5;



figure,semilogy(iter_1,re1(iter_1),'LineWidth',2);hold on
semilogy(iter_3,re3(iter_3),'LineStyle','-.','LineWidth',2);
semilogy(iter_4,re4(iter_4),'LineStyle','--','LineWidth',2);
semilogy(iter_5,re5(iter_5),'LineWidth',1.2);hold off
legend('PRTR','RGD','FIHT','PRGD');
xlabel('iteration','FontSize',14,'Interpreter','latex');
ylabel('obj','FontSize',14,'Interpreter','latex');
set(gca,'Fontsize',14,'Fontname', 'Times New Roman','GridLineStyle','--');
axis tight;
axis([0 80 1e-4,100000])
grid on


figure,semilogy(t_1,re1(iter_1),'LineWidth',2);hold on
semilogy(t_3,re3(iter_3),'LineStyle','-.','LineWidth',2);
semilogy(t_4,re4(iter_4),'LineStyle','--','LineWidth',2);
semilogy(t_5,re5(iter_5),'LineWidth',1.2);hold off
legend('PRTR','RGD','FIHT','PRGD');
xlabel('time (s)','FontSize',14,'Interpreter','latex');
ylabel('obj','FontSize',14,'Interpreter','latex');
set(gca,'Fontsize',14,'Fontname', 'Times New Roman','GridLineStyle','--');
axis tight;
axis([0 30 1e-4,100000])
grid on


