function [ X,y,C,x,h,g,z,y1 ] = generate_model_conditionnumber( m,n1,n2,K,con)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
C = cell(K,1);
x = cell(K,1);
h = cell(K,1);
g = cell(K,1);
z = cell(K,1);
X = cell(K,1);
y1 = cell(K,1);
y = zeros(m,1);
F = dftmtx(m)/sqrt(m);
yy = zeros(m,1);
B = F(:,1:n2);
for k=1:1:ceil(K/2)
%     C{k} = (randn(m,n1)+1i*randn(m,n1))/sqrt(2);
%     x{k} = randn(n1,1)+1i*randn(n1,1);
%     x{k} = x{k}/norm(x{k});
    h{k} = randn(n2,1)+1i*randn(n2,1);
     h{k} = h{k}/norm(h{k}); 
    g{k} = [h{k};zeros(m-n2,1)];
    
     nFFT = n1;
    M = 16;
    modObj = modem.qammod(M);
    XM = randi([0 M-1],nFFT,1);  %BPSK symbols
    XD = modulate(modObj,XM)/sqrt(10); % normalizing symbol power
    xout =(dftmtx(nFFT)/sqrt(nFFT))'*XD;
    D = diag((rand(m,1)<.5)*2 - 1);
    Fc = dftmtx(m)/sqrt(m);
    H = hadamard(m);
    H = H(:,1:n1);
     C{k} = Fc*D*H;
%       C{k} = (randn(m,n1)+1i*randn(m,n1))/sqrt(2);

    x{k} = xout;
    
    z{k} = C{k}*x{k};
    
    X{k} = x{k}*conj(h{k}');
    scale = norm(X{k});
    X{k} = X{k}/scale;
    y1{k} = cconv(z{k},g{k},m)/scale;
    y = y+F*y1{k}/sqrt(m);   
end

for k=  ceil(K/2)+1:K
%     C{k} = (randn(m,n1)+1i*randn(m,n1))/sqrt(2);
%     x{k} = randn(n1,1)+1i*randn(n1,1);
%     x{k} = x{k}/norm(x{k});

    h{k} = randn(n2,1)+1i*randn(n2,1);
     h{k} = h{k}/norm(h{k}); 
    g{k} = [h{k};zeros(m-n2,1)];
    
     nFFT = n1;
    M = 16;
    modObj = modem.qammod(M);
    XM = randi([0 M-1],nFFT,1);  %BPSK symbols
    XD = modulate(modObj,XM)/sqrt(10); % normalizing symbol power
    xout =(dftmtx(nFFT)/sqrt(nFFT))'*XD;
    D = diag((rand(m,1)<.5)*2 - 1);
    Fc = dftmtx(m)/sqrt(m);
    H = hadamard(m);
    H = H(:,1:n1);
     C{k} = Fc*D*H;
%        C{k} = (randn(m,n1)+1i*randn(m,n1))/sqrt(2);

    x{k} =xout;
    
    z{k} = C{k}*x{k};
    X{k} = x{k}*conj(h{k}');
    scale = norm(X{k});
    X{k} = (con)*X{k}/scale;
    y1{k} =(con)*cconv(z{k},g{k},m)/scale;
    y = y+F*y1{k}/sqrt(m); 
end



end

