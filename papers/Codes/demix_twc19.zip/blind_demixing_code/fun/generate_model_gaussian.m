function [ X,y,C,x,h,g,z,y1 ] = generate_model_gaussian( m,n1,n2,K )
% m: sample size
% n1: the dimension of signal x
% n2: the dimension of signal h
% K: the number of users
C = cell(K,1);
x = cell(K,1);
h = cell(K,1);
g = cell(K,1);
z = cell(K,1);
X = cell(K,1);
y1 = cell(K,1);
y = zeros(m,1);
F = dftmtx(m)/sqrt(m);
for k=1:K
    h{k} = randn(n2,1)+1i*randn(n2,1);
    h{k} = h{k}/norm(h{k});
    g{k} = [h{k};zeros(m-n2,1)];
    C{k} = (randn(m,n1)+1i*randn(m,n1))/sqrt(2);
    
    x{k} = randn(n1,1)+1i*randn(n1,1);
    x{k} = x{k}/norm(x{k});

    z{k} = C{k}*x{k};
    X{k} = x{k}*conj(h{k}');
  
    y1{k} = cconv(z{k},g{k},m);
    y = y+F*y1{k}/sqrt(m);   
end
 


end

