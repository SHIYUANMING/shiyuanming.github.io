function [Xreturn,opcost] = convex_cvx( Ksize, A, b)
m=Ksize(1); n=Ksize(2); K = Ksize(3);
f=@(X)cost(X,A,b);
N=@(X)Nx(X);

cvx_begin quiet
% cvx_expert true
    variable X(m,n,K) complex symmetric
%     minimize  N(X)
%     subject to  
%            f(X)<1e-9  
      minimize  f(X)
      subject to 
               N(X) <=45

cvx_end

Xreturn=cell(K,1);
for i = 1:K
  Xreturn{i} = X(:,:,i);
end
opcost =N(X);
end
function fx = cost(X,A,b)  
     sum_Ax = zeros(size(b,1),1);
     for ik = 1:size(X,3)
        x = X(:,:,ik);
        sum_Ax  = sum_Ax + A{ik}*x(:);        
     end
     fx =norm(sum_Ax-b,2);
end
function n = Nx(X)
k = size(X,3);
n = 0;
for i = 1:k,
    n = n + norm_nuc(X(:,:,(i)));
end
end