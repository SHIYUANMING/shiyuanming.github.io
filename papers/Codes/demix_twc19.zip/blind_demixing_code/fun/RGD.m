function [ X, info ] = RGD(Ksize, A,B,mu,d, y,options,u,v)
%RGD �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
if ~isfield(options,'tolgradnorm'); options.tolgradnorm=1e-6; end
if ~isfield(options,'verbosity'); options.verbosity=1; end

n1=Ksize(1); n2=Ksize(2); s = Ksize(3);m = Ksize(4);
% [u,v,d,mu] = RGD_initial(Ksize,B,FC,y);
% [~,d0,~] =  cellfun(@(x)svds(x,1),options.X,'Uni',0);

d0_pre = cellfun(@(h,x)norm(h)^2*norm(x)^2,u,v,'Uni',0);
rho = sum(cell2mat(d0_pre));
f = @(u,v)object(A,B,u,v,rho,mu,y,d,m);
g = @(u,v)gradient(A,B,u,v,d,y,n1,n2,rho,m,mu);
contraction_factor = .5;
info = struct();
ts = tic();
info(1).time = toc(ts);


[info(1).cost,Ax]=f(u,v);
info(1).Ax = sum([Ax{:}],2);
info(1).re=norm(sum([Ax{:}],2)-y)/norm(y);
iter = 1;
h = u; x = v;
while iter<=options.maxiter
    fprintf('iteration: %d, cost: %d\n',iter,info(iter).cost);
    iter = iter + 1;
    alpha = 1/(n1+n2);
    [f0,~] = f(h,x);
    [gh,gx] = g(h,x);
    newh =  cellfun(@(h,gh)h-alpha*gh,h,gh,'Uni',0);
    newx =  cellfun(@(x,gx)x-alpha*gx,x,gx,'Uni',0);
    [newf,Ax] = f(newh,newx);
    cost_evalu = 1;
  
    while newf>f0 
        alpha = contraction_factor * alpha;
        newh =  cellfun(@(h,gh)h-alpha*gh,h,gh,'Uni',0);
        newx =  cellfun(@(x,gx)x-alpha*gx,x,gx,'Uni',0);
        [newf,Ax] = f(newh,newx);
        cost_evalu = cost_evalu+ 1;

        if cost_evalu >= 25;
            break;
        end
    end

  if newf >= f0
        newh = h;
        newx = x;
        [newf,Ax] = f(newh,newx); 
  end
 
   if (norm(sum([Ax{:}],2)-info(end).Ax)/norm(y)<1e-6)
        info(iter).cost = newf;
        info(iter).Ax = sum([Ax{:}],2);
        info(iter).time = toc(ts);  
        info(iter).re=norm(sum([Ax{:}],2)-y)/norm(y);
     break;
   end
   
    h =  cellfun(@(h,gh)h-alpha*gh,h,gh,'Uni',0);
    x =  cellfun(@(x,gx)x-alpha*gx,x,gx,'Uni',0);
    info(iter).cost = newf;
    info(iter).Ax = sum([Ax{:}],2);
    info(iter).time = toc(ts);  
    info(iter).re=norm(sum([Ax{:}],2)-y)/norm(y);

    X = cellfun(@(x,y)x*y',h,x,'Uni',0);
end


end
function [f,Ax] = object(A,B,h,x,rho,mu,y,d,m)
Xmat = cellfun(@(x,y)x*y',h,x,'Uni',0);
Ax = cellfun(@(x,y)x*y(:),A,Xmat,'Uni',0);
f1 = norm(sum([Ax{:}],2)-y)^2;
N_mu = cellfun(@(d,h)sum(G0(m*(abs(B*h)).^2/(8*d*mu^2))),d,h,'Uni',0);
f2 = cellfun(@(h,x,z,d)rho*(G0(norm(h)^2/(2*d))+G0(norm(x)^2/(2*d))+z),h,x,N_mu,d,'Uni',0);
f = f1+sum([f2{:}],2);

end
function [fgh,fgx] = gradient(A,B,h,x,d,y,n1,n2,rho,m,mu)

Xmat = cellfun(@(x,y)x*y',h,x,'Uni',0);
Ax = cellfun(@(x,y)x*y(:),A,Xmat,'Uni',0);
G = cellfun(@(A)reshape(A'*(sum([Ax{:}],2)-y),[n1,n2]),A,'Uni',0);
fh = cellfun(@(G,X)G*X,G,x,'Uni',0);
fx = cellfun(@(G,X)G'*X,G,h,'Uni',0);
N_mu_prime = cellfun(@(d,h)G0prime(m*(abs(B(1,:)*h)).^2/(8*d*mu^2))*B(1,:)'*B(1,:)*h,d,h,'Uni',0);
for i = 2:m
    N_mu_prime = cellfun(@(x,d,h)m/(4*mu^2)*x+G0prime(m*(abs(B(i,:)*h)).^2/(8*d*mu^2))*B(i,:)'*B(i,:)*h,N_mu_prime,d,h,'Uni',0);
end
gh = cellfun(@(h,x,z,d)rho/(2*d)*(G0prime(norm(h)^2/(2*d))*h+z),h,x, N_mu_prime,d,'Uni',0);
gx = cellfun(@(x,d)rho/(2*d)*(G0prime(norm(x)^2/(2*d))*x),x, d,'Uni',0);
fgh = cellfun(@(x,y)x+y,fh,gh,'Uni',0);
fgx = cellfun(@(x,y)x+y,fx,gx,'Uni',0);
end

function f = G0(x)
f =max(x-1,0).^2;
end

function f = G0prime(x)
if x>1
    f = 1;
else
    f = 0;
end
end
