function [Xcg, infos]=Riemannian_fixedrank_GD(r, Ksize, X0, options, A, b,X_or,x_or,h_or,C,B)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
if ~isfield(options,'tolgradnorm'); options.gradtol=1e-6; end
if ~isfield(options,'verbosity'); options.verbosity=1; end
m=Ksize(1); n=Ksize(2); K = Ksize(3);
% Pick the manifold of fixed-rank matrices
     problem.M = powermanifold(symfixedrankYYcomplexfactory(m+n, r), K);
 % problem.M = powermanifold(euclideancomplexfactory(m+n,r), K);
    %% Define the problem cost function f(X) = 1/2 * || P.*(X-A) ||^2
    problem.cost = @cost;  % The input X is a structure with fields U, S, V representing a rank k matrix as U*S*V'.
    function [f, store,re] = cost(X, store)
        if ~isfield(store,'Xmat')
            store.Xmat = cellfun(@(x)x(1:m,:)*x(m+1:end,:)',X,'Uni',0);
             
        end
%         M = A{1};
%         
%         B1 = reshape(M(1,:)',2,2);
%         B2 = reshape(M(2,:)',2,2);
%         B1 = [zeros(2,2),B1;zeros(2,2),zeros(2,2)];
%         B2 = [zeros(2,2),B2;zeros(2,2),zeros(2,2)];
%         xx =  cellfun(@(x)x*x',X,'Uni',0);
%         c1 = trace(B1'*xx{1});
%         c2 = trace(B2'*xx{1});
        Ax = cellfun(@(x,y)x*y(:),A,store.Xmat,'Uni',0);
%         f = 0.5 *norm(sum([Ax{:}],2)-b)^2;
         f = norm(sum([Ax{:}],2)-b)^2;
         re = norm(sum([Ax{:}],2)-b)/norm(b);
    end

    %% Define the Euclidean gradient of the cost function nabla f(X) = P.*(X-A)
    problem.egrad = @egrad;
    function [g,store] = egrad(X,store)
        % Same comment here about Xmat.
        if ~isfield(store,'Xmat')
            store.Xmat = cellfun(@(x)x(1:m,:)*x(m+1:end,:)',X,'Uni',0);
        end
        if ~isfield(store,'G')
            Ax = cellfun(@(x,y)x*y(:),A,store.Xmat,'Uni',0);
            store.G = cellfun(@(A)2*reshape(A'*(sum([Ax{:}],2)-b),[m,n]),A,'Uni',0);
        end
%         g = cellfun(@(G,X)[G*X(m+1:end,:);G'*X(1:m,:)]/2,store.G,X,'Uni',0);
g = cellfun(@(G,X)[G*X(m+1:end,:);G'*X(1:m,:)],store.G,X,'Uni',0);
    end

    %% Define the Euclidean Hess  
problem.ehess = @ehess;
 function [Hess,store] = ehess(X, eta, store)
        if ~isfield(store,'Xmat')
            store.Xmat = cellfun(@(x)x(1:m,:)*x(m+1:end,:)',X,'Uni',0);
        end
        if ~isfield(store,'G')
%             store.G = cellfun(@(A,x,b)reshape(A'*(A*x(:)-b),[m,n]),A,store.Xmat,b,'Uni',0);
            Ax = cellfun(@(x,y)x*y(:),A,store.Xmat,'Uni',0);
            store.G = cellfun(@(A)2*reshape(A'*(sum([Ax{:}],2)-b),[m,n]),A,'Uni',0);
        end
        
        Xmatdot = cellfun(@(x,y)y(1:m,:)*x(m+1:end,:)' + x(1:m,:)*y(m+1:end,:)',X,eta,'Uni',0);
        Axdot = cellfun(@(x,y)x*y(:),A,Xmatdot,'Uni',0);
        Pdot = cellfun(@(A)2*reshape(A'*(sum([Axdot{:}],2)),[m,n]),A,'Uni',0);
        
       
        HessL = cellfun(@(G,eta,Pdot,X)G * eta(m+1:end,:) + Pdot*X(m+1:end,:),store.G,eta,Pdot,X,'Uni',0);
        HessR = cellfun(@(G,eta,Pdot,X)G' * eta(1:m,:) + Pdot'*X(1:m,:),store.G,eta,Pdot,X,'Uni',0);
        Hess = cellfun(@(L,R)[L;R],HessL,HessR,'Uni',0);
       

 end
%  figure,checkgradient(problem);
%  figure,checkhessian(problem);
    %% If mycost exists, we use our stopping criteron, else default
% options.stopfun = @mystop;
%     function y = mystop(problem, x, info, last)
% %         y = info(last).cost<options.costtol;
%        y = sqrt(2*info(last).cost/m)<options.costtol;
%     end
    %% 
       if ~isempty(X0)
           Xs = X0;
       else
           Xs = [];
       end
%        [Xcg, xcost, infos, options] = trustregions(problem, Xs, options);
[Xcg, xcost, options,infos] = gradientdescent_ota(problem, Xs, options,X_or,x_or,h_or,C,B);
end

