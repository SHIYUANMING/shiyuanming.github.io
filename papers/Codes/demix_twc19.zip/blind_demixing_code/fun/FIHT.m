function [X,info] = FIHT( Ksize, A, y,options,X0)
%FIHT �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
r = 1;
n1=Ksize(1); n2=Ksize(2); s = Ksize(3);m = Ksize(4);
if isempty(X0) 
    X0_pre = cellfun(@(A)reshape(A'*y,[n1,n2]),A,'Uni',0);
    [u,d,v] = cellfun(@(x)svds(x,r),X0_pre,'Uni',0);
    X0 = cellfun(@(u,d,v)u*d*v',u,d,v,'Uni',0);
end
X = X0;
f = @(X)object(A,y,X);
P = @(X,G)projection(X,G);

iter = 1;
info = struct();
ts = tic();
info(1).time = toc(ts);
info(1).cost=f(X);
Ax = cellfun(@(x,y)x*y(:),A,X,'Uni',0);
re=norm(sum([Ax{:}],2)-y)/norm(y);
info(iter).re = re;
while iter<options.maxiter
     fprintf('iteration: %d, cost: %d\n',iter,info(iter).cost);
    iter = iter+1;
    Ax = cellfun(@(x,y)x*y(:),A,X,'Uni',0);
    r_l = y-sum([Ax{:}],2);
    G = cellfun(@(A)reshape(A'*r_l,[n1,n2]),A,'Uni',0);
    PG = cellfun(@(X,G)P(X,G),X,G,'Uni',0);
    alpha =cellfun(@(A,PG)norm(PG,'fro')^2/norm(A*PG(:),'fro')^2,A,PG,'Uni',0);
    X_pre = cellfun(@(X,a,G)X+a*G,X,alpha,PG,'Uni',0);
    [u,d,v] = cellfun(@(x)svds(x,r),X_pre,'Uni',0);
    X = cellfun(@(u,d,v)u*d*v',u,d,v,'Uni',0);
    Ax = cellfun(@(x,y)x*y(:),A,X,'Uni',0);
    re=norm(sum([Ax{:}],2)-y)/norm(y);
    if re<1e-4||f(X)>1e20
        info(iter).time = toc(ts);
        info(iter).cost=f(X);
        info(iter).re = re;
     break;
    end
    info(iter).time = toc(ts);
    info(iter).cost=f(X);
    info(iter).re = re;
end
end

function ff = object(A,y,X)
Ax = cellfun(@(x,y)x*y(:),A,X,'Uni',0);
ff = norm(sum([Ax{:}],2)-y)^2;
end

function P = projection(X,G)
% [u,d,v] = svds(G,1);
[u,~,v] =svds(X,1);
m = size(u,1);
n = size(v,1);
% P = ux*(v*sqrt(d)')'+u*sqrt(d)*vx';
P = u*u'*G+G*(v*v')-u*u'*G*(v*v');
% pu = u*u';
% pv = v*v';
% pu_o = eye(m)-pu;
% pv_o = eye(n)-pv;
% P = pu*G*pv+pu_o*G*pv+pu*G*pv_o;
end

