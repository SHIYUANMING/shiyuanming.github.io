% Manopt and CVX should be installed. Please refer to
% https://www.manopt.org/ and http://cvxr.com/cvx/
% Fig. 6  in the paper 'Blind Demixing for Low-Latency Communication'


clear all;
clc
rng('default');rng(1);
warning off
addpath('./fun');

testnum = 10;
size_set =1024; 
size_len = length(size_set);
user_set =3;
user_len = length(user_set);
allcost1 = zeros(size_len,user_len,testnum);
allcost2 = zeros(size_len,user_len,testnum);
allcost3 = zeros(size_len,user_len,testnum);
allcost4 = zeros(size_len,user_len,testnum);
allcost5 = zeros(size_len,user_len,testnum);

r=1;
params.verbosity =0;
params.costtol = 1e-6;
params.maxiter = 1000;
params.tolgradnorm = 1e-6;
n1=50; n2 = 50;
for t=1:size_len
    m = size_set(t);
    for ks = 1:user_len
        s = user_set(ks);
        Ksize = [n1,n2,s,m];
       for ki = 1:testnum
         [X,y,C,x,h,g,z,y1 ] = generate_model_gaussian( m,n1,n2,s );  % Gaussian encoding matrices
         %[X,y,C,x,h,g,z,y1 ] = generate_model_hadamard( m,n1,n2,s ); % Hadamard-type encoding matrices

         [A,B,FC] = generate_decon_matrix(m,n1,n2,s,C);
%% initial 
         
         [ hr,xr,d,mu] = RGD_initial(Ksize,A,B,FC,y);
         X0_fi = cellfun(@(h,x)h*x',hr,xr,'Uni',0);
         X0_rand =cellfun(@(h,x)[h;x],h,x,'Uni',0);
         X0_re = cellfun(@(h,x)[h;x],hr,xr,'Uni',0);
%%  Riemannian
        [Xout1, infos1]=Riemannian_fixedrank_TR(r, Ksize, X0_re, params, A, y);
        x1 = cellfun(@(x,y)x(1:n1,:)*x(n1+1:end,:)',Xout1,'Uni',0);
        allcost1(t,ks,ki)=sqrt(sum(cellfun(@(x,y)norm(x(1:n1,:)*x(n1+1:end,:)'-y,'fro')^2,Xout1,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost1(t,ks,ki));
%% convex
        [Xout2, opt_value]=convex_cvx( Ksize,  A, y);
        allcost2(t,ks,ki)=sqrt(sum(cellfun(@(x,y)norm(x-y,'fro')^2,Xout2,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost2(t,ks,ki));
%% Regularized GD
        [Xout3, infos3]=RGD( Ksize, A,B,mu,d, y,params,hr,xr);
        allcost3(t,ks,ki)=sqrt(sum(cellfun(@(x,y)norm(x-y,'fro')^2,Xout3,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost3(t,ks,ki));
%% FIHIT 
        [Xout4, infos4]=FIHT( Ksize, A, y,params,X0_fi);
        allcost4(t,ks,ki)=sqrt(sum(cellfun(@(x,y)norm(x-y,'fro')^2,Xout4,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost4(t,ks,ki));
%% Riemannian gradient
        [Xout5, infos5]=Riemannian_fixedrank_GD(r, Ksize, X0_re, params, A, y);
        allcost5(t,ks,ki)=sqrt(sum(cellfun(@(x,y)norm(x(1:n1,:)*x(n1+1:end,:)'-y,'fro')^2,Xout5,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost5(t,ks,ki));

        end
    end
end

tol = 1e-3;
test_succ1 = sum(allcost1<tol,3)/testnum;
test_succ2 = sum(allcost2<tol,3)/testnum;
test_succ3 = sum(allcost3<tol,3)/testnum;
test_succ4 = sum(allcost4<tol,3)/testnum;
test_succ5 = sum(allcost5<tol,3)/testnum;

rme1 = mean(allcost1,3);
rme2 = mean(allcost1,3);
rme3 = mean(allcost3,3);
rme4 = mean(allcost4,3);
rme5 = mean(allcost5,3);



figure,plot(user_set,test_succ1,'s-','LineWidth',1.5);hold on
plot(user_set,test_succ2,'s-','LineWidth',1.5);hold on
plot(user_set,test_succ3,'s-','LineWidth',1.5);hold on
plot(user_set,test_succ4,'s-','LineWidth',1.5);
plot(user_set,test_succ5,'s-','LineWidth',1.5);

legend('PRTR','NNM','RGD','FIHIT','PRGD');

xlabel('User Number','FontSize',14);
ylabel('Probability of sucessful recovery','FontSize',14);
axis tight;
