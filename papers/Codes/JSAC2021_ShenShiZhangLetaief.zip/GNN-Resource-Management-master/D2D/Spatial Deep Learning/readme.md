An GNN-based approach for spatial deep learning. The simulation setting is the same as Table III and Table IV of paper "[Spatial Deep Learning for Wireless Scheduling](https://arxiv.org/abs/1808.01486)". 

For any reproduce, further research or development, please kindly cite the following papers

* [Spatial Deep Learning for Wireless Scheduling](https://arxiv.org/abs/1808.01486)
* [Graph Neural Networks for Scalable Radio Resource Management: Architecture Design and Theoretical Analysis](https://arxiv.org/abs/2007.07632)

