##GNN-based Method for Large-scale Radio Resource Management Problem
This repository contains our work of GNN-based radio resource management. Our paper "**Graph Neural Networks for Scalable Radio Resource Management: Architecture Design and Theoretical Analysis**" is available at [https://arxiv.org/abs/2007.07632](https://arxiv.org/abs/2007.07632).

For any reproduce, further research or development, please kindly cite our  paper.
